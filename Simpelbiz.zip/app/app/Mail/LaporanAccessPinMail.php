<?php

namespace App\Mail;

use App\Models\LaporanAccessPin;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class LaporanAccessPinMail extends Mailable
{
    use Queueable, SerializesModels;

    public LaporanAccessPin $accessPin;

    public function __construct(LaporanAccessPin $accessPin)
    {
        $this->accessPin = $accessPin;
    }

    public function build()
    {
        return $this->subject('PIN Akses Laporan Keuangan UMKM')
            ->view('emails.laporan_access_pin');
    }
}
