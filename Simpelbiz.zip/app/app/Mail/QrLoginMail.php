<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class QrLoginMail extends Mailable
{
    use Queueable, SerializesModels;

    public $qrImage;

    /**
     * Create a new message instance.
     */
    public function __construct($qrImage)
    {
        $this->qrImage = $qrImage;
    }

    /**
     * Build the message.
     */
    public function build()
    {
        return $this->subject('QR Code Login UMKM')
            ->view('emails.qr-login')
            ->with([
                'qrImage' => $this->qrImage
            ]);
    }
}
