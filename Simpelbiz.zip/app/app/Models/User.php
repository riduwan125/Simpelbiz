<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail; // ← penting

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable;

    // Tabel & primary key
    protected $table = 'users';
    protected $primaryKey = 'id_user';
    public $incrementing = true;
    protected $keyType   = 'int';

    // Mass assignment
    protected $fillable = [
        'nama_user',
        'email',
        'password',
    ];

    // Hidden
    protected $hidden = [
        'password',
        'remember_token',
    ];

    // Casts
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
        ];
    }

    // Relasi
    public function umkm()
    {
        return $this->hasOne(Umkm::class, 'id_user', 'id_user');
    }

    public function laporanKeuangan()
    {
        return $this->hasMany(LaporanKeuangan::class, 'id_user', 'id_user');
    }

    public function qrLogin()
    {
        return $this->hasMany(QrLogin::class, 'id_user', 'id_user');
    }

    // Mutator: normalisasi email
    public function setEmailAttribute($value)
    {
        $this->attributes['email'] = strtolower(trim($value));
    }
}
