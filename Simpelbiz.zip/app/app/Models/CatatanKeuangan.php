<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatatanKeuangan extends Model
{
    use HasFactory;

    protected $table = 'catatan_keuangan';
    protected $primaryKey = 'id_catatan';

    protected $fillable = [
        'id_umkm',
        'id_laporan',
        'jenis_catatan',
        'deskripsi',
        'jumlah',
        'satuan',
        'nominal',
        'tanggal_transaksi',
    ];

    public function umkm()
    {
        return $this->belongsTo(Umkm::class, 'id_umkm');
    }

    // Catatan milik satu laporan (boleh null kalau belum dijadikan laporan)
    public function laporan()
    {
        return $this->belongsTo(LaporanKeuangan::class, 'id_laporan', 'id_laporan');
    }
}
