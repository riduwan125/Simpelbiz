<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SatuanUmkm extends Model
{
    use HasFactory;

    protected $table = 'satuan_umkm';
    protected $primaryKey = 'id_satuan';

    protected $fillable = [
        'id_umkm',
        'nama_satuan',
    ];

    public $timestamps = true;

    public function umkm()
    {
        return $this->belongsTo(Umkm::class, 'id_umkm');
    }
}
