<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ModalBeban extends Model
{
    protected $table = 'modal_beban';
    protected $primaryKey = 'id_modal_beban';

    protected $fillable = [
        'id_umkm',
        'jenis',              // modal_usaha / beban_operasional
        'jumlah',
        'nominal',
        'tanggal_transaksi',
        'deskripsi',
    ];

    public function umkm()
    {
        return $this->belongsTo(Umkm::class, 'id_umkm', 'id_umkm');
    }
}
