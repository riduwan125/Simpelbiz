<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class QrLogin extends Model
{
    use HasFactory;

    /**
     * Nama tabel di database
     */
    protected $table = 'qr_login';

    /**
     * Primary key sesuai dengan migrasi
     * (karena di migrasi kamu: $table->id('id_qr_login'))
     */
    protected $primaryKey = 'id_qr_login';
    public $incrementing = true;
    protected $keyType = 'int';

    /**
     * Kolom yang bisa diisi (mass assignment)
     */
    protected $fillable = [
        'id_user',
        'token_login',
        'expires_at',
        'used_at',
    ];

    /**
     * Casting otomatis ke tipe data tanggal (Carbon)
     */
    protected $casts = [
        'expires_at' => 'datetime',
        'used_at'    => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relasi ke model User
     * QrLogin(id_user) → User(id_user)
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }

    /**
     * Scope: ambil token yang masih valid
     * - belum dipakai (used_at null)
     * - belum kedaluwarsa (expires_at > now)
     */
    public function scopeValid(Builder $query): Builder
    {
        return $query
            ->whereNull('used_at')
            ->where('expires_at', '>', now());
    }

    /**
     * Tandai token sudah digunakan
     */
    public function markUsed(): void
    {
        $this->used_at = now();
        $this->save();
    }

    /**
     * Accessor: cek status token
     */
    public function getIsUsedAttribute(): bool
    {
        return !is_null($this->used_at);
    }

    public function getIsExpiredAttribute(): bool
    {
        return now()->greaterThan($this->expires_at);
    }

    public function getIsValidAttribute(): bool
    {
        return !$this->is_used && !$this->is_expired;
    }
}
