<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LaporanAccessPin extends Model
{
    use HasFactory;

    protected $table = 'laporan_access_pins';

    protected $fillable = [
        'laporan_id',
        'email',
        'pin',
        'expires_at',
        'used_at',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'used_at'    => 'datetime',
    ];

    public function laporan()
    {
        return $this->belongsTo(LaporanKeuangan::class, 'laporan_id', 'id_laporan');
    }
}
