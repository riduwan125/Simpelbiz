<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LaporanKeuangan extends Model
{
    use HasFactory;

    protected $table = 'laporan_keuangan';
    protected $primaryKey = 'id_laporan';

    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'id_umkm',
        'bulan',
        'tahun',
        'path_pdf',
        'path_qr_pdf',
    ];

    public function umkm()
    {
        return $this->belongsTo(Umkm::class, 'id_umkm', 'id_umkm');
    }

    // ✅ snapshot detail (yang dipakai untuk halaman detail laporan)
    public function details()
    {
        return $this->hasMany(LaporanKeuanganDetail::class, 'laporan_id', 'id_laporan');
    }

    // kalau kamu masih pakai tabel qr_laporan, ini ok
    public function qrLaporan()
    {
        return $this->hasOne(QrLaporan::class, 'id_laporan', 'id_laporan');
    }
}
