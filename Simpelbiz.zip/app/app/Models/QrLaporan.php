<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class QrLaporan extends Model
{
    use HasFactory;

    protected $table = 'qr_laporan';
    protected $primaryKey = 'id_token';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'id_laporan',
        'token_akses',
    ];

    public function laporan()
    {
        return $this->belongsTo(LaporanKeuangan::class, 'id_laporan', 'id_laporan');
    }

    // valid 5 hari dari created_at
    public function isExpired(int $days = 5): bool
    {
        if (!$this->created_at) return true;
        return $this->created_at->copy()->addDays($days)->isPast();
    }
}
