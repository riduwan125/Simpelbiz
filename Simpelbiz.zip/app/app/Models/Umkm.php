<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Umkm extends Model
{
    use HasFactory;

    protected $table = 'umkm';
    protected $primaryKey = 'id_umkm';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'id_user',
        'nama_umkm',
        'alamat_umkm',
        'jenis_usaha',
        'no_telepon',
    ];


    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }

    public function catatanKeuangan()
    {
        return $this->hasMany(CatatanKeuangan::class, 'id_umkm', 'id_umkm');
    }

    public function satuan()
    {
        return $this->hasMany(SatuanUmkm::class, 'id_umkm', 'id_umkm');
    }
}
