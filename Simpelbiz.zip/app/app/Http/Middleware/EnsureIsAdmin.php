<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EnsureIsAdmin
{
    public function handle(Request $request, Closure $next)
    {
        // ✅ Jika belum login, redirect ke login
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        // ✅ Jika sudah login tapi bukan admin
        if (!Auth::user()->is_admin) {
            Auth::logout();
            return redirect()->route('login')->withErrors([
                'email' => 'Anda tidak memiliki akses ke halaman admin.',
            ]);
        }

        return $next($request);
    }
}
