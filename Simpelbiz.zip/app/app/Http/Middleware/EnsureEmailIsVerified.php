<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureEmailIsVerified
{
    /**
     * Pastikan user sudah verifikasi email.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        // Kalau belum login
        if (!$user) {
            return redirect()->route('login');
        }

        // Kalau belum verifikasi email
        if (is_null($user->email_verified_at)) {
            return redirect()->route('verification.notice')
                ->with('warning', 'Silakan verifikasi email Anda terlebih dahulu.');
        }

        return $next($request);
    }
}
