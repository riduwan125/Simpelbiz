<?php

namespace App\Http\Controllers;

use App\Models\ModalBeban;
use App\Models\Umkm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ModalBebanController extends Controller
{
    /**
     * Ambil UMKM milik user yang login.
     */
    protected function getUmkm()
    {
        $user = Auth::user();

        return Umkm::where('id_user', $user->id_user)->firstOrFail();
    }

    /**
     * Tampilkan daftar Biaya Usaha (Modal Usaha & Beban Operasional).
     */
    public function index()
    {
        $umkm = $this->getUmkm();

        $data = ModalBeban::where('id_umkm', $umkm->id_umkm)
            ->orderBy('tanggal_transaksi', 'desc')
            ->get();

        return view('modal-beban.index', compact('data'));
    }

    /**
     * Form tambah Biaya Usaha.
     */
    public function create()
    {
        return view('modal-beban.create');
    }

    /**
     * Simpan data baru.
     */
    public function store(Request $request)
    {
        $request->validate([
            'jenis'             => 'required|in:modal_usaha,beban_operasional',
            'tanggal_transaksi' => 'required|date',
            'deskripsi'         => 'required|string|max:255',
            'nominal'           => 'required|numeric|min:0',
            'jumlah'            => 'nullable|numeric|min:1',
        ]);

        $umkm = $this->getUmkm();

        // Kalau modal_usaha → pakai input jumlah, kalau beban_operasional → default 1
        $jumlah = $request->jenis === 'modal_usaha'
            ? ($request->jumlah ?? 1)
            : 1;

        ModalBeban::create([
            'id_umkm'           => $umkm->id_umkm,
            'jenis'             => $request->jenis,
            'tanggal_transaksi' => $request->tanggal_transaksi,
            'deskripsi'         => $request->deskripsi,
            'jumlah'            => $jumlah,
            'nominal'           => $request->nominal,
        ]);

        return redirect()
            ->route('modal-beban.index')
            ->with('success', 'Data biaya usaha berhasil ditambahkan.');
    }

    /**
     * Form edit.
     */
    public function edit($id)
    {
        $umkm = $this->getUmkm();

        $item = ModalBeban::where('id_modal_beban', $id)
            ->where('id_umkm', $umkm->id_umkm) // pastikan milik UMKM yang login
            ->firstOrFail();

        return view('modal-beban.edit', compact('item'));
    }

    /**
     * Update data yang sudah ada.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'jenis'             => 'required|in:modal_usaha,beban_operasional',
            'tanggal_transaksi' => 'required|date',
            'deskripsi'         => 'required|string|max:255',
            'nominal'           => 'required|numeric|min:0',
            'jumlah'            => 'nullable|numeric|min:1',
        ]);

        $umkm = $this->getUmkm();

        $item = ModalBeban::where('id_modal_beban', $id)
            ->where('id_umkm', $umkm->id_umkm)
            ->firstOrFail();

        $jumlah = $request->jenis === 'modal_usaha'
            ? ($request->jumlah ?? 1)
            : 1;

        $item->update([
            'jenis'             => $request->jenis,
            'tanggal_transaksi' => $request->tanggal_transaksi,
            'deskripsi'         => $request->deskripsi,
            'jumlah'            => $jumlah,
            'nominal'           => $request->nominal,
        ]);

        return redirect()
            ->route('modal-beban.index')
            ->with('success', 'Data biaya usaha berhasil diperbarui.');
    }

    /**
     * Hapus data.
     */
    public function destroy($id)
    {
        $umkm = $this->getUmkm();

        $item = ModalBeban::where('id_modal_beban', $id)
            ->where('id_umkm', $umkm->id_umkm)
            ->firstOrFail();

        $item->delete();

        return redirect()
            ->route('modal-beban.index')
            ->with('success', 'Data biaya usaha berhasil dihapus.');
    }
}
