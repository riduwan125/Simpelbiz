<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class PenggunaController extends Controller
{
    public function index()
    {

        $user = auth()->user();
        $umkm = Umkm::where('id_user', $user->id_user)->first();

        return view('pengguna.index', compact('user', 'umkm'));
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('pengguna.edit', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $validated = $request->validate([
            'nama_user' => 'required|string|max:255',
            'email'     => 'required|email',
            'nama_umkm' => 'required|string|max:255',
            'password'  => 'nullable|string|min:8',
        ]);

        $user->nama_user = $validated['nama_user'];
        $user->email     = $validated['email'];
        $user->nama_umkm = $validated['nama_umkm'];

        if (!empty($validated['password'])) {
            $user->password = Hash::make($validated['password']);
        }

        $user->save();

        return redirect()->route('pengguna.index')->with('success', 'Data pengguna berhasil diperbarui.');
    }
}
