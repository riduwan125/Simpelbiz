<?php

namespace App\Http\Controllers;

use App\Models\CatatanKeuangan;
use App\Models\Umkm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $umkm = Umkm::where('id_user', $user->id_user)->firstOrFail();

        $now           = Carbon::now();
        $startOfMonth  = $now->copy()->startOfMonth();
        $endOfMonth    = $now->copy()->endOfMonth();
        $startOfYear   = $now->copy()->startOfYear();
        $endOfYear     = $now->copy()->endOfYear();
        $prevMonthStart= $now->copy()->subMonth()->startOfMonth();
        $prevMonthEnd  = $now->copy()->subMonth()->endOfMonth();

        // =======================
        //  SUMMARY ANGKA ATAS
        // =======================

        // Total transaksi bulan ini (semua pemasukan + pengeluaran)
        $monthlyTransactions = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->whereBetween('tanggal_transaksi', [$startOfMonth, $endOfMonth])
            ->count();

        // Total transaksi tahun ini
        $yearlyTransactions = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->whereBetween('tanggal_transaksi', [$startOfYear, $endOfYear])
            ->count();

        // Rata-rata transaksi per hari bulan ini
        $daysInMonth = $now->daysInMonth;
        $averageDailyTransactions = $daysInMonth > 0
            ? round($monthlyTransactions / $daysInMonth, 1)
            : 0;

        // Growth rate vs bulan lalu (berdasarkan jumlah transaksi)
        $prevMonthTransactions = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->whereBetween('tanggal_transaksi', [$prevMonthStart, $prevMonthEnd])
            ->count();

        if ($prevMonthTransactions == 0) {
            $growthRate = $monthlyTransactions > 0 ? 100 : 0;
        } else {
            $growthRate = (($monthlyTransactions - $prevMonthTransactions) / $prevMonthTransactions) * 100;
        }

        // =======================
        //  CHART PENGELUARAN
        // =======================

        $pengeluaranQuery = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->whereBetween('tanggal_transaksi', [$startOfMonth, $endOfMonth])
            ->whereRaw('LOWER(jenis_catatan) = ?', ['pengeluaran'])
            ->selectRaw('COALESCE(NULLIF(deskripsi, ""), "Lainnya") as label, SUM(nominal) as total')
            ->groupBy('label')
            ->orderByDesc('total')
            ->take(4)
            ->get();

        if ($pengeluaranQuery->isEmpty()) {
            $chartPengeluaranLabels = ['Tidak ada data'];
            $chartPengeluaranData   = [0];
            $pengeluaranRingkasan   = collect();
        } else {
            $chartPengeluaranLabels = $pengeluaranQuery->pluck('label')->toArray();
            $chartPengeluaranData   = $pengeluaranQuery->pluck('total')->toArray();
            $pengeluaranRingkasan   = $pengeluaranQuery;
        }

        // =======================
        //  CHART PEMASUKAN PER MINGGU
        // =======================

        $pemasukanQuery = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->whereBetween('tanggal_transaksi', [$startOfMonth, $endOfMonth])
            ->whereRaw('LOWER(jenis_catatan) = ?', ['pemasukan'])
            ->selectRaw('WEEK(tanggal_transaksi, 1) as minggu, SUM(nominal) as total')
            ->groupBy('minggu')
            ->orderBy('minggu')
            ->get();

        $chartPemasukanLabels = [];
        $chartPemasukanData   = [];

        foreach ($pemasukanQuery as $index => $row) {
            $chartPemasukanLabels[] = 'Minggu ' . ($index + 1);
            $chartPemasukanData[]   = (float)$row->total;
        }

        if (empty($chartPemasukanLabels)) {
            $chartPemasukanLabels = ['Minggu 1', 'Minggu 2', 'Minggu 3', 'Minggu 4'];
            $chartPemasukanData   = [0, 0, 0, 0];
        }

        $pemasukanMaxValue = !empty($chartPemasukanData) ? max($chartPemasukanData) : 0;
        $pemasukanMaxIndex = array_search($pemasukanMaxValue, $chartPemasukanData);
        $pemasukanMaxLabel = $pemasukanMaxIndex !== false
            ? $chartPemasukanLabels[$pemasukanMaxIndex]
            : '–';

        $pemasukanAveragePerWeek = !empty($chartPemasukanData)
            ? round(array_sum($chartPemasukanData) / max(count($chartPemasukanData), 1), 2)
            : 0;

        return view('dashboard', [
            'monthlyTransactions'      => $monthlyTransactions,
            'yearlyTransactions'       => $yearlyTransactions,
            'averageDailyTransactions' => $averageDailyTransactions,
            'growthRate'               => $growthRate,

            'chartPengeluaranLabels'   => $chartPengeluaranLabels,
            'chartPengeluaranData'     => $chartPengeluaranData,
            'pengeluaranRingkasan'     => $pengeluaranRingkasan,

            'chartPemasukanLabels'     => $chartPemasukanLabels,
            'chartPemasukanData'       => $chartPemasukanData,
            'pemasukanMaxLabel'        => $pemasukanMaxLabel,
            'pemasukanMaxValue'        => $pemasukanMaxValue,
            'pemasukanAveragePerWeek'  => $pemasukanAveragePerWeek,
        ]);
    }
}
