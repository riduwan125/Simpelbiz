<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\QrLogin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

class QRLoginController extends Controller
{
    public function showForgotForm()
    {
        return view('auth.forgot-password-qr');
    }

    public function showScanPage()
    {
        return view('auth.qr-scan');
    }

    // ================== KIRIM QR KE EMAIL ==================
    public function sendQrToEmail(Request $request)
    {
        $ALLOWED_DOMAINS = ['gmail.com'];

        $request->validate([
            'email' => [
                'required',
                'email:rfc,dns',
                function ($attr, $value, $fail) use ($ALLOWED_DOMAINS) {
                    $email  = strtolower(trim($value));
                    $domain = substr(strrchr($email, '@'), 1);

                    if (!in_array($domain, $ALLOWED_DOMAINS)) {
                        $fail('Gunakan email Gmail yang aktif.');
                    }
                },
            ],
        ]);

        $email = strtolower(trim($request->email));

        $user = User::where('email', $email)
            ->whereNotNull('email_verified_at')
            ->first();

        if (!$user) {
            return back()->withErrors([
                'email' => 'Email tidak terdaftar atau belum diverifikasi.',
            ])->withInput();
        }

        $rawToken  = Str::random(40);
        $encrypted = Crypt::encryptString($rawToken);

        QrLogin::create([
            'id_user'     => $user->id_user,
            'token_login' => $rawToken,
            'expires_at'  => now()->addMinutes(2),
            'used_at'     => null,
        ]);

        $qrCode = QrCode::create($encrypted)->setSize(260)->setMargin(10);
        $writer = new PngWriter();
        $result = $writer->write($qrCode);

        $tempPath = storage_path('app/public/qr_login_' . Str::random(10) . '.png');
        file_put_contents($tempPath, $result->getString());

        try {
            Mail::send('emails.qr-reset', [
                'user'    => $user,
                'qrPath'  => $tempPath,
                'expired' => now()->addMinutes(2)->format('d/m/Y H:i'),
            ], function ($message) use ($user, $tempPath) {
                $message->to($user->email)
                    ->subject('Login via QR Code - UMKM')
                    ->attach($tempPath, [
                        'as'   => 'qr-login.png',
                        'mime' => 'image/png',
                    ]);
            });

            if (file_exists($tempPath)) unlink($tempPath);

        } catch (\Throwable $e) {
            Log::error('Gagal kirim email QR Login: ' . $e->getMessage());
            if (file_exists($tempPath)) unlink($tempPath);

            return back()->withErrors([
                'email' => 'Gagal mengirim email. Coba lagi.',
            ]);
        }

        return back()->with('status', 'Kode QR sudah dikirim ke email.');
    }

    // ================== LOGIN DARI QR ==================
    public function login(Request $request)
    {
        $request->validate([
            'token' => 'required|string',
        ]);

        try {
            $rawToken = Crypt::decryptString($request->token);
        } catch (\Throwable) {
            return back()->with('error', 'QR Code tidak valid.');
        }

        $qr = QrLogin::where('token_login', $rawToken)->first();

        if (!$qr) {
            Log::warning('QR Login gagal: token tidak ditemukan', ['ip' => $request->ip()]);
            return back()->with('error', 'QR Code tidak terdaftar.');
        }

        if ($qr->used_at) {
            Log::warning('QR Login gagal: sudah digunakan', ['ip' => $request->ip()]);
            return back()->with('error', 'QR Code sudah pernah digunakan.');
        }

        if ($qr->expires_at < now()) {
            Log::warning('QR Login gagal: expired', ['ip' => $request->ip()]);
            return back()->with('error', 'QR Code sudah kedaluwarsa.');
        }

        $user = User::find($qr->id_user);
        if (!$user) {
            return back()->with('error', 'Pengguna tidak ditemukan.');
        }

        $qr->update(['used_at' => now()]);
        Auth::login($user);

        return redirect()->route('dashboard')
            ->with('success', 'Login berhasil menggunakan QR Code.');
    }

    // ================== GENERATE QR SAAT LOGIN ==================
    public function show()
    {
        $user = Auth::user();
        abort_if(!$user, 403);

        $rawToken  = Str::random(40);
        $encrypted = Crypt::encryptString($rawToken);

        QrLogin::create([
            'id_user'     => $user->id_user,
            'token_login' => $rawToken,
            'expires_at'  => now()->addMinutes(2),
        ]);

        $qr = QrCode::create($encrypted)->setSize(240)->setMargin(10);
        $img = base64_encode((new PngWriter())->write($qr)->getString());

        return view('auth.qr-reset', [
            'qrImage' => "data:image/png;base64,$img"
        ]);
    }
}
