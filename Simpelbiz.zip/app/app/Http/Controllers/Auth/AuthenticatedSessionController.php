<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Support\Str;

class AuthenticatedSessionController extends Controller
{
    /**
     * Tampilkan halaman login.
     */
    public function create()
    {
        return view('auth.login');
    }

    /**
     * Proses login pengguna.
     */
    public function store(Request $request)
    {
        // Normalisasi email biar konsisten
        $request->merge([
            'email' => strtolower(trim((string) $request->email)),
        ]);

        // ✅ Validasi basic (jangan pakai exists, biar pesan error konsisten)
        $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ], [
            'email.required' => 'Email wajib diisi.',
            'email.email'    => 'Format email tidak valid.',
            'password.required' => 'Password wajib diisi.',
        ]);

        // ✅ Batasi percobaan login
        $this->ensureIsNotRateLimited($request);

        // Coba login
        $remember = $request->boolean('remember');

        if (!Auth::attempt(['email' => $request->email, 'password' => $request->password], $remember)) {
            RateLimiter::hit($this->throttleKey($request));

            // ✅ INI yang bikin notif muncul di Blade ($errors->any())
            // Pakai pesan umum (lebih aman, tidak bocorkan email terdaftar/tidak)
            throw ValidationException::withMessages([
                'email' => 'Email atau kata sandi yang Anda masukkan salah.',
            ]);
        }

        // Reset hitungan rate limit
        RateLimiter::clear($this->throttleKey($request));

        $request->session()->regenerate();

        // ✅ Admin -> dashboard admin
        if ((int) (Auth::user()->is_admin ?? 0) === 1) {
            return redirect()->route('admin.dashboard');
        }

        // ✅ User biasa -> dashboard umum
        return redirect()->intended(route('dashboard', absolute: false));
    }

    /**
     * Logout dan hapus sesi login.
     */
    public function destroy(Request $request)
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }

    /**
     * Cegah brute force.
     */
    protected function ensureIsNotRateLimited(Request $request)
    {
        if (!RateLimiter::tooManyAttempts($this->throttleKey($request), 5)) {
            return;
        }

        event(new Lockout($request));

        $seconds = RateLimiter::availableIn($this->throttleKey($request));

        throw ValidationException::withMessages([
            'email' => "Terlalu banyak percobaan login. Coba lagi dalam $seconds detik.",
        ]);
    }

    protected function throttleKey(Request $request)
    {
        return Str::lower($request->input('email')).'|'.$request->ip();
    }
}
