<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Umkm;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class RegisteredUserController extends Controller
{
    /** Tampilkan form register */
    public function create()
    {
        return view('auth.register');
    }

    /** Proses registrasi user baru + data UMKM */
    public function store(Request $request)
    {
        // Normalisasi email
        $request->merge([
            'email' => strtolower(trim((string) $request->email)),
        ]);

        // Validasi
        $request->validate([
            'nama_user'   => ['required', 'string', 'max:255'],
            'nama_umkm'   => ['required', 'string', 'max:255'],
            'alamat_umkm' => ['required', 'string', 'max:255'],
            'jenis_usaha' => ['required', 'string', 'max:255'],
            'no_telepon'  => ['required', 'string', 'max:20'],
            'email'       => ['required', 'string', 'email', 'max:255', 'unique:users,email'],

            // ✅ Syarat dospem:
            // minimal 8, ada huruf besar, huruf kecil, angka, simbol
            'password' => [
                'required',
                'confirmed',
                Password::min(8)->mixedCase()->numbers()->symbols(),
            ],
        ], [
            'email.unique'          => 'Email sudah terdaftar.',
            'password.confirmed'    => 'Konfirmasi password tidak sama.',
            'password.min'          => 'Password minimal 8 karakter.',
        ]);

        // Simpan data dengan transaksi
        $user = DB::transaction(function () use ($request) {
            $user = User::create([
                'nama_user' => $request->nama_user,
                'email'     => $request->email,
                'password'  => Hash::make($request->password),
            ]);

            Umkm::create([
                'id_user'     => $user->id_user,
                'nama_umkm'   => $request->nama_umkm,
                'alamat_umkm' => $request->alamat_umkm,
                'jenis_usaha' => $request->jenis_usaha,
                'no_telepon'  => $request->no_telepon,
            ]);

            return $user;
        });

        // Event & login
        event(new Registered($user));
        Auth::login($user);

        return redirect()->route('dashboard');
    }
}
