<?php

namespace App\Http\Controllers;

use App\Models\CatatanKeuangan;
use App\Models\LaporanKeuangan;
use App\Models\LaporanKeuanganDetail;
use App\Models\ModalBeban;
use App\Models\Umkm;
use App\Models\User;
use App\Models\QrLaporan;
use App\Models\LaporanAccessPin;
use App\Mail\LaporanAccessPinMail;

use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class LaporanController extends Controller
{
    protected function getUmkm()
    {
        $user = Auth::user();
        return Umkm::where('id_user', $user->id_user)->firstOrFail();
    }

    protected function createOrRefreshQrToken(int $idLaporan): array
    {
        $rawToken = Str::random(60);
        $stored   = hash('sha256', $rawToken);

        $qr = QrLaporan::updateOrCreate(
            ['id_laporan' => $idLaporan],
            ['token_akses' => $stored]
        );

        $qr->touch();

        $accessUrl = route('laporan.access.email.token', $rawToken);

        return [
            'qr'  => $qr,
            'raw' => $rawToken,
            'url' => $accessUrl,
        ];
    }

    public function index(Request $request)
    {
        $umkm = $this->getUmkm();

        $laporanList = LaporanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->orderBy('tahun', 'desc')
            ->orderBy('bulan', 'desc')
            ->get();

        $namaBulan = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
        ];

        $bulanSelected = $request->input('bulan');
        $tahunSelected = $request->input('tahun');

        $catatanPreview = collect();
        $totalPemasukanPreview = 0;
        $totalPengeluaranPreview = 0;
        $modalUsahaPreview = 0;
        $bebanOperasionalPreview = 0;
        $labaKotorPreview = 0;
        $labaBersihPreview = 0;

        if ($bulanSelected && $tahunSelected) {
            $bulanSelected = (int)$bulanSelected;
            $tahunSelected = (int)$tahunSelected;

            $startDate = Carbon::create($tahunSelected, $bulanSelected, 1)->startOfDay();
            $endDate   = (clone $startDate)->endOfMonth()->endOfDay();

            $catatanPreview = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
                ->whereBetween('tanggal_transaksi', [$startDate, $endDate])
                ->orderBy('tanggal_transaksi')
                ->get();

            $totalPemasukanPreview = $catatanPreview->filter(fn($c) => strtolower($c->jenis_catatan) === 'pemasukan')->sum('nominal');
            $totalPengeluaranPreview = $catatanPreview->filter(fn($c) => strtolower($c->jenis_catatan) === 'pengeluaran')->sum('nominal');

            $modalUsahaPreview = ModalBeban::where('id_umkm', $umkm->id_umkm)
                ->where('jenis', 'modal_usaha')
                ->whereBetween('tanggal_transaksi', [$startDate, $endDate])
                ->sum('nominal');

            $bebanOperasionalPreview = ModalBeban::where('id_umkm', $umkm->id_umkm)
                ->where('jenis', 'beban_operasional')
                ->whereBetween('tanggal_transaksi', [$startDate, $endDate])
                ->sum('nominal');

            $labaKotorPreview  = $totalPemasukanPreview - $totalPengeluaranPreview;
            $labaBersihPreview = $labaKotorPreview - $bebanOperasionalPreview;
        }

        return view('laporan.index', compact(
            'laporanList',
            'namaBulan',
            'bulanSelected',
            'tahunSelected',
            'catatanPreview',
            'totalPemasukanPreview',
            'totalPengeluaranPreview',
            'modalUsahaPreview',
            'bebanOperasionalPreview',
            'labaKotorPreview',
            'labaBersihPreview'
        ));
    }

    public function export(Request $request)
    {
        $request->validate([
            'bulan'    => 'required|integer|min:1|max:12',
            'tahun'    => 'required|integer|min:2000',
            'filename' => 'required|string|min:3|max:80',
        ]);

        $bulan = (int)$request->bulan;
        $tahun = (int)$request->tahun;

        $umkm = $this->getUmkm();

        $startDate = Carbon::create($tahun, $bulan, 1)->startOfDay();
        $endDate   = (clone $startDate)->endOfMonth()->endOfDay();

        $catatan = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->whereBetween('tanggal_transaksi', [$startDate, $endDate])
            ->orderBy('tanggal_transaksi')
            ->get();

        if ($catatan->isEmpty()) {
            return redirect()
                ->route('laporan.index', ['bulan' => $bulan, 'tahun' => $tahun])
                ->with('error', 'Tidak ada catatan keuangan pada periode tersebut.');
        }

        $totalPemasukan   = $catatan->filter(fn($c) => strtolower($c->jenis_catatan) === 'pemasukan')->sum('nominal');
        $totalPengeluaran = $catatan->filter(fn($c) => strtolower($c->jenis_catatan) === 'pengeluaran')->sum('nominal');

        $modalUsaha = ModalBeban::where('id_umkm', $umkm->id_umkm)
            ->where('jenis', 'modal_usaha')
            ->whereBetween('tanggal_transaksi', [$startDate, $endDate])
            ->sum('nominal');

        $bebanOperasional = ModalBeban::where('id_umkm', $umkm->id_umkm)
            ->where('jenis', 'beban_operasional')
            ->whereBetween('tanggal_transaksi', [$startDate, $endDate])
            ->sum('nominal');

        $labaKotor  = $totalPemasukan - $totalPengeluaran;
        $labaBersih = $labaKotor - $bebanOperasional;

        $filenameRaw = trim($request->filename);
        $safe = preg_replace('/[^A-Za-z0-9_\-]/', '_', $filenameRaw);
        $safe = preg_replace('/_+/', '_', $safe);
        $safe = trim($safe, '_-');

        if ($safe === '') {
            $safe = "laporan_{$tahun}_" . str_pad($bulan, 2, '0', STR_PAD_LEFT);
        }

        $laporanPdfName = $safe . '.pdf';
        $qrPdfName      = 'qr_only_' . $safe . '.pdf';

        $baseName = 'laporan_' . $umkm->id_umkm . '_' . $tahun . '_' . str_pad($bulan, 2, '0', STR_PAD_LEFT);
        $qrName   = 'qr_' . $baseName . '.png';

        return DB::transaction(function () use (
            $umkm, $bulan, $tahun, $catatan,
            $laporanPdfName, $qrPdfName, $qrName,
            $totalPemasukan, $totalPengeluaran, $modalUsaha, $bebanOperasional, $labaKotor, $labaBersih
        ) {
            $laporan = LaporanKeuangan::where('id_umkm', $umkm->id_umkm)
                ->where('bulan', $bulan)
                ->where('tahun', $tahun)
                ->first();

            if ($laporan) {
                if ($laporan->path_pdf && $laporan->path_pdf !== $laporanPdfName) {
                    $old = 'laporan/' . $laporan->path_pdf;
                    if (Storage::disk('public')->exists($old)) {
                        Storage::disk('public')->delete($old);
                    }
                }

                if (Schema::hasColumn('laporan_keuangan', 'path_qr_pdf')) {
                    if ($laporan->path_qr_pdf && $laporan->path_qr_pdf !== $qrPdfName) {
                        $oldQr = 'laporan/' . $laporan->path_qr_pdf;
                        if (Storage::disk('public')->exists($oldQr)) {
                            Storage::disk('public')->delete($oldQr);
                        }
                    }
                }

                $updateData = ['path_pdf' => $laporanPdfName];
                if (Schema::hasColumn('laporan_keuangan', 'path_qr_pdf')) {
                    $updateData['path_qr_pdf'] = $qrPdfName;
                }
                $laporan->update($updateData);

                if (Schema::hasTable('laporan_keuangan_detail')) {
                    DB::table('laporan_keuangan_detail')
                        ->where('laporan_id', $laporan->id_laporan)
                        ->delete();
                }
            } else {
                $createData = [
                    'id_umkm'  => $umkm->id_umkm,
                    'bulan'    => $bulan,
                    'tahun'    => $tahun,
                    'path_pdf' => $laporanPdfName,
                ];

                if (Schema::hasColumn('laporan_keuangan', 'path_qr_pdf')) {
                    $createData['path_qr_pdf'] = $qrPdfName;
                }

                $laporan = LaporanKeuangan::create($createData);
            }

            if (Schema::hasTable('laporan_keuangan_detail')) {
                $now = now();
                $rows = [];

                foreach ($catatan as $row) {
                    $rows[] = [
                        'laporan_id'        => $laporan->id_laporan,
                        'tanggal_transaksi' => $row->tanggal_transaksi,
                        'jenis_catatan'     => $row->jenis_catatan,
                        'deskripsi'         => $row->deskripsi,
                        'jumlah'            => $row->jumlah ?? 0,
                        'nominal'           => $row->nominal ?? 0,
                        'created_at'        => $now,
                        'updated_at'        => $now,
                    ];
                }

                if (!empty($rows)) {
                    DB::table('laporan_keuangan_detail')->insert($rows);
                }
            }

            $qrData    = $this->createOrRefreshQrToken($laporan->id_laporan);
            $accessUrl = $qrData['url'];

            $qrPngBinary = QrCode::format('png')->size(700)->margin(2)->generate($accessUrl);
            Storage::disk('public')->put('laporan/' . $qrName, $qrPngBinary);
            $qrPngBase64 = base64_encode($qrPngBinary);

            $pdfLaporan = Pdf::loadView('laporan.export', [
                'umkm'             => $umkm,
                'bulan'            => $bulan,
                'tahun'            => $tahun,
                'catatan'          => $catatan,
                'totalPemasukan'   => $totalPemasukan,
                'totalPengeluaran' => $totalPengeluaran,
                'modalUsaha'       => $modalUsaha,
                'bebanOperasional' => $bebanOperasional,
                'labaKotor'        => $labaKotor,
                'labaBersih'       => $labaBersih,
            ])->setPaper('a4', 'portrait');

            Storage::disk('public')->put('laporan/' . $laporanPdfName, $pdfLaporan->output());

            $pdfQr = Pdf::loadView('laporan.qr_pdf', [
                'laporan'     => $laporan,
                'umkm'        => $umkm,
                'accessUrl'   => $accessUrl,
                'qrPngBase64' => $qrPngBase64,
            ])->setPaper('a4', 'portrait');

            Storage::disk('public')->put('laporan/' . $qrPdfName, $pdfQr->output());

            return response()->download(
                storage_path('app/public/laporan/' . $qrPdfName),
                $qrPdfName,
                ['Content-Type' => 'application/pdf']
            );
        });
    }

    public function refreshQr($id)
    {
        $umkm = $this->getUmkm();

        $laporan = LaporanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->where('id_laporan', $id)
            ->firstOrFail();

        $tahun = (int)$laporan->tahun;
        $bulan = (int)$laporan->bulan;

        $baseName = 'laporan_' . $laporan->id_umkm . '_' . $tahun . '_' . str_pad($bulan, 2, '0', STR_PAD_LEFT);
        $qrName   = 'qr_' . $baseName . '.png';

        $qrData    = $this->createOrRefreshQrToken($laporan->id_laporan);
        $accessUrl = $qrData['url'];

        $qrPngBinary = QrCode::format('png')->size(700)->margin(1)->generate($accessUrl);
        Storage::disk('public')->put('laporan/' . $qrName, $qrPngBinary);

        return back()->with('success', 'QR laporan berhasil diperbarui. Masa berlaku 5 hari dihitung dari sekarang.');
    }

    public function downloadQrPng($id)
    {
        $laporan = LaporanKeuangan::findOrFail($id);

        $baseName = 'laporan_' . $laporan->id_umkm . '_' . $laporan->tahun . '_' . str_pad($laporan->bulan, 2, '0', STR_PAD_LEFT);
        $qrName   = 'qr_' . $baseName . '.png';
        $relative = 'laporan/' . $qrName;

        if (!Storage::disk('public')->exists($relative)) {
            abort(404, 'File QR tidak ditemukan.');
        }

        return response()->download(
            storage_path('app/public/' . $relative),
            $qrName,
            ['Content-Type' => 'image/png']
        );
    }

    public function showEmailFormByToken(string $token)
    {
        $hashed = hash('sha256', $token);

        $qr = QrLaporan::where('token_akses', $hashed)->first();

        if (!$qr) {
            return view('laporan.qr_invalid');
        }

        if (!$qr->updated_at || $qr->updated_at->copy()->addDays(5)->isPast()) {
            return view('laporan.qr_expired');
        }

        $laporan = LaporanKeuangan::find($qr->id_laporan);

        if (!$laporan) {
            return view('laporan.qr_invalid');
        }

        return view('laporan.access_email', [
            'laporan' => $laporan,
            'token'   => $token,
        ]);
    }

    public function requestPinByToken(Request $request)
    {
        $data = $request->validate([
            'token' => 'required|string',
            'email' => 'required|email',
        ]);

        $hashed = hash('sha256', $data['token']);
        $qr = QrLaporan::where('token_akses', $hashed)->first();

        if (!$qr) {
            return back()->withErrors(['email' => 'QR laporan tidak valid.'])->withInput();
        }

        if (!$qr->updated_at || $qr->updated_at->copy()->addDays(5)->isPast()) {
            return back()->withErrors(['email' => 'QR laporan sudah kedaluwarsa.'])->withInput();
        }

        $request->merge(['laporan_id' => $qr->id_laporan]);

        return $this->requestPin($request);
    }

    public function requestPin(Request $request)
    {
        $data = $request->validate([
            'laporan_id' => 'required|integer|exists:laporan_keuangan,id_laporan',
            'email'      => 'required|email',
        ]);

        $laporan = LaporanKeuangan::findOrFail($data['laporan_id']);
        $umkm    = Umkm::where('id_umkm', $laporan->id_umkm)->firstOrFail();
        $user    = User::where('id_user', $umkm->id_user)->firstOrFail();

        $emailInput   = strtolower(trim($data['email']));
        $emailPemilik = strtolower(trim($user->email));

        if ($emailInput !== $emailPemilik) {
            return back()
                ->withErrors(['email' => 'Email ini tidak terdaftar sebagai pemilik laporan.'])
                ->withInput();
        }

        $pin = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        $accessPin = LaporanAccessPin::create([
            'laporan_id' => $laporan->id_laporan,
            'email'      => $emailInput,
            'pin'        => $pin,
            'expires_at' => now()->addMinutes(2),
        ]);

        Mail::to($emailInput)->send(new LaporanAccessPinMail($accessPin));

        return redirect()
            ->route('laporan.access.pin-form', $accessPin->id)
            ->with('status', 'PIN sudah dikirim ke email Anda. Silakan cek inbox/spam.');
    }

    // ✅ showPinForm: cek expired & used_at sebelum tampil form
    // Jika tidak valid, kirim email & laporanId ke view pin_invalid
    // agar user bisa minta PIN baru tanpa scan QR ulang
public function showPinForm($access)
{
    $accessPin = LaporanAccessPin::with('laporan')->findOrFail($access);

    if ($accessPin->used_at) {
        return view('laporan.access_pin', [
            'accessPin' => $accessPin,
            'pinError'  => 'PIN ini sudah pernah digunakan.',
            'expired'   => true,
        ]);
    }

    if ($accessPin->expires_at->isPast()) {
        return view('laporan.access_pin', [
            'accessPin' => $accessPin,
            'pinError'  => 'PIN sudah kedaluwarsa (2 menit).',
            'expired'   => true,
        ]);
    }

    return view('laporan.access_pin', [
        'accessPin' => $accessPin,
        'pinError'  => null,
        'expired'   => false,
    ]);
}

    // ✅ resendPin: kirim ulang PIN baru ke email yang sama tanpa scan QR ulang
    public function resendPin(Request $request)
    {
        $data = $request->validate([
            'laporan_id' => 'required|integer|exists:laporan_keuangan,id_laporan',
            'email'      => 'required|email',
        ]);

        $laporan = LaporanKeuangan::findOrFail($data['laporan_id']);
        $umkm    = Umkm::where('id_umkm', $laporan->id_umkm)->firstOrFail();
        $user    = User::where('id_user', $umkm->id_user)->firstOrFail();

        $emailInput   = strtolower(trim($data['email']));
        $emailPemilik = strtolower(trim($user->email));

        // Validasi keamanan: pastikan email cocok dengan pemilik laporan
        if ($emailInput !== $emailPemilik) {
            abort(403, 'Email tidak valid.');
        }

        $pin = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        $accessPin = LaporanAccessPin::create([
            'laporan_id' => $laporan->id_laporan,
            'email'      => $emailInput,
            'pin'        => $pin,
            'expires_at' => now()->addMinutes(2),
        ]);

        Mail::to($emailInput)->send(new LaporanAccessPinMail($accessPin));

        return redirect()
            ->route('laporan.access.pin-form', $accessPin->id)
            ->with('status', 'PIN baru sudah dikirim ke email Anda. Silakan cek inbox/spam.');
    }

    // ✅ verifyPin: pakai DB transaction + lockForUpdate cegah race condition
    public function verifyPin(Request $request)
    {
        $data = $request->validate([
            'access_id' => 'required|integer|exists:laporan_access_pins,id',
            'pin'       => 'required|string|size:6',
        ]);

        return DB::transaction(function () use ($data) {
            $access = LaporanAccessPin::with('laporan')
                ->lockForUpdate()
                ->findOrFail($data['access_id']);

            if ($access->used_at) {
                return back()->withErrors(['pin' => 'PIN sudah pernah digunakan. Silakan minta PIN baru.']);
            }

            if ($access->expires_at->isPast()) {
                return back()->withErrors(['pin' => 'PIN sudah kedaluwarsa. Silakan minta PIN baru.']);
            }

            if ($access->pin !== $data['pin']) {
                return back()->withErrors(['pin' => 'PIN tidak valid.']);
            }

            $access->update(['used_at' => now()]);

            return redirect()->route('laporan.download.public', $access->laporan_id);
        });
    }

    public function downloadPublic($id)
    {
        $laporan = LaporanKeuangan::findOrFail($id);

        if (!$laporan->path_pdf) {
            abort(404, 'File laporan tidak ditemukan (path_pdf kosong).');
        }

        $relativePath = 'laporan/' . $laporan->path_pdf;

        if (!Storage::disk('public')->exists($relativePath)) {
            abort(404, 'File laporan tidak ditemukan.');
        }

        return response()->download(
            storage_path('app/public/' . $relativePath),
            $laporan->path_pdf,
            ['Content-Type' => 'application/pdf']
        );
    }

    public function destroy($id)
    {
        $umkm = $this->getUmkm();

        $laporan = LaporanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->where('id_laporan', $id)
            ->firstOrFail();

        if ($laporan->path_pdf && Storage::disk('public')->exists('laporan/' . $laporan->path_pdf)) {
            Storage::disk('public')->delete('laporan/' . $laporan->path_pdf);
        }

        if (Schema::hasColumn('laporan_keuangan', 'path_qr_pdf')) {
            if ($laporan->path_qr_pdf && Storage::disk('public')->exists('laporan/' . $laporan->path_qr_pdf)) {
                Storage::disk('public')->delete('laporan/' . $laporan->path_qr_pdf);
            }
        }

        $baseName = 'laporan_' . $laporan->id_umkm . '_' . $laporan->tahun . '_' . str_pad($laporan->bulan, 2, '0', STR_PAD_LEFT);
        $qrName = 'qr_' . $baseName . '.png';
        if (Storage::disk('public')->exists('laporan/' . $qrName)) {
            Storage::disk('public')->delete('laporan/' . $qrName);
        }

        if (Schema::hasTable('laporan_keuangan_detail')) {
            DB::table('laporan_keuangan_detail')->where('laporan_id', $laporan->id_laporan)->delete();
        }

        if (Schema::hasTable('qr_laporan')) {
            DB::table('qr_laporan')->where('id_laporan', $laporan->id_laporan)->delete();
        }

        $laporan->delete();

        return redirect()->route('laporan.index')->with('success', 'Laporan berhasil dihapus.');
    }

    public function detail(Request $request)
    {
        $request->validate([
            'id'    => 'required|integer|exists:laporan_keuangan,id_laporan',
            'bulan' => 'required|integer|min:1|max:12',
            'tahun' => 'required|integer|min:2000',
        ]);

        $bulan = (int)$request->bulan;
        $tahun = (int)$request->tahun;

        $umkm = $this->getUmkm();

        $laporan = LaporanKeuangan::where('id_laporan', $request->id)
            ->where('id_umkm', $umkm->id_umkm)
            ->firstOrFail();

        $catatan = collect();

        if (Schema::hasTable('laporan_keuangan_detail')) {
            $catatan = LaporanKeuanganDetail::where('laporan_id', $laporan->id_laporan)
                ->orderBy('tanggal_transaksi')
                ->get();
        }

        if ($catatan->isEmpty()) {
            return view('laporan.detail', [
                'laporan'          => $laporan,
                'catatan'          => $catatan,
                'bulan'            => $bulan,
                'tahun'            => $tahun,
                'totalPemasukan'   => 0,
                'totalPengeluaran' => 0,
                'warningSnapshot'  => 'Detail laporan ini belum tersimpan (snapshot belum ada). Pastikan tabel laporan_keuangan_detail sudah migrate, lalu export ulang periode ini.',
            ]);
        }

        $totalPemasukan   = $catatan->filter(fn($c) => strtolower($c->jenis_catatan) === 'pemasukan')->sum('nominal');
        $totalPengeluaran = $catatan->filter(fn($c) => strtolower($c->jenis_catatan) === 'pengeluaran')->sum('nominal');

        return view('laporan.detail', [
            'laporan'          => $laporan,
            'catatan'          => $catatan,
            'bulan'            => $bulan,
            'tahun'            => $tahun,
            'totalPemasukan'   => $totalPemasukan,
            'totalPengeluaran' => $totalPengeluaran,
            'warningSnapshot'  => null,
        ]);
    }
}