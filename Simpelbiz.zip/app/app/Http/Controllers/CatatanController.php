<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CatatanKeuangan;
use App\Models\Umkm;
use App\Models\SatuanUmkm;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class CatatanController extends Controller
{
    public function index()
    {
        $umkm = Umkm::where('id_user', Auth::user()->id_user)->first();

        if (!$umkm) {
            return redirect()->route('dashboard')
                ->with('error', 'Data UMKM tidak ditemukan untuk akun ini.');
        }

        $catatan = CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->orderBy('tanggal_transaksi', 'desc')
            ->get();

        return view('catatan.index', compact('catatan'));
    }

    public function create()
    {
        $satuan = SatuanUmkm::orderBy('nama_satuan', 'asc')->get();

        return view('catatan.create', compact('satuan'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'jenis_catatan'     => 'required|string|max:50',
            'deskripsi'         => 'nullable|string',
            'jumlah'            => 'required|numeric|min:1',
            'harga_satuan'      => 'required',
            'satuan'            => 'required|string|max:50',
            'tanggal_transaksi' => 'required|date',
        ]);

        $umkm = Umkm::where('id_user', Auth::user()->id_user)->first();

        if (!$umkm) {
            return redirect()->back()->with('error', 'Data UMKM tidak ditemukan.');
        }

        $harga        = preg_replace('/[^0-9]/', '', $validated['harga_satuan']);
        $jumlah       = (float) $validated['jumlah'];
        $totalNominal = $jumlah * (float) $harga;

        // Jika tanggal yang dipilih adalah hari ini, gunakan waktu sekarang (now())
        // agar diffForHumans() tampil akurat ("beberapa detik yang lalu")
        $tanggalDipilih = Carbon::parse($validated['tanggal_transaksi'])->startOfDay();
        $hariIni        = Carbon::now()->startOfDay();

        if ($tanggalDipilih->equalTo($hariIni)) {
            $tanggalTransaksi = Carbon::now(); // pakai datetime penuh sekarang
        } else {
            $tanggalTransaksi = $tanggalDipilih; // pakai tanggal yang dipilih
        }

        CatatanKeuangan::create([
            'id_umkm'           => $umkm->id_umkm,
            'jenis_catatan'     => $validated['jenis_catatan'],
            'deskripsi'         => $validated['deskripsi'] ?? '-',
            'jumlah'            => $jumlah,
            'satuan'            => $validated['satuan'],
            'nominal'           => $totalNominal,
            'tanggal_transaksi' => $tanggalTransaksi,
        ]);

        return redirect()
            ->route('catatan.index')
            ->with('success', 'Catatan keuangan berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $catatan = CatatanKeuangan::findOrFail($id);
        $satuan  = SatuanUmkm::orderBy('nama_satuan', 'asc')->get();

        return view('catatan.edit', compact('catatan', 'satuan'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'jenis_catatan'     => 'required|string|max:50',
            'deskripsi'         => 'nullable|string',
            'jumlah'            => 'required|numeric|min:1',
            'harga_satuan'      => 'required',
            'satuan'            => 'required|string|max:50',
            'tanggal_transaksi' => 'required|date',
        ]);

        $catatan = CatatanKeuangan::findOrFail($id);

        $harga        = preg_replace('/[^0-9]/', '', $validated['harga_satuan']);
        $jumlah       = (float) $validated['jumlah'];
        $totalNominal = $jumlah * (float) $harga;

        // Sama seperti store: jika tanggal hari ini, simpan dengan waktu sekarang
        $tanggalDipilih = Carbon::parse($validated['tanggal_transaksi'])->startOfDay();
        $hariIni        = Carbon::now()->startOfDay();

        if ($tanggalDipilih->equalTo($hariIni)) {
            $tanggalTransaksi = Carbon::now();
        } else {
            $tanggalTransaksi = $tanggalDipilih;
        }

        $catatan->update([
            'jenis_catatan'     => $validated['jenis_catatan'],
            'deskripsi'         => $validated['deskripsi'] ?? '-',
            'jumlah'            => $jumlah,
            'satuan'            => $validated['satuan'],
            'nominal'           => $totalNominal,
            'tanggal_transaksi' => $tanggalTransaksi,
        ]);

        return redirect()
            ->route('catatan.index')
            ->with('success', 'Catatan keuangan berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $catatan = CatatanKeuangan::findOrFail($id);
        $catatan->delete();

        return redirect()
            ->route('catatan.index')
            ->with('success', 'Catatan keuangan berhasil dihapus.');
    }

    public function show($id)
    {
        $catatan = CatatanKeuangan::findOrFail($id);
        return view('catatan.show', compact('catatan'));
    }
}