<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SatuanUmkm;
use App\Models\Umkm;
use Illuminate\Support\Facades\Auth;

class SatuanController extends Controller
{
    /**
     * Tambah satuan baru (per UMKM)
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama_satuan' => 'required|string|max:50',
        ]);

        $umkm = Umkm::where('id_user', Auth::user()->id_user)->first();

        if (!$umkm) {
            return response()->json(['error' => 'Data UMKM tidak ditemukan.'], 500);
        }

        // Cegah duplikasi nama di UMKM yang sama (case-insensitive)
        $exists = SatuanUmkm::where('id_umkm', $umkm->id_umkm)
            ->whereRaw('LOWER(nama_satuan) = ?', [strtolower($request->nama_satuan)])
            ->exists();

        if ($exists) {
            return response()->json([
                'error' => 'Satuan sudah ada dalam daftar UMKM Anda.'
            ], 422);
        }

        $satuan = SatuanUmkm::create([
            'id_umkm'     => $umkm->id_umkm,
            'nama_satuan' => ucfirst(strtolower($request->nama_satuan)),
        ]);

        return response()->json($satuan, 201);
    }

    /**
     * Update satuan milik UMKM login
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_satuan' => 'required|string|max:50',
        ]);

        $umkm = Umkm::where('id_user', Auth::user()->id_user)->first();

        if (!$umkm) {
            return response()->json(['error' => 'Data UMKM tidak ditemukan.'], 500);
        }

        $satuan = SatuanUmkm::where('id_umkm', $umkm->id_umkm)->findOrFail($id);

        // Cek apakah nama sudah dipakai oleh satuan lain (case-insensitive)
        $exists = SatuanUmkm::where('id_umkm', $umkm->id_umkm)
            ->where('id_satuan', '!=', $id)
            ->whereRaw('LOWER(nama_satuan) = ?', [strtolower($request->nama_satuan)])
            ->exists();

        if ($exists) {
            return response()->json(['error' => 'Nama satuan sudah digunakan.'], 422);
        }

        $satuan->update([
            'nama_satuan' => ucfirst(strtolower($request->nama_satuan)),
        ]);

        return response()->json(['success' => 'Nama satuan berhasil diperbarui.']);
    }

    /**
     * Hapus satuan milik UMKM login
     */
    public function destroy($id)
    {
        $umkm = Umkm::where('id_user', Auth::user()->id_user)->first();

        if (!$umkm) {
            return response()->json(['error' => 'Data UMKM tidak ditemukan.'], 500);
        }

        $satuan = SatuanUmkm::where('id_umkm', $umkm->id_umkm)->findOrFail($id);

        // (OPSIONAL) Kalau mau larang hapus jika sedang dipakai catatan_keuangan:
        /*
        $dipakai = \App\Models\CatatanKeuangan::where('id_umkm', $umkm->id_umkm)
            ->where('satuan', $satuan->nama_satuan)
            ->exists();

        if ($dipakai) {
            return response()->json([
                'error' => 'Satuan sedang dipakai di catatan keuangan, tidak bisa dihapus.'
            ], 422);
        }
        */

        $satuan->delete();

        return response()->json(['success' => 'Satuan berhasil dihapus.']);
    }
}
