<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Umkm;

class UmkmController extends Controller
{
    /**
     * Tampilkan daftar semua UMKM (dengan fitur pencarian & nama pemilik).
     */
    public function index(Request $request)
    {
        $search = $request->query('q');

        $umkms = Umkm::with('user') // ✅ muat relasi user (pemilik)
            ->when($search, function ($query) use ($search) {
                $query->where('nama_umkm', 'like', "%$search%")
                    ->orWhereHas('user', function ($q) use ($search) {
                        $q->where('nama_user', 'like', "%$search%");
                    });
            })
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('admin.umkm.index', compact('umkms', 'search'));
    }

    /**
     * Tampilkan detail 1 UMKM beserta catatan keuangan-nya.
     */
    public function show($id)
    {
        $umkm = Umkm::with(['user', 'catatanKeuangan'])->findOrFail($id);
        return view('admin.umkm.show', compact('umkm'));
    }
}
