<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\QRLoginController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PenggunaController;
use App\Http\Controllers\CatatanController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\SatuanController;
use App\Http\Controllers\Admin\UmkmController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ModalBebanController;

use App\Models\Umkm;
use App\Models\CatatanKeuangan;

/*
|--------------------------------------------------------------------------
| Web Routes - Aplikasi UMKM
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('welcome');
})->name('home');


/* =========================
| Dashboard
========================= */
Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');


/* =========================
| Group USER (auth + verified)
========================= */
Route::middleware(['auth', 'verified'])->group(function () {

    /* ---- Modul Pengguna ---- */
    Route::get('/pengguna', [PenggunaController::class, 'index'])->name('pengguna.index');
    Route::get('/pengguna/edit/{id}', [PenggunaController::class, 'edit'])->name('pengguna.edit');
    Route::patch('/pengguna/update/{id}', [PenggunaController::class, 'update'])->name('pengguna.update');

    /* ---- Modul Catatan Keuangan ---- */
    Route::get('/catatan-keuangan', [CatatanController::class, 'index'])->name('catatan.index');
    Route::get('/catatan-keuangan/tambah', [CatatanController::class, 'create'])->name('catatan.create');
    Route::post('/catatan-keuangan/simpan', [CatatanController::class, 'store'])->name('catatan.store');
    Route::get('/catatan-keuangan/{id}', [CatatanController::class, 'show'])->name('catatan.show');
    Route::get('/catatan-keuangan/{id}/edit', [CatatanController::class, 'edit'])->name('catatan.edit');
    Route::put('/catatan-keuangan/{id}', [CatatanController::class, 'update'])->name('catatan.update');
    Route::delete('/catatan-keuangan/{id}', [CatatanController::class, 'destroy'])->name('catatan.destroy');

    /* ---- Modul Satuan ---- */
    Route::post('/satuan', [SatuanController::class, 'store'])->name('satuan.store');
    Route::put('/satuan/{id}', [SatuanController::class, 'update'])->name('satuan.update');
    Route::delete('/satuan/{id}', [SatuanController::class, 'destroy'])->name('satuan.destroy');

    /* ---- Modul Modal & Beban ---- */
    Route::get('/modal-beban', [ModalBebanController::class, 'index'])->name('modal-beban.index');
    Route::get('/modal-beban/create', [ModalBebanController::class, 'create'])->name('modal-beban.create');
    Route::post('/modal-beban', [ModalBebanController::class, 'store'])->name('modal-beban.store');
    Route::get('/modal-beban/{id}/edit', [ModalBebanController::class, 'edit'])->name('modal-beban.edit');
    Route::put('/modal-beban/{id}', [ModalBebanController::class, 'update'])->name('modal-beban.update');
    Route::delete('/modal-beban/{id}', [ModalBebanController::class, 'destroy'])->name('modal-beban.destroy');

    /* ---- Modul Laporan (internal) ---- */
    Route::get('/laporan-keuangan', [LaporanController::class, 'index'])->name('laporan.index');

    Route::post('/laporan-keuangan/export', [LaporanController::class, 'export'])
        ->name('laporan.export');

    Route::get('/laporan-keuangan/export', [LaporanController::class, 'export'])
        ->name('laporan.export.get');

    Route::get('/laporan-keuangan/detail', [LaporanController::class, 'detail'])
        ->name('laporan.detail');

    Route::delete('/laporan-keuangan/{id}', [LaporanController::class, 'destroy'])
        ->whereNumber('id')
        ->name('laporan.destroy');

    Route::post('/laporan-keuangan/{id}/refresh-qr', [LaporanController::class, 'refreshQr'])
        ->whereNumber('id')
        ->name('laporan.qr.refresh');

    Route::get('/laporan-keuangan/{id}/qr-download', [LaporanController::class, 'downloadQrPng'])
        ->whereNumber('id')
        ->name('laporan.qr.download');
});


/* =========================
| PUBLIK: Akses Laporan via QR Token (tanpa login)
| QR -> /laporan/qr/{token} -> input email -> kirim PIN -> input PIN -> download
========================= */

// Halaman input email dari QR token
Route::get('/laporan/qr/{token}', [LaporanController::class, 'showEmailFormByToken'])
    ->name('laporan.access.email.token');

// Kirim PIN (token)
Route::post('/laporan/qr/request-pin', [LaporanController::class, 'requestPinByToken'])
    ->name('laporan.access.pin.request.token');

// ✅ HARUS DI ATAS route legacy /laporan-keuangan/akses/{id}
// agar tidak tertimpa oleh wildcard {id}

// Form input PIN
Route::get('/laporan-keuangan/akses/pin/{accessId}', [LaporanController::class, 'showPinForm'])
    ->whereNumber('accessId')
    ->name('laporan.access.pin-form');

// Verifikasi PIN
Route::post('/laporan-keuangan/akses/verify-pin', [LaporanController::class, 'verifyPin'])
    ->name('laporan.access.verify-pin');

// Kirim ulang PIN baru (tanpa scan QR ulang)
Route::post('/laporan/pin/resend', [LaporanController::class, 'resendPin'])
    ->name('laporan.access.pin.resend');

// Download PDF laporan (public)
Route::get('/laporan-keuangan/download/{id}', [LaporanController::class, 'downloadPublic'])
    ->whereNumber('id')
    ->name('laporan.download.public');


/* =========================
| LEGACY: Akses Laporan via ID (QR lama)
| ✅ Harus di BAWAH route /akses/pin dan /akses/verify-pin
| agar wildcard {id} tidak menangkap segment 'pin' atau 'verify-pin'
========================= */

Route::get('/laporan-keuangan/akses/{id}', [LaporanController::class, 'showEmailForm'])
    ->whereNumber('id')
    ->name('laporan.access.email');

Route::post('/laporan-keuangan/akses/request-pin', [LaporanController::class, 'requestPin'])
    ->name('laporan.access.request-pin');


/* =========================
| LOGIN via QR CODE
========================= */

Route::get('/forgot-password-qr', [QRLoginController::class, 'showForgotForm'])
    ->name('qr.forgot.form')
    ->middleware('guest');

Route::post('/forgot-password-qr', [QRLoginController::class, 'sendQrToEmail'])
    ->name('qr.send')
    ->middleware(['guest', 'throttle:10,1']);

Route::get('/forgot-qr', [QRLoginController::class, 'showScanPage'])
    ->name('qr.forgot')
    ->middleware('guest');

Route::post('/forgot-qr', [QRLoginController::class, 'login'])
    ->name('qr.login')
    ->middleware(['guest', 'throttle:30,1']);

Route::get('/my-qr', [QRLoginController::class, 'show'])
    ->name('my-qr')
    ->middleware('auth');


/* =========================
| Profil
========================= */
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');

    Route::put('/profile/password', [ProfileController::class, 'updatePassword'])
        ->name('profile.password.update');

    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});


/* =========================
| Admin
========================= */
Route::middleware(['auth', 'verified', 'is_admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::get('/dashboard', function () {

            $totalUmkmVerified = Umkm::whereHas('user', function ($q) {
                $q->whereNotNull('email_verified_at');
            })->count();

            $totalUmkmNonVerified = Umkm::whereHas('user', function ($q) {
                $q->whereNull('email_verified_at');
            })->count();

            $tanggalMulai = now()->subDays(30)->toDateString();

            $totalUmkmAktif = Umkm::whereHas('catatanKeuangan', function ($q) use ($tanggalMulai) {
                $q->where('tanggal_transaksi', '>=', $tanggalMulai);
            })->count();

            return view('admin.dashboard', [
                'totalUmkmAktif'       => $totalUmkmAktif,
                'totalUmkmVerified'    => $totalUmkmVerified,
                'totalUmkmNonVerified' => $totalUmkmNonVerified,
                'totalCatatan'         => CatatanKeuangan::count(),
            ]);
        })->name('dashboard');

        Route::get('/umkm', [UmkmController::class, 'index'])->name('umkm.index');
        Route::get('/umkm/{id}', [UmkmController::class, 'show'])
            ->whereNumber('id')
            ->name('umkm.show');
    });


/* =========================
| Auth Routes (Breeze)
========================= */
require __DIR__ . '/auth.php';