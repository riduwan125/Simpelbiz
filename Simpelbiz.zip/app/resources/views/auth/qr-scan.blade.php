<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Scan QR Code - UMKM Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js"></script>
    <style>
        @keyframes scan-line {
            0%, 100% { transform: translateY(-100%); }
            50% { transform: translateY(100%); }
        }
        .scan-animation { animation: scan-line 2s ease-in-out infinite; }
        
        #reader {
            position: relative;
            width: 100%;
        }
        #reader video {
            width: 100% !important;
            height: auto !important;
            border-radius: 12px;
        }
        #reader__scan_region {
            border-radius: 12px !important;
        }

        /* Custom styles untuk tampilan seperti gambar */
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex items-center justify-center px-4 py-8">

<div class="w-full max-w-md">

    <!-- 🔔 NOTIFIKASI DARI CONTROLLER -->
    @if(session('error'))
    <div class="mb-4 p-4 rounded-lg bg-red-500 text-white shadow-sm">
        ❌ {{ session('error') }}
    </div>
    @endif

    @if(session('success'))
    <div class="mb-4 p-4 rounded-lg bg-green-500 text-white shadow-sm">
        ✅ {{ session('success') }}
    </div>
    @endif

    <!-- Main Card -->
    <div class="bg-white shadow-lg rounded-2xl overflow-hidden">
        
        <!-- Scanner Area -->
        <div class="p-6">
            <form id="qrLoginForm" method="POST" action="{{ route('qr.login') }}" class="hidden">
                @csrf
                <input type="hidden" id="tokenInput" name="token" value="">
            </form>

            <div id="scanner-container" class="relative">
                <!-- Camera/Scanner Box -->
                <div class="border-2 border-dashed border-gray-300 rounded-xl overflow-hidden bg-gray-50 relative" style="min-height: 320px;">
                    <div id="reader" class="w-full h-full">
                        <div id="loading-indicator" class="absolute inset-0 flex items-center justify-center text-gray-500 z-10 bg-gray-50">
                            <div class="text-center">
                                <svg class="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                </svg>
                                <p class="text-gray-700 font-medium mb-1">Mengaktifkan kamera...</p>
                                <p class="text-gray-500 text-sm">Pastikan izin kamera telah diperbolehkan</p>
                            </div>
                        </div>
                    </div>
                    <div id="scan-line" class="hidden absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent scan-animation" style="top: 50%;"></div>
                </div>
            </div>

            <!-- Info Box (styled seperti gambar) -->
            <div id="info-box" class="mt-4 p-3 rounded-lg bg-blue-50 border border-blue-200">
                <div class="flex items-start gap-2">
                    <svg class="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path>
                    </svg>
                    <div>
                        <p class="text-blue-900 font-semibold text-sm mb-1">Informasi</p>
                        <p class="text-blue-800 text-sm leading-relaxed">Aplikasi harus diakses melalui HTTPS/localhost untuk mengaktifkan kamera. Anda tetap bisa upload gambar QR.</p>
                    </div>
                </div>
            </div>

            <!-- Dynamic Messages -->
            <div id="info" class="hidden mt-4 p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-800 text-sm"></div>
            <div id="success" class="hidden mt-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-800 text-sm"></div>
            <div id="error" class="hidden mt-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-800 text-sm"></div>

            <div class="text-center mt-4 text-gray-500 text-sm">atau</div>

            <!-- Upload Button -->
            <input type="file" id="qrFile" accept="image/*" class="hidden">
            <button id="uploadBtn" class="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white py-3.5 rounded-lg font-medium shadow-sm transition-colors flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                </svg>
                Upload Gambar QR Code
            </button>

            <!-- Switch Camera Button -->
            <button id="switchCameraBtn" class="hidden mt-3 w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                </svg>
                Ganti Kamera
            </button>

            <!-- Back to Login Button -->
            <button onclick="window.location.href='/login'" class="mt-3 w-full bg-white hover:bg-gray-50 text-gray-700 py-3 rounded-lg font-medium border border-gray-300 transition-colors flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                </svg>
                Kembali ke Login
            </button>

        </div>

        <!-- Footer -->
        <div class="px-6 py-4 bg-gray-50 border-t border-gray-100 text-center">
            <p class="text-gray-600 text-sm">
                Belum punya akun? 
                <a href="/register" class="text-blue-600 hover:text-blue-700 font-medium">Daftar Sekarang</a>
            </p>
        </div>

    </div>

    <!-- Debug info (hapus di production) -->
    <div id="debug" class="hidden mt-4 p-3 rounded-lg bg-gray-100 text-gray-700 text-xs font-mono"></div>

</div>

<script>
document.addEventListener("DOMContentLoaded", async () => {

    const info = document.getElementById('info');
    const success = document.getElementById('success');
    const error = document.getElementById('error');
    const debug = document.getElementById('debug');
    const tokenInput = document.getElementById('tokenInput');
    const qrLoginForm = document.getElementById('qrLoginForm');
    const loadingIndicator = document.getElementById('loading-indicator');
    const switchCameraBtn = document.getElementById('switchCameraBtn');
    const infoBox = document.getElementById('info-box');

    let html5QrCode = new Html5Qrcode("reader");
    let isProcessing = false;
    let cameras = [];
    let currentCameraIndex = 0;

    // ✅ Helper functions
    function showInfo(msg) { 
        info.innerText = msg; 
        info.classList.remove('hidden'); 
        success.classList.add('hidden'); 
        error.classList.add('hidden');
        infoBox.classList.add('hidden');
    }
    
    function showSuccess(msg) { 
        success.innerText = msg; 
        success.classList.remove('hidden'); 
        info.classList.add('hidden'); 
        error.classList.add('hidden');
        infoBox.classList.add('hidden');
    }
    
    function showError(msg) { 
        error.innerText = msg; 
        error.classList.remove('hidden'); 
        info.classList.add('hidden'); 
        success.classList.add('hidden');
        infoBox.classList.add('hidden');
    }

    function showDebug(msg) {
        if (debug) {
            debug.innerText = msg;
            debug.classList.remove('hidden');
        }
    }

    // ✅ Process QR Code dengan validasi lebih ketat
    function processQRCode(data) {
        if (isProcessing) {
            console.log('Already processing, ignoring duplicate scan');
            return;
        }
        
        isProcessing = true;
        data = data.trim();
        
        console.log('QR Code detected:', data);
        showDebug(`QR Data: ${data.substring(0, 50)}...`);

        // ✅ Cek apakah URL laporan (short_id atau token)
        if (data.startsWith("http://") || data.startsWith("https://")) {
            // Cek apakah URL laporan
            if (data.includes('/laporan/akses/') || data.includes('/laporan/qr/')) {
                showSuccess("✅ QR Laporan terdeteksi! Membuka halaman akses...");
                setTimeout(() => {
                    window.location.href = data;
                }, 1000);
                return;
            }
            
            // URL lain
            showError("⚠️ URL tidak dikenali sebagai QR laporan atau login");
            setTimeout(() => isProcessing = false, 3000);
            return;
        }

        // ✅ Jika bukan URL, anggap sebagai token login
        if (data.length > 10) { // Token biasanya panjang
            showSuccess("🔐 QR Login terdeteksi! Memproses...");
            tokenInput.value = data;
            setTimeout(() => {
                qrLoginForm.submit();
            }, 1000);
            return;
        }

        // ✅ Data tidak valid
        showError("❌ QR Code tidak valid. Pastikan Anda scan QR yang benar.");
        setTimeout(() => isProcessing = false, 3000);
    }

    // ✅ Start camera dengan konfigurasi optimal
    async function startCamera(cameraId) {
        try {
            loadingIndicator.style.display = "flex";
            
            await html5QrCode.start(
                cameraId,
                {
                    fps: 10,
                    qrbox: { width: 250, height: 250 },
                    aspectRatio: 1.0,
                    formatsToSupport: [ Html5QrcodeSupportedFormats.QR_CODE ]
                },
                (decodedText, decodedResult) => {
                    console.log('QR Decoded:', decodedText);
                    processQRCode(decodedText);
                },
                (errorMessage) => {
                    // Scan error (normal, terjadi terus saat scanning)
                }
            );
            
            loadingIndicator.style.display = "none";
            document.getElementById('scan-line').classList.remove('hidden');
            infoBox.classList.add('hidden');
            showInfo("📱 Arahkan kamera ke QR Code");
            
        } catch (err) {
            console.error('Camera start error:', err);
            loadingIndicator.style.display = "none";
            showError("❌ Gagal mengaktifkan kamera. Silakan gunakan upload gambar.");
        }
    }

    // ✅ Initialize cameras
    try {
        cameras = await Html5Qrcode.getCameras();
        console.log('Available cameras:', cameras.length);
        
        if (cameras.length === 0) {
            throw new Error('No cameras found');
        }

        // ✅ Prioritas kamera belakang
        const backCamera = cameras.find(cam => 
            cam.label.toLowerCase().includes('back') || 
            cam.label.toLowerCase().includes('rear') ||
            cam.label.toLowerCase().includes('environment')
        );
        
        if (backCamera) {
            currentCameraIndex = cameras.indexOf(backCamera);
        }

        await startCamera(cameras[currentCameraIndex].id);

        // ✅ Tampilkan tombol ganti kamera jika ada lebih dari 1
        if (cameras.length > 1) {
            switchCameraBtn.classList.remove('hidden');
        }

    } catch (err) {
        console.error('Camera initialization error:', err);
        loadingIndicator.style.display = "none";
        // Info box tetap ditampilkan jika kamera gagal
    }

    // ✅ Switch camera handler
    switchCameraBtn.addEventListener('click', async () => {
        try {
            await html5QrCode.stop();
            currentCameraIndex = (currentCameraIndex + 1) % cameras.length;
            await startCamera(cameras[currentCameraIndex].id);
            showInfo(`📷 Beralih ke: ${cameras[currentCameraIndex].label}`);
        } catch (err) {
            showError("Gagal mengganti kamera");
        }
    });

    // ✅ Upload button handler
    document.getElementById('uploadBtn').onclick = () => {
        document.getElementById('qrFile').click();
    };

    // ✅ File upload handler
    document.getElementById('qrFile').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        showInfo("📸 Membaca QR dari gambar...");
        
        try {
            try {
                await html5QrCode.stop();
            } catch (stopErr) {
                console.log('Camera already stopped or not started');
            }

            const scanPromise = html5QrCode.scanFile(file, true);
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Scan timeout')), 10000)
            );

            const result = await Promise.race([scanPromise, timeoutPromise]);
            
            console.log('File scan result:', result);
            processQRCode(result);

        } catch (err) {
            console.error('File scan error:', err);
            showError("❌ QR Code tidak terbaca dari gambar. Pastikan gambar jelas dan terfokus.");
            isProcessing = false;

            try {
                await startCamera(cameras[currentCameraIndex].id);
            } catch (restartErr) {
                console.error('Failed to restart camera:', restartErr);
            }
        }

        e.target.value = "";
    });

});
</script>

</body>
</html>