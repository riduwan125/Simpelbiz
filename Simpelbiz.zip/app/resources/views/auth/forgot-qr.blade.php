@extends('layouts.app')

@section('title', 'Scan QR Code')

@section('content')
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-6">

            {{-- Header --}}
            <div class="text-center mb-4">
                <h3 class="fw-bold mb-1">Scan QR Code</h3>
                <p class="text-muted mb-0">
                    Arahkan kamera ke QR Code untuk login, atau scan QR laporan.
                    Jika isi QR berupa URL, halaman akan langsung dibuka.
                </p>
            </div>

            {{-- Card utama --}}
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">

                    {{-- Area kamera --}}
                    <div id="reader"
                         style="width:100%;max-width:400px;height:320px;margin:0 auto;border:1px dashed #d1d5db;border-radius:10px;">
                        <div class="d-flex flex-column justify-content-center align-items-center h-100 text-center text-secondary">
                            <div style="font-size:32px;">📷</div>
                            <div class="fw-semibold mt-2">Mengaktifkan kamera...</div>
                            <div style="font-size: 12px;">Pastikan izin kamera sudah diberikan</div>
                        </div>
                    </div>

                    {{-- Status --}}
                    <div id="qr-status" class="mt-3 small fw-semibold text-center text-danger"></div>

                    {{-- form hidden untuk submit token LOGIN --}}
                    <form id="qrScanForm" method="POST" action="{{ route('qr.login') }}">
                        @csrf
                        <input type="hidden" name="qr_token" id="qr_token">
                    </form>
                </div>

                {{-- Footer card --}}
                <div class="card-footer bg-white border-0">
                    <div class="text-center text-muted small mb-2">atau</div>

                    {{-- Upload gambar QR --}}
                    <div class="mb-2">
                        <input type="file" id="qrFile" accept="image/*" class="form-control mb-2" hidden>
                        <button type="button" id="uploadBtn" class="btn btn-primary w-100">
                            Upload Gambar QR Code
                        </button>
                    </div>

                    <a href="{{ route('login') }}" class="btn btn-outline-secondary w-100">
                        Kembali ke Login
                    </a>
                </div>
            </div>

            {{-- Tips --}}
            <div class="alert alert-info small mb-0">
                <strong>Tips:</strong>
                <ul class="mb-0 ps-3">
                    <li>Pastikan QR Code tidak buram dan cukup cahaya.</li>
                    <li>Jarak kamera ke QR sekitar 10–20 cm.</li>
                    <li>Jika kamera tidak bisa dipakai, gunakan upload gambar QR.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
    {{-- 1. PAKAI FILE LOKAL, BUKAN CDN --}}
    <script src="{{ asset('js/html5-qrcode.min.js') }}"></script>

    {{-- 2. Script inisialisasi --}}
    <script>
        document.addEventListener('DOMContentLoaded', async function () {
            const readerDiv  = document.getElementById('reader');
            const statusDiv  = document.getElementById('qr-status');
            const tokenInput = document.getElementById('qr_token');
            const form       = document.getElementById('qrScanForm');
            const uploadBtn  = document.getElementById('uploadBtn');
            const fileInput  = document.getElementById('qrFile');

            function setStatus(message, type = 'error') {
                statusDiv.textContent = message || '';
                statusDiv.classList.remove('text-danger', 'text-success', 'text-info');
                if (type === 'success') statusDiv.classList.add('text-success');
                else if (type === 'info') statusDiv.classList.add('text-info');
                else statusDiv.classList.add('text-danger');
            }

            // ==== CEK: library sudah ke-load belum? ====
            console.log('Html5Qrcode type =', typeof Html5Qrcode);
            if (typeof Html5Qrcode === 'undefined') {
                readerDiv.innerHTML = `
                    <div class="d-flex flex-column justify-content-center align-items-center h-100 text-center text-danger">
                        <div style="font-size:32px;">⚠️</div>
                        <div class="fw-semibold mt-2">Library QR tidak dimuat</div>
                        <div class="text-muted" style="font-size:12px;">
                            Pastikan file <code>public/js/html5-qrcode.min.js</code> ada dan bisa diakses.
                        </div>
                    </div>
                `;
                setStatus('Library QR Code tidak dapat dimuat.', 'error');
                return;
            }

            // Fungsi handle hasil decode (kamera & upload)
            function handleDecoded(decodedText) {
                console.log('QR decoded:', decodedText);

                // 1) Jika hasil scan URL → buka URL (untuk laporan)
                if (decodedText.startsWith('http://') || decodedText.startsWith('https://')) {
                    setStatus('Membuka link laporan...', 'info');
                    window.location.href = decodedText;
                    return;
                }

                // 2) Selain itu dianggap token login
                tokenInput.value = decodedText;
                setStatus('QR Code terdeteksi, memproses login...', 'success');
                form.submit();
            }

            const isSecure = location.protocol === 'https:' || location.hostname === 'localhost';
            const html5QrCode = new Html5Qrcode('reader');

            // ==== Kamera (kalau HTTPS) ====
            if (isSecure) {
                try {
                    const cameras = await Html5Qrcode.getCameras();

                    if (!cameras || !cameras.length) {
                        setStatus('Tidak ada kamera terdeteksi. Gunakan upload gambar QR.', 'error');
                    } else {
                        const cameraConfig = { deviceId: { exact: cameras[0].id } };

                        await html5QrCode.start(
                            cameraConfig,
                            { fps: 10, qrbox: 250 },
                            decodedText => {
                                html5QrCode.stop().catch(() => {});
                                handleDecoded(decodedText);
                            },
                            err => {
                                // error per frame boleh diabaikan
                            }
                        );
                        setStatus('', 'info');
                    }
                } catch (e) {
                    console.error(e);
                    setStatus('Gagal membuka kamera: ' + (e.message || e.name || e), 'error');
                }

                // stop kamera ketika tab disembunyikan
                document.addEventListener('visibilitychange', () => {
                    if (document.hidden) {
                        html5QrCode.stop().catch(() => {});
                    }
                });
            } else {
                setStatus('Untuk kamera, akses harus lewat HTTPS. Anda tetap bisa upload gambar QR.', 'info');
            }

            // ==== Upload gambar QR ====
            uploadBtn.addEventListener('click', () => fileInput.click());

            fileInput.addEventListener('change', async () => {
                if (!fileInput.files || !fileInput.files.length) return;

                setStatus('Memproses gambar QR Code...', 'info');

                try {
                    // PENTING: pakai method instance, bukan Html5Qrcode.scanFile()
                    const result = await html5QrCode.scanFile(fileInput.files[0], true);
                    handleDecoded(result);
                } catch (e) {
                    console.error(e);
                    setStatus(
                        'QR Code tidak dapat dibaca dari gambar. Pastikan gambar jelas dan tidak buram.',
                        'error'
                    );
                }
            });
        });
    </script>
@endpush
