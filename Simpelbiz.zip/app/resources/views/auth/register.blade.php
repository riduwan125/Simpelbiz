<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi UMKM</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen py-12 px-4">
<div class="max-w-5xl mx-auto">

    {{-- Header --}}
    <div class="text-center mb-8">
        <div class="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
            <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
            </svg>
        </div>
        <h1 class="text-3xl font-bold text-gray-900 mb-2">Registrasi UMKM</h1>
        <p class="text-gray-600">Daftarkan usaha Anda untuk bergabung dengan platform kami</p>
    </div>

    {{-- Card --}}
    <div class="bg-white shadow-xl rounded-2xl overflow-hidden">

        {{-- Error Laravel --}}
        @if ($errors->any())
            <div class="mx-8 mt-8 p-4 rounded-lg bg-red-50 border border-red-200">
                <div class="flex items-start">
                    <svg class="w-5 h-5 text-red-600 mt-0.5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                              clip-rule="evenodd"/>
                    </svg>
                    <div class="flex-1">
                        <h3 class="text-sm font-semibold text-red-800 mb-1">Terdapat kesalahan:</h3>
                        <ul class="text-sm text-red-700 space-y-1 list-disc list-inside">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        @endif

        <form method="POST" action="{{ route('register') }}" class="p-8">
            @csrf

            <div class="space-y-8">

                {{-- Informasi Pemilik --}}
                <div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-4 pb-2 border-b border-gray-200 flex items-center">
                        <svg class="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                        Informasi Pemilik
                    </h2>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        {{-- Nama User --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Nama Lengkap <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input type="text" name="nama_user" value="{{ old('nama_user') }}" required
                                       class="w-full border border-gray-300 rounded-lg h-11 px-4 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                       placeholder="Masukkan nama lengkap">
                            </div>
                        </div>

                        {{-- Email --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Email <span class="text-red-500">*</span>
                            </label>
                            <input type="email" name="email" value="{{ old('email') }}" required
                                   class="w-full border border-gray-300 rounded-lg h-11 px-4 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                   placeholder="nama@email.com">
                        </div>

                        {{-- No Telepon --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                No. Telepon <span class="text-red-500">*</span>
                            </label>
                            <input type="tel" name="no_telepon" value="{{ old('no_telepon') }}" required
                                   class="w-full border border-gray-300 rounded-lg h-11 px-4 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                   placeholder="08xx-xxxx-xxxx">
                        </div>

                    </div>
                </div>

                {{-- Informasi UMKM --}}
                <div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-4 pb-2 border-b border-gray-200 flex items-center">
                        <svg class="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                        </svg>
                        Informasi UMKM
                    </h2>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        {{-- Nama UMKM --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Nama UMKM <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="nama_umkm" value="{{ old('nama_umkm') }}" required
                                   class="w-full border border-gray-300 rounded-lg h-11 px-4 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                   placeholder="Nama usaha Anda">
                        </div>

                        {{-- Jenis Usaha --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Jenis Usaha <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="jenis_usaha" value="{{ old('jenis_usaha') }}" required
                                   class="w-full border border-gray-300 rounded-lg h-11 px-4 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                   placeholder="Contoh: Kuliner, Fashion, Kerajinan">
                        </div>

                        {{-- Alamat UMKM --}}
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Alamat UMKM <span class="text-red-500">*</span>
                            </label>
                            <textarea name="alamat_umkm" rows="3" required
                                      class="w-full border border-gray-300 rounded-lg px-4 py-3 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none"
                                      placeholder="Alamat lengkap usaha Anda">{{ old('alamat_umkm') }}</textarea>
                        </div>

                    </div>
                </div>

                {{-- Keamanan Akun --}}
                <div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-4 pb-2 border-b border-gray-200 flex items-center">
                        <svg class="w-5 h-5 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                        </svg>
                        Keamanan Akun
                    </h2>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        {{-- Password --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Password <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input id="password" type="password" name="password" required minlength="8"
                                       class="w-full border border-gray-300 rounded-lg h-11 px-4 pr-10 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                       placeholder="Minimal 8 karakter">
                                <button type="button" id="togglePassword"
                                        class="absolute inset-y-0 right-0 px-3 flex items-center text-gray-400 hover:text-gray-600">
                                    <svg id="iconPassword" class="w-5 h-5" fill="none" stroke="currentColor"
                                         viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                              d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                              d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                    </svg>
                                </button>
                            </div>

                            <!-- INFO / CHECKLIST PASSWORD (TAMBAHAN, TANPA UBAH DESAIN UTAMA) -->
                            <div class="mt-3 p-4 rounded-lg bg-blue-50 border border-blue-200">
                                <p class="text-sm font-semibold text-blue-900 mb-2">Syarat Password:</p>
                                <ul class="text-sm space-y-1">
                                    <li id="rule-length" class="text-gray-700">• Minimal 8 karakter</li>
                                    <li id="rule-upper"  class="text-gray-700">• Minimal 1 huruf besar (A–Z)</li>
                                    <li id="rule-lower"  class="text-gray-700">• Minimal 1 huruf kecil (a–z)</li>
                                    <li id="rule-number" class="text-gray-700">• Minimal 1 angka (0–9)</li>
                                    <li id="rule-symbol" class="text-gray-700">• Minimal 1 simbol (contoh: !@#$)</li>
                                </ul>
                            </div>
                        </div>

                        {{-- Konfirmasi Password --}}
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Konfirmasi Password <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input id="password_confirmation" type="password" name="password_confirmation" required minlength="8"
                                       class="w-full border border-gray-300 rounded-lg h-11 px-4 pr-10 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                       placeholder="Ulangi password">
                                <button type="button" id="togglePasswordConfirm"
                                        class="absolute inset-y-0 right-0 px-3 flex items-center text-gray-400 hover:text-gray-600">
                                    <svg id="iconPasswordConfirm" class="w-5 h-5" fill="none" stroke="currentColor"
                                         viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                              d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                              d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                    </svg>
                                </button>
                            </div>

                            <p id="confirmHint" class="text-xs mt-2 text-gray-500">
                                Pastikan konfirmasi password sama persis.
                            </p>
                        </div>

                    </div>
                </div>

            </div>

            {{-- Tombol submit --}}
            <div class="mt-8 pt-6 border-t border-gray-200">
                <button type="submit"
                        class="w-full bg-blue-600 hover:bg-blue-700 text-white h-12 rounded-lg font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center justify-center space-x-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span>DAFTAR SEKARANG</span>
                </button>
            </div>

        </form>

        {{-- Footer --}}
        <div class="bg-gray-50 px-8 py-4 border-t border-gray-200">
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-600">Sudah punya akun?</span>
                <a href="{{ route('login') }}"
                   class="text-blue-600 hover:text-blue-700 font-medium hover:underline transition-colors flex items-center space-x-1">
                    <span>Login di sini</span>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M9 5l7 7-7 7"></path>
                    </svg>
                </a>
            </div>
        </div>

    </div>

    <div class="mt-8 text-center text-sm text-gray-600">
        <p class="flex items-center justify-center space-x-2">
            <svg class="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd"
                      d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 101.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                      clip-rule="evenodd"/>
            </svg>
            <span>Data Anda aman dan terenkripsi</span>
        </p>
    </div>

</div>

<script>
    // toggle show/hide password (desain asli tetap)
    function setupTogglePassword(inputId, buttonId, iconId) {
        const input = document.getElementById(inputId);
        const button = document.getElementById(buttonId);
        const icon = document.getElementById(iconId);

        button.addEventListener('click', () => {
            const hidden = input.type === "password";
            input.type = hidden ? "text" : "password";

            icon.innerHTML = hidden
                ? `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                       d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59"/>
                  `
                : `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                       d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                   <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                       d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>`;
        });
    }

    setupTogglePassword("password", "togglePassword", "iconPassword");
    setupTogglePassword("password_confirmation", "togglePasswordConfirm", "iconPasswordConfirm");

    // ====== CHECKLIST PASSWORD (TAMBAHAN) ======
    const passwordEl = document.getElementById('password');

    function markRule(id, ok) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.toggle('text-blue-800', ok);
        el.classList.toggle('font-semibold', ok);
        el.classList.toggle('text-gray-700', !ok);
        el.classList.toggle('font-normal', !ok);
    }

    function validatePasswordRules(v) {
        return {
            length: v.length >= 8,
            upper: /[A-Z]/.test(v),
            lower: /[a-z]/.test(v),
            number: /[0-9]/.test(v),
            symbol: /[^A-Za-z0-9]/.test(v),
        };
    }

    passwordEl.addEventListener('input', () => {
        const v = passwordEl.value || '';
        const r = validatePasswordRules(v);

        markRule('rule-length', r.length);
        markRule('rule-upper', r.upper);
        markRule('rule-lower', r.lower);
        markRule('rule-number', r.number);
        markRule('rule-symbol', r.symbol);
    });

    // validasi konfirmasi + aturan password sebelum submit
    document.querySelector("form").addEventListener("submit", e => {
        const p = document.getElementById("password").value;
        const pc = document.getElementById("password_confirmation").value;

        const r = validatePasswordRules(p);
        const okAll = r.length && r.upper && r.lower && r.number && r.symbol;

        if (!okAll) {
            e.preventDefault();
            alert("Password belum memenuhi syarat: minimal 8 karakter, ada huruf besar, huruf kecil, angka, dan simbol.");
            return;
        }

        if (p !== pc) {
            e.preventDefault();
            alert("Password dan konfirmasi password tidak cocok!");
            return;
        }
    });
</script>

</body>
</html>
