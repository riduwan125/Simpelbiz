@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Scan QR Code Disini</h2>

    <!-- Tempat scanner -->
    <div id="reader" style="width:300px; margin:auto; border:1px solid #ccc;"></div>

    <!-- Form tersembunyi -->
    <form id="qrForm" method="POST" action="{{ route('qr.login') }}">
        @csrf
        <input type="hidden" id="qr_token" name="qr_token">
    </form>

    <div style="margin-top:15px;">
        <button type="button" onclick="startScanner()">Start Scanner</button>
        <button type="button" onclick="stopScanner()">Stop Scanner</button>
    </div>

    <p style="margin-top:15px;">
        Belum daftar? <a href="{{ route('register') }}">Daftar</a>
    </p>
</div>

@push('scripts')
<script src="https://unpkg.com/html5-qrcode"></script>
<script>
    let html5QrCode = null;
    let currentCameraId = null;

    // Callback kalau QR berhasil dibaca
    function onScanSuccess(decodedText, decodedResult) {
        console.log("QR terdeteksi:", decodedText);
        document.getElementById("qr_token").value = decodedText;
        document.getElementById("qrForm").submit();
    }

    // Start scanner
    async function startScanner() {
        try {
            if (html5QrCode) {
                await stopScanner(); // pastikan stop dulu sebelum start baru
            }

            html5QrCode = new Html5Qrcode("reader");

            const devices = await Html5Qrcode.getCameras();
            console.log("Daftar kamera:", devices);

            if (!devices || devices.length === 0) {
                alert("Tidak ada kamera ditemukan!");
                return;
            }

            currentCameraId = devices[0].id; // pilih kamera pertama
            console.log("Memakai kamera:", devices[0].label || "Default Camera");

            await html5QrCode.start(
                currentCameraId,
                { fps: 10, qrbox: 250 },
                onScanSuccess
            );

            console.log("Scanner berhasil dimulai ✅");
        } catch (err) {
            console.error("Gagal start scanner:", err);
            alert("Tidak bisa mengakses kamera: " + err);
        }
    }

    // Stop scanner
    async function stopScanner() {
        if (html5QrCode) {
            try {
                await html5QrCode.stop();
                await html5QrCode.clear();
                console.log("Scanner dimatikan ❌");
            } catch (err) {
                console.error("Gagal stop scanner:", err);
            }
        }
    }

    // Auto-reconnect kalau device kamera berubah
    navigator.mediaDevices.ondevicechange = () => {
        console.log("Perubahan device kamera terdeteksi, restart scanner...");
        stopScanner().then(startScanner);
    };

    // Auto start pertama kali halaman dibuka
    window.onload = startScanner;
</script>
@endpush
@endsection
