<x-guest-layout>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }

        .verify-container {
            background-color: #ffffff;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 3rem 2.5rem;
            max-width: 480px;
            width: 100%;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .verify-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        }

        .icon-wrapper {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }

        .icon-wrapper svg {
            width: 50px;
            height: 50px;
            color: white;
        }

        .verify-logo {
            width: 90px;
            height: auto;
            margin-bottom: 1.5rem;
            filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1));
        }

        .verify-container h2 {
            font-weight: 700;
            font-size: 28px;
            color: #1f2937;
            margin-bottom: 0.75rem;
            line-height: 1.2;
        }

        .verify-container p {
            color: #6b7280;
            font-size: 15px;
            line-height: 1.6;
            margin-bottom: 1.5rem;
        }

        .verify-container p strong {
            color: #374151;
            font-weight: 600;
        }

        .alert-success {
            background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
            color: #065f46;
            font-size: 14px;
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border: 1px solid #6ee7b7;
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        .button-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 2rem;
        }

        .btn-verify {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 14px 24px;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            font-size: 15px;
            width: 100%;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-verify:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }

        .btn-verify:active {
            transform: translateY(0);
        }

        .btn-verify svg {
            width: 18px;
            height: 18px;
        }

        .btn-logout {
            background-color: transparent;
            color: #dc2626;
            border: 2px solid #fecaca;
            padding: 12px 24px;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            width: 100%;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-logout:hover {
            background-color: #fef2f2;
            border-color: #dc2626;
        }

        .btn-logout svg {
            width: 16px;
            height: 16px;
        }

        .info-box {
            background-color: #f0f9ff;
            border: 1px solid #bfdbfe;
            border-radius: 12px;
            padding: 16px;
            margin-top: 1.5rem;
            text-align: left;
        }

        .info-box-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 14px;
            color: #1e40af;
            margin-bottom: 8px;
        }

        .info-box-title svg {
            width: 18px;
            height: 18px;
        }

        .info-box-content {
            font-size: 13px;
            color: #1e40af;
            line-height: 1.5;
        }

        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 1.5rem 0;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #e5e7eb;
        }

        .divider span {
            padding: 0 12px;
            color: #9ca3af;
            font-size: 13px;
            font-weight: 500;
        }

        @media (max-width: 640px) {
            .verify-container {
                padding: 2rem 1.5rem;
            }

            .verify-container h2 {
                font-size: 24px;
            }

            .icon-wrapper {
                width: 80px;
                height: 80px;
            }

            .icon-wrapper svg {
                width: 40px;
                height: 40px;
            }
        }
    </style>

    <div class="verify-container">
        <!-- Logo or Icon -->
        @if(file_exists(public_path('images/logo-umkm.png')))
            <img src="{{ asset('images/logo-umkm.png') }}" alt="Logo UMKM" class="verify-logo">
        @else
            <div class="icon-wrapper">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                </svg>
            </div>
        @endif

        <!-- Title -->
        <h2>Verifikasi Email Anda</h2>

        <!-- Description -->
        <p>
            Terima kasih telah mendaftar! Kami telah mengirimkan tautan verifikasi ke alamat email Anda.
            <br><br>
            Silakan periksa <strong>inbox</strong> atau folder <strong>spam</strong> Anda dan klik tautan untuk mengaktifkan akun.
        </p>

        <!-- Success Alert -->
        @if (session('status') == 'verification-link-sent')
            <div class="alert-success">
                <svg fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                </svg>
                <span>Link verifikasi baru telah dikirim ke email Anda!</span>
            </div>
        @endif

        <!-- Buttons -->
        <div class="button-group">
            <form method="POST" action="{{ route('verification.send') }}">
                @csrf
                <button type="submit" class="btn-verify">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                    </svg>
                    Kirim Ulang Email Verifikasi
                </button>
            </form>

            <div class="divider">
                <span>atau</span>
            </div>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn-logout">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Keluar dari Akun
                </button>
            </form>
        </div>

        <!-- Info Box -->
        <div class="info-box">
            <div class="info-box-title">
                <svg fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                </svg>
                Tidak menerima email?
            </div>
            <div class="info-box-content">
                Periksa folder spam atau gunakan tombol "Kirim Ulang" di atas. Jika masih bermasalah, hubungi tim support kami.
            </div>
        </div>
    </div>
</x-guest-layout>