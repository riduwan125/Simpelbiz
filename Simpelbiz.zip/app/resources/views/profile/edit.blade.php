@extends('layouts.admin')

@section('page-title', 'Profil Saya')

@section('content')
<div class="container mt-5">

    {{-- Kartu Informasi UMKM --}}
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-3">Informasi UMKM</h5>

            @if($umkm)
                <div class="mb-2">
                    <span class="text-muted d-block">Nama UMKM</span>
                    <span class="fw-semibold">{{ $umkm->nama_umkm }}</span>
                </div>

                <div class="mb-2">
                    <span class="text-muted d-block">Jenis Usaha</span>
                    <span class="fw-semibold">{{ $umkm->jenis_usaha }}</span>
                </div>

                <div class="mb-2">
                    <span class="text-muted d-block">Alamat</span>
                    <span class="fw-semibold">{{ $umkm->alamat_umkm }}</span>
                </div>

                <div class="mb-2">
                    <span class="text-muted d-block">No. Telepon</span>
                    <span class="fw-semibold">{{ $umkm->no_telepon }}</span>
                </div>
            @else
                <p class="text-muted mb-0">
                    Data UMKM belum tersedia untuk akun ini.
                </p>
            @endif
        </div>
    </div>

    {{-- Kartu Update Profil --}}
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-3">Informasi Profil</h5>
            @include('profile.partials.update-profile-information-form')
        </div>
    </div>

    {{-- Kartu Update Password --}}
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-2">Ganti Password</h5>

            {{-- Keterangan Syarat Password --}}
            <div class="alert alert-secondary small mb-3">
                <strong>Syarat Password:</strong>
                <ul class="mb-0 ps-3">
                    <li>Minimal 8 karakter</li>
                    <li>Minimal 1 huruf besar (A–Z)</li>
                    <li>Minimal 1 huruf kecil (a–z)</li>
                    <li>Minimal 1 angka (0–9)</li>
                    <li>Minimal 1 simbol (contoh: !@#$)</li>
                </ul>
            </div>

            @include('profile.partials.update-password-form')
        </div>
    </div>

    {{-- Kartu Hapus Akun --}}
    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-3 text-danger">Hapus Akun</h5>
            @include('profile.partials.delete-user-form')
        </div>
    </div>

</div>
@endsection
