<form method="post" action="{{ route('profile.password.update') }}" class="mt-3">
    @csrf
    @method('put')

    @if (session('status') === 'password-updated')
        <div class="alert alert-success py-2 px-3 mb-3">
            Password berhasil diperbarui.
        </div>
    @endif

    <div class="mb-3">
        <label class="form-label fw-semibold">Password Baru</label>
        <input id="password"
               name="password"
               type="password"
               class="form-control @error('password') is-invalid @enderror"
               autocomplete="new-password">
        @error('password')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="mb-4">
        <label class="form-label fw-semibold">Konfirmasi Password Baru</label>
        <input id="password_confirmation"
               name="password_confirmation"
               type="password"
               class="form-control"
               autocomplete="new-password">
    </div>

    <div class="d-flex justify-content-end">
        <button type="submit" class="btn btn-primary px-4">
            Simpan
        </button>
    </div>
</form>
