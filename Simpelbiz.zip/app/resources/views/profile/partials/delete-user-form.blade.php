<form method="post" action="{{ route('profile.destroy') }}" class="mt-3"
      onsubmit="return confirm('Yakin ingin menghapus akun? Semua data akan hilang.');">
    @csrf
    @method('delete')

    @if ($errors->userDeletion->get('password'))
        <div class="alert alert-danger py-2 px-3 mb-3">
            {{ $errors->userDeletion->first('password') }}
        </div>
    @endif

    <p class="text-muted mb-3">
        Setelah akun dihapus, semua data Anda akan dihapus permanen.
    </p>

    <div class="mb-3" style="max-width: 320px;">
        <label class="form-label fw-semibold">Password</label>
        <input id="password"
               name="password"
               type="password"
               class="form-control @error('password', 'userDeletion') is-invalid @enderror"
               placeholder="Masukkan password untuk konfirmasi">
    </div>

    <button type="submit" class="btn btn-outline-danger">
        Hapus Akun
    </button>
</form>
