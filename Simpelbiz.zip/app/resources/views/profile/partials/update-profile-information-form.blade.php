<form method="post" action="{{ route('profile.update') }}" class="mt-3">
    @csrf
    @method('patch')

    @if (session('status') === 'profile-updated')
        <div class="alert alert-success py-2 px-3 mb-3">
            Profil berhasil diperbarui.
        </div>
    @endif

    <div class="mb-3">
        <label class="form-label fw-semibold">Nama</label>
        <input id="name"
               name="nama_user"
               type="text"
               class="form-control @error('nama_user') is-invalid @enderror"
               value="{{ old('nama_user', $user->nama_user) }}"
               required autofocus autocomplete="name">
        @error('nama_user')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="mb-3">
        <label class="form-label fw-semibold">Email</label>
        <input id="email"
               name="email"
               type="email"
               class="form-control @error('email') is-invalid @enderror"
               value="{{ old('email', $user->email) }}"
               required autocomplete="username">
        @error('email')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    {{-- Nama UMKM (relasi ke tabel umkm) --}}
    <div class="mb-3">
        <label class="form-label fw-semibold">Nama UMKM</label>
        <input type="text"
               name="nama_umkm"
               class="form-control @error('nama_umkm') is-invalid @enderror"
               value="{{ old('nama_umkm', optional($user->umkm)->nama_umkm) }}"
               placeholder="Nama usaha Anda">
        @error('nama_umkm')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="d-flex justify-content-end">
        <button type="submit" class="btn btn-primary px-4">
            Simpan
        </button>
    </div>
</form>
