<nav x-data="{ open: false }" class="bg-white border-b border-gray-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">

            <!-- LEFT -->
            <div class="flex">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}" class="font-bold text-indigo-600">
                        {{ config('app.name') }}
                    </a>
                </div>

                <!-- MAIN MENU -->
                <div class="hidden sm:flex sm:items-center sm:ms-10 space-x-6">

                    <a href="{{ route('dashboard') }}"
                       class="{{ request()->routeIs('dashboard') ? 'font-bold text-indigo-600' : 'text-gray-600' }}">
                        Dashboard
                    </a>

                    <a href="{{ route('catatan.index') }}"
                       class="{{ request()->routeIs('catatan.*') ? 'font-bold text-indigo-600' : 'text-gray-600' }}">
                        Transaksi
                    </a>

                    <a href="{{ route('modal-beban.index') }}"
                       class="{{ request()->routeIs('modal-beban.*') ? 'font-bold text-indigo-600' : 'text-gray-600' }}">
                        Biaya Usaha
                    </a>

                    <a href="{{ route('laporan.index') }}"
                       class="{{ request()->routeIs('laporan.*') ? 'font-bold text-indigo-600' : 'text-gray-600' }}">
                        Laporan
                    </a>

                </div>
            </div>

            <!-- RIGHT -->
            <div class="hidden sm:flex sm:items-center sm:ms-6">
                <x-dropdown align="right" width="48">
                    <x-slot name="trigger">
                        <button class="inline-flex items-center px-3 py-2 text-sm text-gray-600">
                            {{ Auth::user()->nama_user }}
                            <svg class="ms-2 h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                      d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/>
                            </svg>
                        </button>
                    </x-slot>

                    <x-slot name="content">
                        <x-dropdown-link :href="route('profile.edit')">
                            Profil
                        </x-dropdown-link>

                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <x-dropdown-link :href="route('logout')"
                                onclick="event.preventDefault(); this.closest('form').submit();">
                                Keluar
                            </x-dropdown-link>
                        </form>
                    </x-slot>
                </x-dropdown>
            </div>

            <!-- HAMBURGER -->
            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="p-2 text-gray-500">
                    ☰
                </button>
            </div>
        </div>
    </div>

    <!-- MOBILE MENU -->
    <div x-show="open" class="sm:hidden px-4 pb-4 space-y-2">
        <a href="{{ route('dashboard') }}">Dashboard</a>
        <a href="{{ route('catatan.index') }}">Transaksi</a>
        <a href="{{ route('modal-beban.index') }}">Biaya Usaha</a>
        <a href="{{ route('laporan.index') }}">Laporan</a>
        <a href="{{ route('profile.edit') }}">Profil</a>
    </div>
</nav>
