<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('page-title', 'Dashboard - '.config('app.name'))</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
<div class="d-flex" style="min-height:100vh">

    <!-- SIDEBAR USER -->
    <aside class="p-3 text-white" style="width:260px;background:#4c46ff">
        <div class="mb-4">
            <span class="fw-semibold">Dashboard Keuangan</span>
        </div>

        <nav class="nav flex-column gap-1">

            <!-- Dashboard -->
            <a class="nav-link text-white {{ request()->routeIs('dashboard') ? 'fw-bold' : '' }}"
               href="{{ route('dashboard') }}">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>

            <!-- Transaksi Harian -->
            <a class="nav-link text-white {{ request()->routeIs('catatan.*') ? 'fw-bold' : '' }}"
               href="{{ route('catatan.index') }}">
                <i class="bi bi-receipt me-2"></i> Transaksi Harian
            </a>

            <!-- Biaya / Modal Usaha -->
            <a class="nav-link text-white {{ request()->routeIs('modal-beban.*') ? 'fw-bold' : '' }}"
               href="{{ route('modal-beban.index') }}">
                <i class="bi bi-wallet2 me-2"></i> Biaya Usaha
            </a>

            <!-- Laporan -->
            <a class="nav-link text-white {{ request()->routeIs('laporan.*') ? 'fw-bold' : '' }}"
               href="{{ route('laporan.index') }}">
                <i class="bi bi-bar-chart-line me-2"></i> Laporan
            </a>

            <!-- PROFIL -->
            <hr class="text-white opacity-50 my-2">

            <a class="nav-link text-white {{ request()->routeIs('profile.*') ? 'fw-bold' : '' }}"
               href="{{ route('profile.edit') }}">
                <i class="bi bi-person-circle me-2"></i> Profil
            </a>

        </nav>
    </aside>

    <!-- CONTENT -->
    <div class="flex-grow-1 bg-light">

        <!-- HEADER -->
        <header class="p-3 border-bottom d-flex justify-content-between align-items-center bg-white">
            <span class="fw-semibold">@yield('page-title','Dashboard')</span>

            <div class="d-flex align-items-center gap-2">
                <span class="small text-muted">{{ auth()->user()->email }}</span>

                <form action="{{ route('logout') }}" method="POST" class="m-0">
                    @csrf
                    <button class="btn btn-sm btn-outline-danger">
                        <i class="bi bi-box-arrow-right me-1"></i> Keluar
                    </button>
                </form>
            </div>
        </header>

        <!-- MAIN -->
        <main class="p-4">
            @yield('content')
        </main>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
