<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('page-title', config('app.name'))</title>

    <!-- FAVICON (bypass cache) -->
    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}?v=2">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('favicon.ico') }}?v=2">
    <link rel="apple-touch-icon" href="{{ asset('favicon.ico') }}?v=2">

    {{-- CSS Bootstrap & ikon --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    {{-- SweetAlert2 --}}
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    {{-- CSS custom --}}
    <style>
        body { background-color: #f5f7fb; }
        .app-wrapper { min-height: 100vh; }
        .sidebar { background: #4c46ff; color: #fff; width: 260px; }
        .sidebar a { color: #e0e7ff; text-decoration: none; }
        .sidebar .nav-link { border-radius: 999px; padding: .65rem 1rem; margin-bottom: .25rem; }
        .sidebar .nav-link.active, .sidebar .nav-link:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .sidebar-header { padding: .85rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,0.15); }
        .sidebar-body { padding: 1rem 1.25rem 1.5rem 1.25rem; }
        .main-content { flex: 1; padding: 1.5rem; }

        @media (max-width: 767.98px) {
            .app-wrapper { flex-direction: column; }
            .sidebar {
                position: fixed; inset: 0 auto 0 0;
                transform: translateX(-100%);
                transition: transform .25s ease;
                z-index: 1040;
            }
            .sidebar.show { transform: translateX(0); }
            .sidebar-backdrop {
                position: fixed; inset: 0;
                background: rgba(15,23,42,.45);
                z-index: 1035; display: none;
            }
            .sidebar-backdrop.show { display: block; }
            .main-content { padding: 1rem; }
            .topbar {
                position: sticky; top: 0; z-index: 1030;
                background: #ffffff; border-bottom: 1px solid #e5e7eb;
            }
        }
    </style>

    @stack('styles')
</head>

<body>
<div id="sidebar-backdrop" class="sidebar-backdrop"></div>

<div class="app-wrapper d-flex">

    {{-- SIDEBAR --}}
    <aside id="sidebar" class="sidebar d-flex flex-column">
        <div class="sidebar-header d-flex justify-content-between align-items-center">
            <span class="fw-semibold">
                @auth
                    {{ auth()->user()->is_admin == 1 ? 'Admin Panel' : 'Dashboard' }}
                @else
                    Dashboard
                @endauth
            </span>
            <button class="btn btn-sm btn-light d-md-none" type="button" onclick="toggleSidebar()">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <div class="sidebar-body">
            <nav class="nav flex-column">

                @auth
                    @if (auth()->user()->is_admin == 1)
                        {{-- ========= MENU ADMIN SUPER (AMAN: hanya tampil jika route ada) ========= --}}

                        @if (\Illuminate\Support\Facades\Route::has('admin.dashboard'))
                            <a href="{{ route('admin.dashboard') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('admin.dashboard')) active @endif">
                                <i class="bi bi-speedometer2 me-2"></i> Dashboard Admin
                            </a>
                        @endif

                        @if (\Illuminate\Support\Facades\Route::has('admin.umkm.index'))
                            <a href="{{ route('admin.umkm.index') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('admin.umkm.*')) active @endif">
                                <i class="bi bi-buildings me-2"></i> Kelola UMKM
                            </a>
                        @endif

                        @if (\Illuminate\Support\Facades\Route::has('admin.verifikasi.index'))
                            <a href="{{ route('admin.verifikasi.index') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('admin.verifikasi.*')) active @endif">
                                <i class="bi bi-patch-check me-2"></i> Verifikasi UMKM
                            </a>
                        @endif

                        @if (\Illuminate\Support\Facades\Route::has('admin.users.index'))
                            <a href="{{ route('admin.users.index') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('admin.users.*')) active @endif">
                                <i class="bi bi-people me-2"></i> Kelola User
                            </a>
                        @endif

                        @if (\Illuminate\Support\Facades\Route::has('admin.laporan.index'))
                            <a href="{{ route('admin.laporan.index') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('admin.laporan.*')) active @endif">
                                <i class="bi bi-bar-chart-line me-2"></i> Laporan Sistem
                            </a>
                        @endif

                    @else
                        {{-- ========= MENU USER / PEGAWAI / ADMIN BIASA ========= --}}
                        @if (\Illuminate\Support\Facades\Route::has('dashboard'))
                            <a href="{{ route('dashboard') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('dashboard')) active @endif">
                                <i class="bi bi-speedometer2 me-2"></i> Dashboard
                            </a>
                        @endif

                        @if (\Illuminate\Support\Facades\Route::has('catatan.index'))
                            <a href="{{ route('catatan.index') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('catatan.*')) active @endif">
                                <i class="bi bi-journal-text me-2"></i> Transaksi Harian
                            </a>
                        @endif

                        @if (\Illuminate\Support\Facades\Route::has('modal-beban.index'))
                            <a href="{{ route('modal-beban.index') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('modal-beban.*')) active @endif">
                                <i class="bi bi-wallet2 me-2"></i> Biaya Usaha
                            </a>
                        @endif

                        @if (\Illuminate\Support\Facades\Route::has('laporan.index'))
                            <a href="{{ route('laporan.index') }}"
                               class="nav-link d-flex align-items-center @if(request()->routeIs('laporan.*')) active @endif">
                                <i class="bi bi-bar-chart-line me-2"></i> Laporan
                            </a>
                        @endif
                    @endif
                @endauth

            </nav>
        </div>
    </aside>

    {{-- AREA KONTEN --}}
    <div class="flex-grow-1 d-flex flex-column">

        {{-- TOPBAR --}}
        <header class="topbar px-3 py-2 d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-2">
                <button class="btn btn-sm btn-outline-secondary d-md-none me-1" type="button" onclick="toggleSidebar()">
                    <i class="bi bi-list"></i>
                </button>
                <span class="fw-semibold">@yield('page-title', 'Dashboard')</span>
            </div>

            <div class="d-flex align-items-center gap-2">
                @auth
                    <span class="small text-muted d-none d-sm-inline">
                        {{ auth()->user()->username ?? auth()->user()->email }}
                    </span>
                    <form action="{{ route('logout') }}" method="POST" class="m-0">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-box-arrow-right me-1"></i> Keluar
                        </button>
                    </form>
                @endauth
            </div>
        </header>

        <main class="main-content">
            @yield('content')
        </main>
    </div>
</div>

{{-- JS Bootstrap --}}
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function toggleSidebar() {
        const sidebar  = document.getElementById('sidebar');
        const backdrop = document.getElementById('sidebar-backdrop');
        sidebar.classList.toggle('show');
        backdrop.classList.toggle('show');
    }
    document.getElementById('sidebar-backdrop')?.addEventListener('click', toggleSidebar);
</script>

{{-- TOAST NOTIF GLOBAL --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof Swal === 'undefined') return;

    @if (session('success'))
        Swal.fire({
            icon: 'success',
            title: 'Berhasil',
            text: @json(session('success')),
            toast: true,
            position: 'top-end',
            timer: 2200,
            timerProgressBar: true,
            showConfirmButton: false
        });
    @endif

    @if (session('error'))
        Swal.fire({
            icon: 'error',
            title: 'Gagal',
            text: @json(session('error')),
        });
    @endif

    @if (session('warning'))
        Swal.fire({
            icon: 'warning',
            title: 'Perhatian',
            text: @json(session('warning')),
        });
    @endif
});
</script>

@stack('scripts')
</body>
</html>
