@extends('layouts.admin')

@section('title', 'Modal & Beban Operasional')

@section('content')

<div class="container py-3 py-md-4">

    {{-- Header + tombol tambah --}}
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 mb-md-4 gap-3">
        <div class="flex-grow-1">
            <h3 class="fw-bold mb-1 fs-4 fs-md-3">Modal & Beban Operasional</h3>
            <p class="text-secondary mb-0 small">
                Kelola modal dan beban operasional dengan mudah
            </p>
        </div>
        <a href="{{ route('modal-beban.create') }}" 
           class="btn btn-primary d-flex align-items-center gap-2 shadow-sm">
            <i class="bi bi-plus-lg"></i>
            <span>Tambah Data</span>
        </a>
    </div>
    {{-- Card daftar modal & beban --}}
    <div class="card border-0 shadow-sm mb-3 mb-md-4">
        <div class="card-body p-2 p-md-4">

            {{-- Desktop Table View --}}
            <div class="d-none d-lg-block">
                <div class="table-responsive">
                    <table class="table table-striped align-middle text-center mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Jenis</th>
                                <th>Deskripsi</th>
                                <th>Nominal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($data as $index => $row)
                                <tr>
                                    <td>{{ $index + 1 }}</td>

                                    <td>
                                        <div class="fw-medium">
                                            {{ \Carbon\Carbon::parse($row->tanggal)->format('d/m/Y') }}
                                        </div>
                                        <small class="text-secondary">
                                            {{ \Carbon\Carbon::parse($row->tanggal)->diffForHumans() }}
                                        </small>
                                    </td>

                                    <td>
                                        @if($row->jenis == 'modal_usaha')
                                            <span class="badge rounded-pill text-bg-info">
                                                <i class="bi bi-wallet2 me-1"></i>Modal Usaha
                                            </span>
                                        @else
                                            <span class="badge rounded-pill text-bg-warning">
                                                <i class="bi bi-cash-stack me-1"></i>Beban Operasional
                                            </span>
                                        @endif
                                    </td>

                                    <td class="text-start">
                                        {{ $row->deskripsi }}
                                    </td>

                                    <td class="text-end">
                                        Rp {{ number_format($row->nominal, 0, ',', '.') }}
                                    </td>

                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="{{ route('modal-beban.edit', $row->id_modal_beban) }}" 
                                               class="btn btn-primary btn-sm"
                                               title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>

                                            <form action="{{ route('modal-beban.destroy', $row->id_modal_beban) }}" 
                                                  method="POST"
                                                  class="d-inline delete-modal-beban-form">
                                                @csrf
                                                @method('DELETE')
                                                <button type="button"
                                                        class="btn btn-danger btn-sm btn-delete-modal-beban"
                                                        title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-muted py-4">
                                        Belum ada data modal & beban
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            {{-- Mobile & Tablet Card View --}}
            <div class="d-lg-none">
                @forelse ($data as $index => $row)
                <div class="card mb-3 border modal-beban-card" data-type="{{ $row->jenis }}">
                    <div class="card-body p-3">
                        {{-- Header Card --}}
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-secondary">{{ $index + 1 }}</span>
                                @if($row->jenis == 'modal_usaha')
                                    <span class="badge bg-info">
                                        <i class="bi bi-wallet2"></i> Modal Usaha
                                    </span>
                                @else
                                    <span class="badge bg-warning text-dark">
                                        <i class="bi bi-cash-stack"></i> Beban Operasional
                                    </span>
                                @endif
                            </div>
                            <div class="text-end">
                                <small class="text-muted d-block">
                                    {{ \Carbon\Carbon::parse($row->tanggal)->format('d/m/Y') }}
                                </small>
                                <small class="text-muted" style="font-size: 0.75rem;">
                                    {{ \Carbon\Carbon::parse($row->tanggal)->diffForHumans() }}
                                </small>
                            </div>
                        </div>

                        {{-- Deskripsi --}}
                        <h6 class="mb-2 fw-bold">{{ $row->deskripsi }}</h6>

                        {{-- Nominal --}}
                        <div class="p-2 bg-light rounded mb-3">
                            <small class="text-muted d-block" style="font-size: 0.75rem;">Nominal</small>
                            <div class="fw-bold text-primary">
                                Rp {{ number_format($row->nominal, 0, ',', '.') }}
                            </div>
                        </div>

                        {{-- Action Buttons --}}
                        <div class="d-flex gap-2">
                            <a href="{{ route('modal-beban.edit', $row->id_modal_beban) }}" 
                               class="btn btn-primary btn-sm flex-fill">
                                <i class="bi bi-pencil"></i> Edit
                            </a>

                            <form action="{{ route('modal-beban.destroy', $row->id_modal_beban) }}" 
                                  method="POST"
                                  class="delete-modal-beban-form flex-fill">
                                @csrf
                                @method('DELETE')
                                <button type="button"
                                        class="btn btn-danger btn-sm w-100 btn-delete-modal-beban"
                                        title="Hapus">
                                    <i class="bi bi-trash"></i> Hapus
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                @empty
                <div class="text-center text-muted py-5">
                    <div class="mb-3">
                        <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.5;"></i>
                    </div>
                    <h5 class="mb-2">Belum ada data modal & beban</h5>
                    <p class="mb-3 small">Mulai catat modal dan beban operasional Anda sekarang</p>
                    <a href="{{ route('modal-beban.create') }}" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg"></i> Tambah Data Pertama
                    </a>
                </div>
                @endforelse
            </div>

        </div>
    </div>

    {{-- Summary Cards (Mobile Only) --}}
    @if($data->count() > 0)
    <div class="row g-2 d-lg-none mb-3">
        @php
            $totalModal = $data->where('jenis', 'modal_usaha')->sum('nominal');
            $totalBeban = $data->where('jenis', 'beban_operasional')->sum('nominal');
            $selisih = $totalModal - $totalBeban;
        @endphp

        <div class="col-4">
            <div class="card border-0 bg-info bg-opacity-10">
                <div class="card-body p-2 text-center">
                    <small class="text-info d-block mb-1" style="font-size: 0.7rem;">
                        <i class="bi bi-wallet2"></i> Modal
                    </small>
                    <div class="fw-bold text-info" style="font-size: 0.85rem;">
                        Rp {{ number_format($totalModal, 0, ',', '.') }}
                    </div>
                </div>
            </div>
        </div>

        <div class="col-4">
            <div class="card border-0 bg-warning bg-opacity-10">
                <div class="card-body p-2 text-center">
                    <small class="text-warning d-block mb-1" style="font-size: 0.7rem;">
                        <i class="bi bi-cash-stack"></i> Beban
                    </small>
                    <div class="fw-bold text-warning" style="font-size: 0.85rem;">
                        Rp {{ number_format($totalBeban, 0, ',', '.') }}
                    </div>
                </div>
            </div>
        </div>

        <div class="col-4">
            <div class="card border-0 bg-primary bg-opacity-10">
                <div class="card-body p-2 text-center">
                    <small class="text-primary d-block mb-1" style="font-size: 0.7rem;">
                        <i class="bi bi-calculator"></i> Selisih
                    </small>
                    <div class="fw-bold text-primary" style="font-size: 0.85rem;">
                        Rp {{ number_format($selisih, 0, ',', '.') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

</div>

{{-- Custom CSS --}}
<style>
/* Mobile optimizations */
@media (max-width: 991.98px) {
    .modal-beban-card {
        transition: all 0.2s ease;
    }

    .modal-beban-card:active {
        transform: scale(0.98);
        box-shadow: 0 0.125rem 0.5rem rgba(0, 0, 0, 0.15);
    }

    /* Colored border for type */
    .modal-beban-card[data-type="modal_usaha"] {
        border-left: 4px solid #0dcaf0;
    }

    .modal-beban-card[data-type="beban_operasional"] {
        border-left: 4px solid #ffc107;
    }

    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
    }
}

/* Touch-friendly buttons */
.btn, .form-select, .form-control {
    min-height: 44px;
}

@media (max-width: 991.98px) {
    .btn-sm {
        min-height: 38px;
    }
}

/* Smooth animations */
.card {
    transition: box-shadow 0.2s ease;
}

.card:hover {
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

/* Better badge sizing on mobile */
@media (max-width: 991.98px) {
    .badge {
        font-size: 0.7rem;
        padding: 0.35em 0.65em;
    }
}

/* Empty state animation */
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.bi-inbox {
    animation: float 3s ease-in-out infinite;
}
</style>

{{-- Script SweetAlert konfirmasi hapus --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    const deleteForms = document.querySelectorAll('.delete-modal-beban-form');

    deleteForms.forEach(function(form) {
        const button = form.querySelector('.btn-delete-modal-beban');
        if (!button) return;

        button.addEventListener('click', function (e) {
            e.preventDefault();

            // Check if Swal is available
            if (typeof Swal === 'undefined') {
                if (confirm('Hapus data? Data yang dihapus tidak dapat dikembalikan.')) {
                    form.submit();
                }
                return;
            }

            Swal.fire({
                title: 'Hapus data?',
                text: 'Data yang dihapus tidak dapat dikembalikan.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3342f',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus',
                cancelButtonText: 'Batal',
                customClass: {
                    container: window.innerWidth < 992 ? 'swal2-mobile' : ''
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });

    // Prevent double tap zoom on buttons (iOS)
    document.querySelectorAll('button, a.btn').forEach(element => {
        let lastTap = 0;
        element.addEventListener('touchend', function(e) {
            const currentTime = new Date().getTime();
            const tapLength = currentTime - lastTap;
            
            if (tapLength < 500 && tapLength > 0) {
                e.preventDefault();
            }
            
            lastTap = currentTime;
        }, { passive: false });
    });

    // Auto dismiss alerts
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});
</script>

<style>
/* SweetAlert mobile optimization */
.swal2-mobile {
    padding: 1rem !important;
}

.swal2-mobile .swal2-popup {
    width: calc(100% - 2rem) !important;
    font-size: 0.9rem !important;
}

.swal2-mobile .swal2-title {
    font-size: 1.2rem !important;
}

.swal2-mobile .swal2-html-container {
    font-size: 0.85rem !important;
}
</style>

@endsection