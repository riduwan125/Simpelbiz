@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Edit Biaya Usaha</h3>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('modal-beban.update', $item->id_modal_beban) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label>Jenis</label>
            <select name="jenis" class="form-select" required>
                <option value="">-- Pilih Jenis --</option>
                <option value="modal_usaha" {{ old('jenis', $item->jenis) == 'modal_usaha' ? 'selected' : '' }}>
                    Modal Usaha (modal awal / investasi)
                </option>
                <option value="beban_operasional" {{ old('jenis', $item->jenis) == 'beban_operasional' ? 'selected' : '' }}>
                    Beban Operasional (listrik, sewa, bensin, dll)
                </option>
            </select>
        </div>

        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal_transaksi" class="form-control"
                   value="{{ old('tanggal_transaksi', $item->tanggal_transaksi) }}" required>
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <input type="text" name="deskripsi" class="form-control"
                   value="{{ old('deskripsi', $item->deskripsi) }}" required>
        </div>

        <div class="mb-3">
            <label>Nominal</label>
            <input type="number" name="nominal" class="form-control"
                   value="{{ old('nominal', $item->nominal) }}" required>
        </div>

        <button class="btn btn-primary">Update</button>
        <a href="{{ route('modal-beban.index') }}" class="btn btn-secondary">Kembali</a>
    </form>
</div>

@push('scripts')
<script>
    const selectJenis = document.querySelector('select[name="jenis"]');
    const jumlahGroup = document.getElementById('jumlahGroup');

    function toggleJumlah() {
        if (selectJenis.value === 'modal_usaha') {
            jumlahGroup.style.display = 'block';
        } else {
            jumlahGroup.style.display = 'none';
        }
    }

    selectJenis.addEventListener('change', toggleJumlah);
    toggleJumlah();
</script>
@endpush

@endsection
