@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Input Modal Usaha / Beban Operasional</h3>

    <form action="{{ route('modal-beban.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label>Jenis</label>
            <select name="jenis" class="form-select" required>
                <option value="">-- Pilih Jenis --</option>
                <option value="modal_usaha" {{ old('jenis')=='modal_usaha'?'selected':'' }}>
                    Modal Usaha (modal awal / investasi)
                </option>
                <option value="beban_operasional" {{ old('jenis')=='beban_operasional'?'selected':'' }}>
                    Beban Operasional (listrik, sewa, bensin, dll)
                </option>
            </select>
        </div>

        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal_transaksi" class="form-control"
                   value="{{ old('tanggal_transaksi', date('Y-m-d')) }}" required>
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <input type="text" name="deskripsi" class="form-control"
                   value="{{ old('deskripsi') }}" required>
        </div>

        <div class="mb-3">
            <label>Nominal</label>
            <input type="number" name="nominal" class="form-control"
                   value="{{ old('nominal') }}" required>
        </div>

        <button class="btn btn-primary">Simpan</button>
        <a href="{{ route('modal-beban.index') }}" class="btn btn-secondary">Kembali</a>
    </form>
</div>
@endsection
