@extends('layouts.app')

@section('content')

    <h5>📋 Daftar UMKM Terbaru</h5>
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama UMKM</th>
                <th>Pemilik</th>
                <th>Jenis Usaha</th>
                <th>Tanggal Daftar</th>
                <th class="text-center">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach(\App\Models\Umkm::with('user')->latest()->take(5)->get() as $item)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $item->nama_umkm }}</td>
                <td>{{ $item->user->nama_user ?? '-' }}</td>
                <td>{{ $item->jenis_usaha ?? '-' }}</td>
                <td>{{ $item->created_at->format('d-m-Y') }}</td>
                <td class="text-center">
                    <a href="{{ route('admin.umkm.show', $item->id_umkm) }}" class="btn btn-sm btn-info text-white">
                        <i class="bi bi-eye"></i> Lihat
                    </a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
