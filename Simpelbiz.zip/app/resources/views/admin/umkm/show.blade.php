@extends('layouts.app')

@section('content')
<div class="container py-4">
    
    {{-- Header with Breadcrumb --}}
    <div class="row mb-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" class="text-decoration-none">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('admin.umkm.index') }}" class="text-decoration-none">UMKM</a></li>
                    <li class="breadcrumb-item active">Detail</li>
                </ol>
            </nav>
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="fw-bold mb-0">Detail UMKM</h2>
                <a href="{{ route('admin.umkm.index') }}" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
            </div>
        </div>
    </div>

    {{-- UMKM Information Card --}}
    <div class="row g-4 mb-4">
        
        {{-- Main Info --}}
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary bg-opacity-10 rounded-circle p-2 me-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="text-primary" viewBox="0 0 16 16">
                                <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146Z"/>
                            </svg>
                        </div>
                        <div>
                            <h5 class="mb-0 fw-semibold">{{ $umkm->nama_umkm }}</h5>
                            <small class="text-muted">Informasi Usaha</small>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="d-flex align-items-start mb-3">
                                <div class="me-3">
                                    <i class="bi bi-person-circle text-primary fs-4"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Pemilik</small>
                                    <strong>{{ optional($umkm->user)->nama_user ?? '-' }}</strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-start mb-3">
                                <div class="me-3">
                                    <i class="bi bi-envelope text-primary fs-4"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Email</small>
                                    <strong>{{ optional($umkm->user)->email ?? '-' }}</strong>
                                    @if(optional($umkm->user)->email_verified_at)
                                        <span class="badge bg-success ms-2">
                                            <i class="bi bi-check-circle"></i> Verified
                                        </span>
                                    @else
                                        <span class="badge bg-warning ms-2">
                                            <i class="bi bi-exclamation-circle"></i> Unverified
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-start mb-3">
                                <div class="me-3">
                                    <i class="bi bi-calendar-check text-primary fs-4"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Tanggal Registrasi</small>
                                    <strong>{{ $umkm->created_at->format('d M Y') }}</strong>
                                    <small class="text-muted d-block">{{ $umkm->created_at->diffForHumans() }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-start mb-3">
                                <div class="me-3">
                                    <i class="bi bi-clock-history text-primary fs-4"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Terakhir Diperbarui</small>
                                    <strong>{{ $umkm->updated_at->format('d M Y') }}</strong>
                                    <small class="text-muted d-block">{{ $umkm->updated_at->diffForHumans() }}</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Statistics --}}
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body text-center">
                    <div class="bg-success bg-opacity-10 rounded-circle d-inline-flex p-3 mb-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="text-success" viewBox="0 0 16 16">
                            <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718H4zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73l.348.086z"/>
                        </svg>
                    </div>
                    <h6 class="text-muted mb-1 small">Total Transaksi</h6>
                    <h3 class="fw-bold mb-0">{{ number_format($umkm->catatanKeuangan->count()) }}</h3>
                    <small class="text-muted">Catatan Keuangan</small>
                </div>
            </div>

            @php
                $totalPemasukan = $umkm->catatanKeuangan->where('jenis_catatan', 'Pemasukan')->sum('nominal');
                $totalPengeluaran = $umkm->catatanKeuangan->where('jenis_catatan', 'Pengeluaran')->sum('nominal');
                $saldo = $totalPemasukan - $totalPengeluaran;
            @endphp

            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h6 class="text-muted mb-3 small">Ringkasan Keuangan</h6>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-muted small">Pemasukan</span>
                            <span class="fw-semibold text-success">Rp {{ number_format($totalPemasukan, 0, ',', '.') }}</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-success" style="width: 100%"></div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-muted small">Pengeluaran</span>
                            <span class="fw-semibold text-danger">Rp {{ number_format($totalPengeluaran, 0, ',', '.') }}</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-danger" style="width: {{ $totalPemasukan > 0 ? ($totalPengeluaran / $totalPemasukan * 100) : 0 }}%"></div>
                        </div>
                    </div>
                    <div class="pt-3 border-top">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-semibold">Saldo</span>
                            <span class="fw-bold {{ $saldo >= 0 ? 'text-primary' : 'text-danger' }}">
                                Rp {{ number_format($saldo, 0, ',', '.') }}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    {{-- Financial Records Table --}}
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0 fw-semibold">
                                <i class="bi bi-journal-text text-primary me-2"></i>
                                Catatan Keuangan
                            </h5>
                            <small class="text-muted">Riwayat transaksi terbaru</small>
                        </div>
                        @if($umkm->catatanKeuangan->count() > 0)
                            <span class="badge bg-primary rounded-pill">{{ $umkm->catatanKeuangan->count() }} Transaksi</span>
                        @endif
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="px-4 py-3 border-0">
                                        <i class="bi bi-calendar3 me-1"></i> Tanggal
                                    </th>
                                    <th class="py-3 border-0">
                                        <i class="bi bi-tag me-1"></i> Jenis
                                    </th>
                                    <th class="py-3 border-0">
                                        <i class="bi bi-card-text me-1"></i> Deskripsi
                                    </th>
                                    <th class="py-3 border-0 text-end pe-4">
                                        <i class="bi bi-cash me-1"></i> Nominal
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($umkm->catatanKeuangan->sortByDesc('tanggal_transaksi') as $c)
                                    <tr>
                                        <td class="px-4">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-light rounded p-2 me-2">
                                                    <i class="bi bi-calendar-event text-muted"></i>
                                                </div>
                                                <div>
                                                    <div class="fw-semibold">{{ \Carbon\Carbon::parse($c->tanggal_transaksi)->format('d M Y') }}</div>
                                                    <small class="text-muted">{{ \Carbon\Carbon::parse($c->tanggal_transaksi)->diffForHumans() }}</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            @if($c->jenis_catatan == 'Pemasukan')
                                                <span class="badge bg-success-subtle text-success px-3 py-2">
                                                    <i class="bi bi-arrow-down-circle me-1"></i> Pemasukan
                                                </span>
                                            @else
                                                <span class="badge bg-danger-subtle text-danger px-3 py-2">
                                                    <i class="bi bi-arrow-up-circle me-1"></i> Pengeluaran
                                                </span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width: 300px;" title="{{ $c->deskripsi }}">
                                                {{ $c->deskripsi }}
                                            </div>
                                        </td>
                                        <td class="text-end pe-4">
                                            <strong class="{{ $c->jenis_catatan == 'Pemasukan' ? 'text-success' : 'text-danger' }}">
                                                {{ $c->jenis_catatan == 'Pemasukan' ? '+' : '-' }} 
                                                Rp {{ number_format($c->nominal, 0, ',', '.') }}
                                            </strong>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center py-5">
                                            <div class="py-4">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="text-muted mb-3" viewBox="0 0 16 16">
                                                    <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                                                    <path d="M4 2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5v-2zm0 4a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm0 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm0 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm3-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm0 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm0 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm3-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm0 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-4z"/>
                                                </svg>
                                                <h6 class="text-muted mb-1">Belum Ada Catatan Keuangan</h6>
                                                <p class="text-muted small mb-0">Transaksi akan ditampilkan di sini</p>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
    .card {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .card:hover {
        transform: translateY(-2px);
    }

    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.03);
    }

    .bg-opacity-10 {
        --bs-bg-opacity: 0.1;
    }

    .badge {
        font-weight: 500;
    }

    .bg-success-subtle {
        background-color: rgba(25, 135, 84, 0.1);
    }

    .bg-danger-subtle {
        background-color: rgba(220, 53, 69, 0.1);
    }

    .breadcrumb-item + .breadcrumb-item::before {
        content: "›";
    }
</style>
@endsection