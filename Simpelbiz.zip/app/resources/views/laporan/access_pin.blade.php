<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masukkan PIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            background: #f0f2f5;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            padding: 20px 0;
        }
        
        .container {
            max-width: 450px;
            margin: 50px auto;
        }
        
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .card-body {
            padding: 35px;
        }
        
        h5 {
            color: #1c1e21;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .text-muted {
            color: #65676b !important;
            font-size: 14px;
        }
        
        .email-badge {
            display: inline-block;
            background: #e7f3ff;
            color: #1877f2;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
            margin: 15px 0;
        }
        
        .pin-input {
            font-size: 24px;
            font-weight: 600;
            letter-spacing: 12px;
            text-align: center;
            padding: 18px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-family: monospace;
            transition: all 0.2s ease;
            background: white !important;
        }
        
        .pin-input:focus {
            border-color: #1877f2;
            box-shadow: 0 0 0 3px rgba(24, 119, 242, 0.1);
            outline: none;
        }
        
        .pin-input.expired {
            background: #f5f5f5 !important;
            opacity: 0.7;
            cursor: not-allowed;
        }
        
        .btn {
            padding: 12px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.2s ease;
        }
        
        .btn-primary {
            background: #1877f2;
            border: none;
        }
        
        .btn-primary:hover:not(:disabled) {
            background: #166fe5;
        }
        
        .btn-primary:disabled {
            background: #e4e6eb;
            color: #bcc0c4;
            cursor: not-allowed;
        }
        
        .btn-outline-secondary {
            border: 1px solid #ccc;
            color: #555;
        }
        
        .btn-outline-secondary:hover {
            background: #f5f5f5;
            border-color: #999;
        }
        
        .alert {
            border-radius: 8px;
            padding: 12px 16px;
            font-size: 14px;
        }
        
        .info-text {
            font-size: 13px;
            color: #65676b;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e4e6eb;
        }
        
        .pin-indicator {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-bottom: 15px;
        }
        
        .pin-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #e4e6eb;
            transition: background 0.2s ease;
        }
        
        .pin-dot.filled {
            background: #1877f2;
        }
        
        @media (max-width: 576px) {
            .card-body {
                padding: 25px 20px;
            }
            
            .pin-input {
                font-size: 20px;
                letter-spacing: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <h5>Masukkan PIN Akses</h5>
                <p class="text-muted">PIN sudah dikirim ke email:</p>
                
                <div class="email-badge">{{ $accessPin->email }}</div>

                @if (session('status'))
                    <div class="alert alert-success">{{ session('status') }}</div>
                @endif

                @if(!empty($expired))
                    {{-- ✅ PIN expired atau sudah dipakai: tampilkan pesan + tombol minta PIN baru --}}
                    <div class="alert alert-danger">
                        ⚠️ {{ $pinError }}
                    </div>

                    <form method="POST" action="{{ route('laporan.access.pin.resend') }}">
                        @csrf
                        <input type="hidden" name="laporan_id" value="{{ $accessPin->laporan_id }}">
                        <input type="hidden" name="email" value="{{ $accessPin->email }}">
                        <button type="submit" class="btn btn-primary w-100 mb-2">
                            🔄 Minta PIN Baru
                        </button>
                    </form>

                    <a href="{{ route('login') }}" class="btn btn-link w-100 text-muted">
                        Kembali ke Login
                    </a>

                @else
                    {{-- ✅ Form PIN normal --}}
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            @foreach ($errors->all() as $error)
                                <div>{{ $error }}</div>
                            @endforeach
                        </div>
                    @endif

                    <form method="POST" action="{{ route('laporan.access.verify-pin') }}" id="pinForm">
                        @csrf
                        <input type="hidden" name="access_id" value="{{ $accessPin->id }}">

                        <div class="mb-3">
                            <label class="form-label">PIN 6 Digit</label>
                            
                            <div class="pin-indicator">
                                <div class="pin-dot" data-index="0"></div>
                                <div class="pin-dot" data-index="1"></div>
                                <div class="pin-dot" data-index="2"></div>
                                <div class="pin-dot" data-index="3"></div>
                                <div class="pin-dot" data-index="4"></div>
                                <div class="pin-dot" data-index="5"></div>
                            </div>
                            
                            <input
                                type="tel"
                                name="pin"
                                id="pinInput"
                                maxlength="6"
                                class="form-control pin-input @error('pin') is-invalid @enderror"
                                placeholder="000000"
                                required
                                autofocus
                                autocomplete="off"
                            >
                            @error('pin')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mb-2" id="submitBtn" disabled>
                            Verifikasi &amp; Unduh Laporan
                        </button>
                    </form>
                        
                    <form method="POST" action="{{ route('laporan.access.pin.resend') }}" class="mb-2">
                        @csrf
                        <input type="hidden" name="laporan_id" value="{{ $accessPin->laporan_id }}">
                        <input type="hidden" name="email" value="{{ $accessPin->email }}">
                        <button type="submit" class="btn btn-outline-secondary w-100">
                            Minta PIN Baru
                        </button>
                    </form>
                    
                    <a href="{{ route('login') }}" class="btn btn-link w-100 text-muted">
                        Kembali ke Login
                    </a>

                    <div class="info-text" id="infoText">
                        💡 PIN hanya berlaku <strong><span id="countdown">--:--</span></strong>. Jika tidak masuk email, cek folder spam.
                    </div>

                @endif
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    @if(empty($expired))
    <script>
        const pinInput  = document.getElementById('pinInput');
        const submitBtn = document.getElementById('submitBtn');
        const pinForm   = document.getElementById('pinForm');
        const pinDots   = document.querySelectorAll('.pin-dot');
        const countdown = document.getElementById('countdown');
        const infoText  = document.getElementById('infoText');

        // ✅ FIX UTAMA: pakai Unix timestamp dari server (UTC murni)
        // Tidak pakai string date yang bisa salah parse karena timezone browser
        // ->utc()->timestamp = detik sejak epoch, dikali 1000 = milidetik untuk JS
        const expiresAt = {{ $accessPin->expires_at->utc()->timestamp }} * 1000;

        let isExpired     = false;
        let timerInterval = null;

        // Update dot indicators
        function updateDots(val) {
            pinDots.forEach((dot, i) => dot.classList.toggle('filled', i < val.length));
        }

        // Input: hanya angka, max 6 digit
        pinInput.addEventListener('input', function () {
            if (isExpired) { this.value = ''; return; }
            this.value = this.value.replace(/\D/g, '').substring(0, 6);
            updateDots(this.value);
            submitBtn.disabled = (this.value.length !== 6);
        });

        // Paste handler
        pinInput.addEventListener('paste', function (e) {
            if (isExpired) { e.preventDefault(); return; }
            e.preventDefault();
            const pasted = (e.clipboardData || window.clipboardData).getData('text');
            this.value   = pasted.replace(/\D/g, '').substring(0, 6);
            this.dispatchEvent(new Event('input', { bubbles: true }));
        });

        // Timer countdown — dihitung dari expiresAt server, bukan waktu load
        function updateTimer() {
            const timeLeft = Math.floor((expiresAt - Date.now()) / 1000);

            if (timeLeft <= 0) {
                if (!isExpired) {
                    isExpired = true;
                    clearInterval(timerInterval);

                    countdown.textContent = 'kedaluwarsa';
                    countdown.style.color = '#d32f2f';

                    submitBtn.disabled    = true;
                    submitBtn.textContent = 'PIN Kedaluwarsa';
                    pinInput.disabled     = true;
                    pinInput.classList.add('expired');
                    pinInput.value        = '';
                    pinDots.forEach(d => d.classList.remove('filled'));

                    infoText.innerHTML = '⚠️ <strong style="color:#d32f2f;">PIN sudah kedaluwarsa!</strong> Klik "Minta PIN Baru" untuk mendapatkan PIN baru.';
                }
                return;
            }

            const menit = Math.floor(timeLeft / 60);
            const detik = timeLeft % 60;
            countdown.textContent = menit + ':' + String(detik).padStart(2, '0');
            countdown.style.color = timeLeft <= 30 ? '#d32f2f' : '';
        }

        // Jalankan langsung saat halaman load, lalu tiap 1 detik
        updateTimer();
        timerInterval = setInterval(updateTimer, 1000);

        // Cegah submit jika sudah expired
        pinForm.addEventListener('submit', function (e) {
            if (isExpired || Date.now() > expiresAt) {
                e.preventDefault();
                alert('PIN sudah kedaluwarsa! Silakan minta PIN baru.');
                return false;
            }
            if (pinInput.value.length !== 6) {
                e.preventDefault();
                return false;
            }
            submitBtn.disabled    = true;
            submitBtn.textContent = 'Memverifikasi...';
        });

        setTimeout(() => pinInput.focus(), 100);
    </script>
    @endif
</body>
</html>