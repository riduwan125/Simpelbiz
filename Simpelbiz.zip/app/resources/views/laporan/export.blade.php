<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laporan Keuangan</title>
    <style>
        body { font-family: "DejaVu Sans", sans-serif; padding: 40px 35px; font-size: 11px; color:#111; }
        .header { text-align:center; margin-bottom: 20px; }
        .header h2 { margin:0; font-size:16px; }
        .header p { margin:2px 0; }

        table { border-collapse: collapse; width:100%; margin-top: 8px; }
        th, td { border:1px solid #444; padding:5px 6px; }
        th { background:#f0f0f0; }
        .right { text-align:right; }
        .center { text-align:center; }
        .section-title { font-weight:bold; margin-top: 18px; margin-bottom: 6px; }
        .qr-wrapper { margin-top: 22px; text-align:center; }
        .qr-wrapper img { width:120px; height:120px; }
        .qr-caption { font-size: 10px; margin-top: 6px; }
    </style>
</head>
<body>

<div class="header">
    <h2>Laporan Keuangan {{ $umkm->nama_umkm ?? 'UMKM' }}</h2>
    <p>Periode: {{ str_pad($bulan, 2, '0', STR_PAD_LEFT) }} / {{ $tahun }}</p>
    <p>Dicetak dari Sistem Pencatatan Keuangan UMKM</p>
</div>

<div class="section-title">Rincian Transaksi</div>
<table>
    <thead>
        <tr>
            <th style="width:5%;">No</th>
            <th style="width:15%;">Tanggal</th>
            <th style="width:40%;">Keterangan</th>
            <th style="width:15%;">Jenis</th>
            <th style="width:15%;">Nominal</th>
        </tr>
    </thead>
    <tbody>
        @php $no=1; @endphp
        @foreach($catatan as $c)
        <tr>
            <td class="center">{{ $no++ }}</td>
            <td class="center">{{ \Carbon\Carbon::parse($c->tanggal_transaksi)->format('d/m/Y') }}</td>
            <td>{{ $c->deskripsi ?? '-' }}</td>
            <td class="center">{{ ucfirst($c->jenis_catatan) }}</td>
            <td class="right">Rp {{ number_format($c->nominal, 0, ',', '.') }}</td>
        </tr>
        @endforeach
    </tbody>
</table>

<div class="section-title">Rekapitulasi</div>
<table>
    <tbody>
        <tr><td>Total Pemasukan</td><td class="right">Rp {{ number_format($totalPemasukan, 0, ',', '.') }}</td></tr>
        <tr><td>Total Pengeluaran</td><td class="right">Rp {{ number_format($totalPengeluaran, 0, ',', '.') }}</td></tr>
        <tr><td>Modal Usaha</td><td class="right">Rp {{ number_format($modalUsaha, 0, ',', '.') }}</td></tr>
        <tr><td>Beban Operasional</td><td class="right">Rp {{ number_format($bebanOperasional, 0, ',', '.') }}</td></tr>
        <tr><th>Laba Kotor</th><th class="right">Rp {{ number_format($labaKotor, 0, ',', '.') }}</th></tr>
        <tr><th>Laba Bersih</th><th class="right">Rp {{ number_format($labaBersih, 0, ',', '.') }}</th></tr>
    </tbody>
</table>

</body>
</html>
