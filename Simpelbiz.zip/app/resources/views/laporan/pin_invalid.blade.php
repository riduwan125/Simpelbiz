<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masukkan PIN Akses</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .card {
            background: white;
            border-radius: 16px;
            padding: 36px 28px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }

        h2 {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 4px;
        }

        .subtitle {
            font-size: 13px;
            color: #888;
            margin-bottom: 16px;
        }

        .email-badge {
            display: inline-block;
            background: #e8f5e9;
            color: #2e7d32;
            border-radius: 20px;
            padding: 5px 14px;
            font-size: 13px;
            margin-bottom: 16px;
        }

        .alert-success {
            background: #e8f5e9;
            border: 1px solid #c8e6c9;
            color: #2e7d32;
            border-radius: 8px;
            padding: 12px 14px;
            font-size: 13px;
            margin-bottom: 20px;
        }

        .alert-error {
            background: #ffebee;
            border: 1px solid #ffcdd2;
            color: #c62828;
            border-radius: 8px;
            padding: 12px 14px;
            font-size: 13px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .pin-label {
            font-size: 13px;
            font-weight: 600;
            color: #555;
            margin-bottom: 10px;
        }

        /* Dot indicators */
        .pin-dots {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 12px;
        }

        .pin-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #ddd;
            transition: background 0.2s;
        }

        .pin-dot.filled {
            background: #1976d2;
        }

        /* PIN input */
        .pin-input-wrapper {
            position: relative;
            margin-bottom: 20px;
        }

        .pin-input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #1976d2;
            border-radius: 10px;
            font-size: 22px;
            letter-spacing: 10px;
            text-align: center;
            outline: none;
            color: #1a1a2e;
            background: white;
        }

        .pin-input:focus {
            border-color: #1565c0;
            box-shadow: 0 0 0 3px rgba(25,118,210,0.15);
        }

        .pin-input.is-invalid {
            border-color: #e53935;
        }

        .invalid-feedback {
            color: #e53935;
            font-size: 12px;
            margin-top: 6px;
        }

        /* Buttons */
        .btn {
            display: block;
            width: 100%;
            padding: 13px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            margin-bottom: 10px;
            transition: background 0.2s, opacity 0.2s;
        }

        .btn-primary {
            background: #1976d2;
            color: white;
        }

        .btn-primary:hover:not(:disabled) { background: #1565c0; }
        .btn-primary:disabled {
            background: #b0bec5;
            cursor: not-allowed;
        }

        .btn-outline {
            background: white;
            color: #555;
            border: 1px solid #ddd;
        }

        .btn-outline:hover { background: #f5f5f5; }

        .btn-resend {
            background: white;
            color: #1976d2;
            border: 1.5px solid #1976d2;
        }

        .btn-resend:hover { background: #e3f2fd; }

        /* Link */
        .link-back {
            display: block;
            text-align: center;
            color: #888;
            font-size: 13px;
            text-decoration: underline;
            margin-top: 4px;
        }

        /* Timer */
        .timer-info {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            color: #888;
            margin-top: 16px;
        }

        .timer-info span#timer {
            font-weight: 700;
            color: #e65100;
        }

        .divider {
            border: none;
            border-top: 1px solid #eee;
            margin: 16px 0;
        }
    </style>
</head>
<body>
<div class="card">
    <h2>Masukkan PIN Akses</h2>
    <p class="subtitle">PIN sudah dikirim ke email:</p>

    <div class="email-badge">{{ $accessPin->email }}</div>

    {{-- Status sukses kirim PIN --}}
    @if(session('status'))
        <div class="alert-success">{{ session('status') }}</div>
    @endif

    {{-- Jika PIN expired atau sudah dipakai --}}
    @if(!empty($expired))

        <div class="alert-error">
            ⚠️ {{ $pinError }}
        </div>

        <form method="POST" action="{{ route('laporan.access.pin.resend') }}">
            @csrf
            <input type="hidden" name="laporan_id" value="{{ $accessPin->laporan_id }}">
            <input type="hidden" name="email" value="{{ $accessPin->email }}">
            <button type="submit" class="btn btn-resend">🔄 Minta PIN Baru</button>
        </form>

        <a href="{{ route('login') }}" class="link-back">← Kembali ke Login</a>

    @else

        {{-- Error PIN salah dari verifyPin() --}}
        @if($errors->has('pin'))
            <div class="alert-error">⚠️ {{ $errors->first('pin') }}</div>
        @endif

        <p class="pin-label">PIN 6 Digit</p>

        {{-- Dot indicators --}}
        <div class="pin-dots">
            @for($i = 0; $i < 6; $i++)
                <div class="pin-dot" id="dot-{{ $i }}"></div>
            @endfor
        </div>

        <form method="POST" action="{{ route('laporan.access.verify-pin') }}" id="pin-form">
            @csrf
            <input type="hidden" name="access_id" value="{{ $accessPin->id }}">

            <div class="pin-input-wrapper">
                <input
                    type="text"
                    name="pin"
                    id="pin-input"
                    class="pin-input {{ $errors->has('pin') ? 'is-invalid' : '' }}"
                    maxlength="6"
                    inputmode="numeric"
                    pattern="[0-9]*"
                    autocomplete="one-time-code"
                    autofocus
                    placeholder="● ● ● ● ● ●"
                >
                @if($errors->has('pin'))
                    <div class="invalid-feedback">{{ $errors->first('pin') }}</div>
                @endif
            </div>

            <button type="submit" class="btn btn-primary" id="btn-verify" disabled>
                Verifikasi &amp; Unduh Laporan
            </button>
        </form>

        <hr class="divider">

        <form method="POST" action="{{ route('laporan.access.pin.resend') }}">
            @csrf
            <input type="hidden" name="laporan_id" value="{{ $accessPin->laporan_id }}">
            <input type="hidden" name="email" value="{{ $accessPin->email }}">
            <button type="submit" class="btn btn-outline">Minta PIN Baru</button>
        </form>

        <a href="{{ route('login') }}" class="link-back">← Kembali ke Login</a>

        {{-- ✅ FIX TIMER: dihitung dari expires_at server, bukan dari waktu load --}}
        <div class="timer-info">
            💡 PIN hanya berlaku <span id="timer">--:--</span>.
            Jika tidak masuk email, cek folder spam.
        </div>

        <script>
            // Ambil expires_at dari server dalam format ISO agar akurat
            const expiresAt = new Date("{{ $accessPin->expires_at->toIso8601String() }}").getTime();

            const timerEl  = document.getElementById('timer');
            const btnVerify = document.getElementById('btn-verify');
            const pinInput  = document.getElementById('pin-input');

            // Update dot indicators saat user mengetik
            pinInput.addEventListener('input', function () {
                // Hanya izinkan angka
                this.value = this.value.replace(/[^0-9]/g, '');

                const len = this.value.length;
                for (let i = 0; i < 6; i++) {
                    const dot = document.getElementById('dot-' + i);
                    dot.classList.toggle('filled', i < len);
                }

                // Aktifkan tombol hanya jika 6 digit sudah diisi
                btnVerify.disabled = (len < 6);
            });

            function updateTimer() {
                const now      = new Date().getTime();
                const timeLeft = Math.floor((expiresAt - now) / 1000);

                if (timeLeft <= 0) {
                    timerEl.textContent = 'kedaluwarsa';
                    timerEl.style.color = '#e53935';
                    btnVerify.disabled  = true;
                    pinInput.disabled   = true;
                    clearInterval(interval);
                    return;
                }

                const menit = Math.floor(timeLeft / 60);
                const detik = timeLeft % 60;
                timerEl.textContent = menit + ':' + String(detik).padStart(2, '0');

                // Warna merah saat kurang dari 30 detik
                timerEl.style.color = timeLeft <= 30 ? '#e53935' : '#e65100';
            }

            updateTimer(); // jalankan langsung saat halaman load
            const interval = setInterval(updateTimer, 1000);
        </script>

    @endif
</div>
</body>
</html>