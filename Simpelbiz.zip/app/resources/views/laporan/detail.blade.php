@extends('layouts.app')
@section('title', 'Detail Laporan Keuangan')
@section('content')
<div class="container py-4">
    <h3 class="fw-bold mb-2">Detail Laporan Keuangan</h3>
    <p class="text-muted">
        Periode:
        {{ \Carbon\Carbon::create($tahun, $bulan, 1)->translatedFormat('F Y') }}
    </p>
    
    <!-- Summary Card - Responsif untuk mobile -->
    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-12 col-sm-4">
                    <small class="text-muted d-block mb-1">Total Pemasukan</small>
                    <strong class="text-success">Rp {{ number_format($totalPemasukan, 0, ',', '.') }}</strong>
                </div>
                <div class="col-12 col-sm-4">
                    <small class="text-muted d-block mb-1">Total Pengeluaran</small>
                    <strong class="text-danger">Rp {{ number_format($totalPengeluaran, 0, ',', '.') }}</strong>
                </div>
                <div class="col-12 col-sm-4">
                    <small class="text-muted d-block mb-1">Saldo Bersih</small>
                    <strong class="{{ ($totalPemasukan - $totalPengeluaran) >= 0 ? 'text-success' : 'text-danger' }}">
                        Rp {{ number_format($totalPemasukan - $totalPengeluaran, 0, ',', '.') }}
                    </strong>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Desktop Table View -->
    <div class="card border-0 shadow-sm d-none d-md-block">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped align-middle text-center mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Jenis</th>
                            <th>Deskripsi</th>
                            <th>Jumlah</th>
                            <th>Nominal</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($catatan as $i => $row)
                            <tr>
                                <td>{{ $i + 1 }}</td>
                                <td>{{ \Carbon\Carbon::parse($row->tanggal_transaksi)->format('d-m-Y') }}</td>
                                <td class="text-capitalize">{{ $row->jenis_catatan }}</td>
                                <td class="text-start">{{ $row->deskripsi }}</td>
                                <td>{{ number_format($row->jumlah, 0, ',', '.') }}</td>
                                <td>Rp {{ number_format($row->nominal, 0, ',', '.') }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-muted py-4">
                                    Tidak ada catatan keuangan pada periode ini.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="mt-3 text-end">
                <a href="{{ route('laporan.index') }}" class="btn btn-secondary">Kembali ke Laporan</a>
            </div>
        </div>
    </div>
    
    <!-- Mobile Card View -->
    <div class="d-md-none">
        @forelse($catatan as $i => $row)
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge bg-{{ $row->jenis_catatan == 'pemasukan' ? 'success' : 'danger' }}">
                            {{ ucfirst($row->jenis_catatan) }}
                        </span>
                        <small class="text-muted">
                            {{ \Carbon\Carbon::parse($row->tanggal_transaksi)->format('d/m/Y') }}
                        </small>
                    </div>
                    <h6 class="mb-2">{{ $row->deskripsi }}</h6>
                    <div class="row g-2">
                        <div class="col-6">
                            <small class="text-muted d-block">Jumlah</small>
                            <strong>{{ number_format($row->jumlah, 0, ',', '.') }}</strong>
                        </div>
                        <div class="col-6 text-end">
                            <small class="text-muted d-block">Nominal</small>
                            <strong class="text-{{ $row->jenis_catatan == 'pemasukan' ? 'success' : 'danger' }}">
                                Rp {{ number_format($row->nominal, 0, ',', '.') }}
                            </strong>
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center text-muted py-5">
                    <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                    Tidak ada catatan keuangan pada periode ini.
                </div>
            </div>
        @endforelse
        
        <div class="mt-3 d-grid">
            <a href="{{ route('laporan.index') }}" class="btn btn-secondary">Kembali ke Laporan</a>
        </div>
    </div>
</div>

<style>
@media (max-width: 767.98px) {
    .container {
        padding-left: 0.75rem;
        padding-right: 0.75rem;
    }
    
    h3 {
        font-size: 1.25rem;
    }
    
    .card-body {
        padding: 1rem;
    }
}
</style>
@endsection