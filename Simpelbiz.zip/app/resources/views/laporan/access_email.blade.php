<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Verifikasi Email</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body { 
            background: #f5f7fa;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            max-width: 420px;
            width: 100%;
        }

        /* Card Container */
        .card-container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }

        /* Card Body */
        .card-body {
            padding: 32px 24px;
        }

        /* Icon Header */
        .icon-header {
            width: 64px;
            height: 64px;
            background: #f0f2f5;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }

        .icon-header i {
            font-size: 32px;
            color: #6b7280;
        }

        .header-text {
            text-align: center;
            margin-bottom: 24px;
        }

        .header-text h1 {
            font-size: 20px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 6px;
        }

        .header-text p {
            color: #6b7280;
            font-size: 14px;
            margin: 0;
        }

        /* Info Box - Styled seperti gambar */
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 10px;
            padding: 14px;
            margin-bottom: 20px;
            display: flex;
            gap: 12px;
        }

        .info-box-icon {
            flex-shrink: 0;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .info-box-icon i {
            color: #2563eb;
            font-size: 16px;
        }

        .info-box-content {
            flex: 1;
        }

        .info-box-title {
            font-weight: 600;
            color: #1e40af;
            font-size: 13px;
            margin-bottom: 6px;
        }

        .info-box-text {
            color: #1e40af;
            font-size: 13px;
            line-height: 1.5;
            margin: 0;
        }

        .divider-text {
            text-align: center;
            color: #9ca3af;
            font-size: 13px;
            margin: 16px 0;
        }

        /* Alerts */
        .alert {
            border: none;
            border-radius: 10px;
            padding: 14px 16px;
            font-size: 14px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
        }

        .alert-danger {
            background: #fee2e2;
            color: #991b1b;
        }

        .alert i {
            font-size: 18px;
        }

        /* Form */
        .form-label {
            font-weight: 500;
            color: #374151;
            font-size: 14px;
            margin-bottom: 8px;
            display: block;
        }

        .form-control {
            border: 1px solid #d1d5db;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 14px;
            width: 100%;
            transition: all 0.2s;
            background: white;
        }

        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            outline: none;
        }

        .form-control.is-invalid {
            border-color: #ef4444;
        }

        .form-control.is-invalid:focus {
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
        }

        .invalid-feedback {
            color: #dc2626;
            font-size: 13px;
            margin-top: 6px;
            display: block;
        }

        /* Buttons */
        .btn {
            padding: 13px 20px;
            border-radius: 10px;
            font-weight: 500;
            font-size: 14px;
            transition: all 0.2s;
            border: none;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            cursor: pointer;
        }

        .btn-primary {
            background: #3b82f6;
            color: white;
        }

        .btn-primary:hover:not(:disabled) {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
            background: white;
            color: #4b5563;
            border: 1px solid #d1d5db;
        }

        .btn-secondary:hover {
            background: #f9fafb;
        }

        .btn i {
            font-size: 16px;
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        /* Notes Section */
        .notes-section {
            background: #f9fafb;
            border-radius: 10px;
            padding: 16px;
            margin-top: 20px;
        }

        .notes-section strong {
            display: block;
            color: #374151;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .notes-section ul {
            margin: 0;
            padding-left: 20px;
            color: #6b7280;
            font-size: 13px;
        }

        .notes-section li {
            margin-bottom: 6px;
            line-height: 1.4;
        }

        /* Footer */
        .card-footer {
            background: #f9fafb;
            border-top: 1px solid #e5e7eb;
            padding: 20px 24px;
            text-align: center;
        }

        .card-footer p {
            margin: 0;
            color: #6b7280;
            font-size: 14px;
        }

        .card-footer a {
            color: #3b82f6;
            text-decoration: none;
            font-weight: 500;
        }

        .card-footer a:hover {
            color: #2563eb;
            text-decoration: underline;
        }

        /* Debug Box */
        .debug-box {
            margin-top: 16px;
            padding: 12px;
            background: #fef3c7;
            border: 1px solid #fcd34d;
            border-radius: 8px;
            font-size: 12px;
            color: #92400e;
            font-family: 'Courier New', monospace;
        }

        .debug-box strong {
            display: block;
            margin-bottom: 6px;
        }

        .mb-3 {
            margin-bottom: 20px;
        }

        .mb-2 {
            margin-bottom: 12px;
        }

        @media (max-width: 576px) {
            .card-body {
                padding: 28px 20px;
            }

            .card-footer {
                padding: 18px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card-container">
            <div class="card-body">
                <!-- Icon & Header -->
                <div class="icon-header">
                    <i class="bi bi-envelope"></i>
                </div>

                <div class="header-text">
                    <h1>Verifikasi Email</h1>
                    <p>Masukkan email untuk menerima kode akses</p>
                </div>

                <!-- Success Alert -->
                @if (session('status'))
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle-fill"></i>
                        <span>{{ session('status') }}</span>
                    </div>
                @endif

                <!-- Error Alert -->
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-circle-fill"></i>
                        <span>
                            @foreach ($errors->all() as $error)
                                {{ $error }}
                            @endforeach
                        </span>
                    </div>
                @endif

                <!-- Info Box -->
                <div class="info-box">
                    <div class="info-box-icon">
                        <i class="bi bi-info-circle-fill"></i>
                    </div>
                    <div class="info-box-content">
                        <div class="info-box-title">Informasi</div>
                        <p class="info-box-text">
                            Masukkan email pemilik untuk menerima kode PIN. Kode akan dikirim ke email yang terdaftar dan berlaku selama 2 menit.
                        </p>
                    </div>
                </div>

                <div class="divider-text">atau</div>

                <!-- Form -->
                <form method="POST" action="{{ 
                    isset($qr_id) 
                        ? route('laporan.request-pin.short') 
                        : (isset($token) 
                            ? route('laporan.access.pin.request.token') 
                            : route('laporan.access.request-pin'))
                }}" id="pinForm">
                    @csrf

                    <!-- Hidden Inputs -->
                    @if(isset($qr_id))
                        <input type="hidden" name="qr_id" value="{{ $qr_id }}">
                    @elseif(isset($token))
                        <input type="hidden" name="token" value="{{ $token }}">
                    @else
                        <input type="hidden" name="laporan_id" value="{{ $laporan->id_laporan }}">
                    @endif

                    <!-- Email Input -->
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email"
                               name="email"
                               class="form-control @error('email') is-invalid @enderror"
                               value="{{ old('email') }}"
                               placeholder="contoh@email.com"
                               required 
                               autofocus>
                        @error('email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary mb-2" id="submitBtn">
                        <i class="bi bi-send-fill"></i>
                        <span>Kirim PIN ke Email</span>
                    </button>

                    <!-- Back Button -->
                    <a href="{{ route('login') }}" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i>
                        <span>Kembali ke Login</span>
                    </a>
                </form>

                <!-- Notes -->
                <div class="notes-section">
                    <strong>Catatan Penting:</strong>
                    <ul>
                        <li>PIN hanya dikirim ke email yang terdaftar</li>
                        <li>Kode verifikasi berlaku selama 2 menit</li>
                        <li>Periksa folder spam jika email tidak masuk</li>
                        <li>Pastikan email yang dimasukkan benar</li>
                    </ul>
                </div>

                <!-- Debug -->
                @if(config('app.debug'))
                    <div class="debug-box">
                        <strong>Debug Information:</strong>
                        @if(isset($qr_id))
                            Access Method: QR Code<br>
                            QR ID: {{ $qr_id }}
                        @elseif(isset($token))
                            Access Method: Token<br>
                            Token: {{ substr($token, 0, 20) }}...
                        @else
                            Access Method: Direct ID<br>
                            Laporan ID: {{ $laporan->id_laporan ?? 'N/A' }}
                        @endif
                    </div>
                @endif
            </div>

            <!-- Footer -->
            <div class="card-footer">
                <p>
                    Belum punya akun? 
                    <a href="{{ route('register') }}">Daftar Sekarang</a>
                </p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Loading state pada submit
        document.getElementById('pinForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('submitBtn');
            btn.disabled = true;
            btn.innerHTML = '<i class="bi bi-hourglass-split"></i><span>Mengirim...</span>';
        });

        // Auto focus pada input email
        window.addEventListener('load', function() {
            const emailInput = document.querySelector('input[name="email"]');
            if (emailInput && !emailInput.value) {
                emailInput.focus();
            }
        });
    </script>
</body>
</html>