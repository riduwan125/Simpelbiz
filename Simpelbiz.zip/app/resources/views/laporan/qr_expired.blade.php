<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Kedaluwarsa</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            background: #f5f7fa;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            max-width: 450px;
            width: 100%;
            overflow: hidden;
            animation: fadeIn 0.4s ease-out;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .content {
            padding: 40px 32px;
            text-align: center;
        }
        
        .icon {
            width: 64px;
            height: 64px;
            background: #fee2e2;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            font-size: 32px;
        }
        
        h1 {
            color: #1f2937;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 8px;
            line-height: 1.3;
        }
        
        .status {
            display: inline-block;
            background: #fee2e2;
            color: #991b1b;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 20px;
            letter-spacing: 0.5px;
        }
        
        .message {
            color: #6b7280;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 24px;
        }
        
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 24px;
            text-align: left;
        }
        
        .info-box-header {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
        }
        
        .info-box-header svg {
            width: 20px;
            height: 20px;
            color: #2563eb;
            flex-shrink: 0;
        }
        
        .info-box-title {
            color: #1e40af;
            font-size: 13px;
            font-weight: 600;
        }
        
        .info-box ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .info-box li {
            color: #1e40af;
            font-size: 13px;
            line-height: 1.6;
            margin-bottom: 6px;
            padding-left: 20px;
            position: relative;
        }
        
        .info-box li:before {
            content: "•";
            position: absolute;
            left: 8px;
            font-weight: bold;
        }
        
        .info-box li:last-child {
            margin-bottom: 0;
        }
        
        .info-box strong {
            font-weight: 600;
        }
        
        .action-text {
            color: #6b7280;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .highlight {
            color: #3b82f6;
            font-weight: 600;
        }
        
        .btn-back {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            background: white;
            color: #4b5563;
            border: 1px solid #d1d5db;
            padding: 12px 24px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s;
            cursor: pointer;
        }
        
        .btn-back:hover {
            background: #f9fafb;
            border-color: #9ca3af;
        }
        
        .btn-back svg {
            width: 20px;
            height: 20px;
        }
        
        .footer {
            background: #f9fafb;
            border-top: 1px solid #e5e7eb;
            padding: 20px 32px;
            text-align: center;
        }
        
        .footer p {
            color: #6b7280;
            font-size: 14px;
            margin: 0;
        }
        
        .footer a {
            color: #3b82f6;
            text-decoration: none;
            font-weight: 500;
        }
        
        .footer a:hover {
            color: #2563eb;
            text-decoration: underline;
        }
        
        @media (max-width: 576px) {
            .content {
                padding: 32px 24px;
            }
            
            .footer {
                padding: 18px 24px;
            }
            
            h1 {
                font-size: 18px;
            }
            
            .icon {
                width: 56px;
                height: 56px;
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <div class="icon">❌</div>
            
            <div class="status">KEDALUWARSA</div>
            
            <h1>QR Code Tidak Dapat Diakses</h1>
            
            <p class="message">
                Maaf, QR code yang Anda scan sudah melewati masa berlaku dan tidak dapat digunakan lagi.
            </p>
            
            <div class="info-box">
                <div class="info-box-header">
                    <svg fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                    </svg>
                    <span class="info-box-title">Informasi Penting</span>
                </div>
                <ul>
                    <li>QR code laporan berlaku selama <strong>5 hari</strong></li>
                    <li>Link akan otomatis non-aktif setelah periode tersebut</li>
                    <li>Ini untuk menjaga keamanan dan validitas data</li>
                </ul>
            </div>
            
            <p class="action-text">
                Untuk mengakses laporan terbaru, silakan hubungi <span class="highlight">Pegawai UMKM</span> untuk membuat QR code baru.
            </p>
            
            <div style="margin-top: 24px;">
                <a href="{{ route('login') }}" class="btn-back">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                    </svg>
                    <span>Kembali ke Login</span>
                </a>
            </div>
        </div>
        
        <div class="footer">
            <p>
                Butuh bantuan? 
                <a href="#">Hubungi Support</a>
            </p>
        </div>
    </div>
</body>
</html>