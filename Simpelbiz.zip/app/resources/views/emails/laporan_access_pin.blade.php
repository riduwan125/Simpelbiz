@php
    $laporan = $accessPin->laporan;
@endphp

<p>Halo,</p>

<p>Berikut PIN untuk mengakses laporan keuangan UMKM:</p>

<p>
    <strong>UMKM:</strong> {{ $laporan->umkm->nama_umkm ?? 'UMKM' }}<br>
    <strong>Periode:</strong> {{ $laporan->bulan }}/{{ $laporan->tahun }}<br>
    <strong>PIN Akses:</strong> <span style="font-size: 18px">{{ $accessPin->pin }}</span><br>
    <strong>Berlaku sampai:</strong> {{ $accessPin->expires_at->format('d-m-Y H:i') }}
</p>

<p>Silakan kembali ke halaman scan laporan dan masukkan PIN di atas untuk mengunduh PDF.</p>

<p>Terima kasih.</p>
