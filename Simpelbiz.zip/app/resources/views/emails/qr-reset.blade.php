<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Akun UMKM via QR Code</title>
</head>
<body style="font-family: Arial, sans-serif; color:#111; background:#f7f7f9; padding:20px;">
  <table width="100%" cellpadding="0" cellspacing="0"
         style="max-width:520px;margin:0 auto;background:#ffffff;
                border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.05);">

    <!-- HEADER -->
    <tr>
      <td style="padding:24px 24px 8px 24px; text-align:center;">
        <h2 style="margin:0 0 8px 0; font-size:22px; color:#111;">
          Login Akun UMKM via QR Code
        </h2>
        <p style="margin:0; color:#555;">
          Halo, {{ $user->nama_user ?? $user->email }}
        </p>
      </td>
    </tr>

    <!-- CONTENT -->
    <tr>
      <td style="padding:12px 24px 0 24px;">
        <p style="color:#333; line-height:1.6; font-size:14px;">
          Berikut adalah <strong>QR Code untuk login ke sistem UMKM</strong>.
          Silakan scan QR Code ini menggunakan kamera ponsel atau fitur
          <em>Scan QR</em> pada aplikasi.
        </p>

        <p style="color:#333; line-height:1.6; font-size:13px; margin-top:8px;">
          Jika Anda menggunakan <strong>satu perangkat</strong> (misalnya hanya laptop),
          silakan <strong>unduh gambar QR Code yang terlampir</strong>, lalu pada halaman
          <em>Login via QR</em> pilih menu
          <strong>“Upload Gambar QR Code”</strong> dan unggah file tersebut.
        </p>
      </td>
    </tr>

    <!-- QR IMAGE -->
    <tr>
      <td style="padding:10px 24px 12px 24px; text-align:center;">
        <img
          src="{{ $message->embed($qrPath) }}"
          alt="QR Login UMKM"
          style="max-width:240px;border:1px solid #eee;
                 padding:10px;border-radius:8px;"
        >
      </td>
    </tr>

    <!-- INFO -->
    <tr>
      <td style="padding:0 24px 16px 24px;">
        <p style="color:#555; font-size:13px; margin:0;">
          QR Code ini berlaku hingga:
          <strong>{{ $expired ?? '-' }}</strong><br>
          Demi keamanan, jangan bagikan QR Code ini kepada siapa pun.
        </p>
      </td>
    </tr>

    <!-- FOOTER -->
    <tr>
      <td style="padding:8px 24px 24px 24px; color:#888; font-size:12px;">
        <hr style="border:none;border-top:1px solid #f0f0f0;margin:12px 0;">
        <p style="margin:0;">UMKM App</p>
        <p style="margin:0;">
          Email ini dikirim secara otomatis. Mohon untuk tidak membalas email ini.
        </p>
      </td>
    </tr>

  </table>
</body>
</html>
