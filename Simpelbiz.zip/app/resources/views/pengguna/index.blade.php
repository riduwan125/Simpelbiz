@extends('layouts.dashboard') {{-- ganti dengan layoutmu --}}

@section('content')
<div class="p-6">
    <h1 class="text-2xl font-bold mb-4">Profil</h1>

    <div class="bg-white rounded-xl shadow p-4 mb-6">
        <h2 class="font-semibold mb-3">Data Akun</h2>
        <p><strong>Nama:</strong> {{ $user->nama_user }}</p>
        <p><strong>Email:</strong> {{ $user->email }}</p>
    </div>

    <div class="bg-white rounded-xl shadow p-4">
        <h2 class="font-semibold mb-3">Data UMKM</h2>

        @if($umkm)
            <p><strong>Nama UMKM:</strong> {{ $umkm->nama_umkm }}</p>
            <p><strong>Jenis Usaha:</strong> {{ $umkm->jenis_usaha }}</p>
            <p><strong>Alamat:</strong> {{ $umkm->alamat_umkm }}</p>
            <p><strong>No. Telepon:</strong> {{ $umkm->no_telepon }}</p>
        @else
            <p class="text-gray-500">Belum ada data UMKM untuk akun ini.</p>
        @endif
    </div>
</div>
@endsection
