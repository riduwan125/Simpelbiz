@extends('layouts.app')
@section('title', 'Edit Pengguna')

@section('content')
<div class="d-flex min-vh-100">

    {{-- Sidebar --}}
    <div class="bg-dark text-white p-3 d-flex flex-column" style="width:230px;">
        <h5 class="text-center mb-4">Pencatatan<br>Keuangan</h5>

        <a href="{{ route('dashboard') }}" class="d-block text-white py-2 px-3">📊 Dashboard</a>
        <a href="{{ route('pengguna.index') }}" class="d-block text-white py-2 px-3 bg-secondary rounded">👥 Pengguna</a>
        <a href="{{ route('catatan.index') }}" class="d-block text-white py-2 px-3">🧾 Catatan Keuangan</a>
        <a href="{{ route('laporan.index') }}" class="d-block text-white py-2 px-3">📑 Laporan Keuangan</a>

        <form method="POST" action="{{ route('logout') }}" class="mt-auto pt-4">
            @csrf
            <button type="submit" class="btn btn-link text-danger text-decoration-none ps-3">🚪 Keluar</button>
        </form>
    </div>

    {{-- Main Content --}}
    <div class="flex-grow-1 bg-light">

        {{-- Header --}}
        <div class="d-flex justify-content-between align-items-center bg-secondary-subtle py-3 px-4 border-bottom">
            <h4 class="m-0">Edit Pengguna</h4>
            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center"
                 style="width:40px; height:40px;">👤</div>
        </div>

        {{-- Form --}}
        <div class="container my-5">
            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <h6 class="fw-semibold mb-3 text-muted">Form Edit Admin</h6>

                    <form action="{{ route('pengguna.update', $user->id_user) }}" method="POST">
                        @csrf
                        @method('PATCH')

                        {{-- Nama --}}
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama</label>
                            <input type="text" name="nama_user"
                                   value="{{ old('nama_user', $user->nama_user) }}"
                                   class="form-control" required>
                        </div>

                        {{-- Email --}}
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email"
                                   value="{{ old('email', $user->email) }}"
                                   class="form-control" required>
                        </div>

                        {{-- Nama UMKM --}}
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama UMKM</label>
                            <input type="text" name="nama_umkm"
                                   value="{{ old('nama_umkm', $user->umkm->nama_umkm ?? '') }}"
                                   class="form-control" required>
                        </div>

                        {{-- Password --}}
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Password</label>
                            <input type="password" name="password" class="form-control"
                                   placeholder="Password baru (kosongkan jika tidak diubah)">
                        </div>

                        <button type="submit" class="btn btn-primary px-4">Simpan</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection
