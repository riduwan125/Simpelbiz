@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="card shadow-sm p-4">
        <h4 class="mb-4">Pengguna</h4>
        <table class="table table-borderless">
            <tr><th>Nama</th><td>{{ $user->nama_user }}</td></tr>
            <tr><th>Email</th><td>{{ $user->email }}</td></tr>
            <tr><th>Nama UMKM</th><td>{{ $user->nama_umkm }}</td></tr>
            <tr><th>Password</th><td>Rp {{ $user->password }}</td></tr>
        </table>

        <div class="mt-4 text-end">
            <a href="{{ route('catatan.index') }}" class="btn btn-secondary">Kembali</a>
        </div>
    </div>
</div>
@endsection
