@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h4 class="mb-4">Edit Catatan Keuangan</h4>

    <form action="{{ route('catatan.update', $catatan->id_catatan) }}" method="POST" class="card p-4 shadow-sm">
        @csrf
        @method('PUT')

        {{-- Jenis Catatan --}}
        <div class="mb-3">
            <label class="form-label">Jenis Catatan</label>
            <select name="jenis_catatan" class="form-select" required>
                <option value="">-- Pilih Jenis --</option>
                <option value="Pemasukan" {{ $catatan->jenis_catatan === 'Pemasukan' ? 'selected' : '' }}>Pemasukan</option>
                <option value="Pengeluaran" {{ $catatan->jenis_catatan === 'Pengeluaran' ? 'selected' : '' }}>Pengeluaran</option>
            </select>
        </div>

        {{-- Deskripsi --}}
        <div class="mb-3">
            <label class="form-label">Deskripsi Barang/Jasa</label>
            <textarea name="deskripsi" class="form-control" placeholder="Masukkan deskripsi transaksi">{{ $catatan->deskripsi }}</textarea>
        </div>

        {{-- Jumlah, Satuan, Harga --}}
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">Jumlah</label>
                <input
                    type="number"
                    name="jumlah"
                    id="jumlah"
                    class="form-control"
                    value="{{ $catatan->jumlah }}"
                    min="0"
                    step="1"
                    required>
            </div>

            <div class="col-md-4 mb-3">
    <label class="form-label">Satuan</label>
    <input
        type="text"
        name="satuan"
        id="satuan"
        class="form-control"
        value="{{ old('satuan', $catatan->satuan) }}"
        list="daftar_satuan"
        placeholder="Misal: pcs, kg, liter"
        required>

    {{-- Suggestion satuan dari tabel satuan_umkm --}}
    <datalist id="daftar_satuan">
        @foreach($satuan as $s)
            <option value="{{ $s->nama_satuan }}"></option>
        @endforeach
    </datalist>
</div>


            <div class="col-md-4 mb-3">
                <label class="form-label">Harga Satuan</label>
                @php
                    $hargaSatuan = $catatan->jumlah > 0 ? ($catatan->nominal / $catatan->jumlah) : 0;
                @endphp
                <input
                    type="text"
                    name="harga_satuan"
                    id="harga_satuan"
                    value="Rp {{ number_format($hargaSatuan, 0, ',', '.') }}"
                    class="form-control"
                    required>
            </div>
        </div>

        {{-- Tanggal --}}
        <div class="mb-3">
            <label class="form-label">Tanggal Transaksi</label>
            <input
                type="date"
                name="tanggal_transaksi"
                class="form-control"
                value="{{ $catatan->tanggal_transaksi }}"
                required>
        </div>

        {{-- Total --}}
        <div class="mb-3">
            <label class="form-label">Total Nominal</label>
            <input
                type="text"
                id="total_nominal"
                class="form-control bg-light"
                value="Rp {{ number_format($catatan->nominal, 0, ',', '.') }}"
                readonly>
        </div>

        {{-- Tombol --}}
        <div class="text-end">
            <a href="{{ route('catatan.index') }}" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn btn-primary px-4">Update</button>
        </div>
    </form>
</div>

{{-- Script Hitung Total --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    const jumlah = document.getElementById('jumlah');
    const satuan = document.getElementById('satuan');
    const harga = document.getElementById('harga_satuan');
    const total = document.getElementById('total_nominal');

    // Ubah placeholder & step sesuai satuan
    satuan.addEventListener('change', function () {
        const val = this.value.toLowerCase();
        if (['kg', 'gram', 'liter'].includes(val)) {
            jumlah.setAttribute('step', '0.01');
            jumlah.setAttribute('placeholder', `Masukkan jumlah dalam ${val}`);
        } else {
            jumlah.setAttribute('step', '1');
            jumlah.setAttribute('placeholder', `Masukkan jumlah (${val})`);
        }
    });

    // Hitung total otomatis
    function hitungTotal() {
        const jml = parseFloat(jumlah.value) || 0;
        const hrg = parseFloat(harga.value.replace(/\D/g, '')) || 0;
        const hasil = jml * hrg;
        total.value = "Rp " + new Intl.NumberFormat('id-ID').format(hasil);
    }

    jumlah.addEventListener('input', hitungTotal);
    harga.addEventListener('input', hitungTotal);
});
</script>
@endsection
