@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h4 class="mb-4">Tambah Catatan Keuangan</h4>

    <form action="{{ route('catatan.store') }}" method="POST" class="card p-4 shadow-sm">
        @csrf

        {{-- Jenis Catatan --}}
        <div class="mb-3">
            <label class="form-label">Jenis Catatan</label>
            <select name="jenis_catatan" class="form-select" required>
                <option value="">-- Pilih Jenis --</option>
                <option value="Pemasukan">Pemasukan</option>
                <option value="Pengeluaran">Pengeluaran</option>
            </select>
        </div>

        {{-- Deskripsi --}}
        <div class="mb-3">
            <label class="form-label">Deskripsi Barang/Jasa</label>
            <textarea name="deskripsi" class="form-control" placeholder="Masukkan deskripsi transaksi"></textarea>
        </div>

        {{-- Jumlah, Satuan, Harga --}}
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">Jumlah</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control" placeholder="Masukkan jumlah" min="0" step="1" required>
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">Satuan</label>
                <div class="d-flex gap-2">
                    <select name="satuan" id="satuan" class="form-select flex-grow-1" required>
                        <option value="">-- Pilih Satuan --</option>
                        @foreach($satuan as $s)
                            <option value="{{ $s->nama_satuan }}">{{ ucfirst($s->nama_satuan) }}</option>
                        @endforeach
                    </select>

                    {{-- Tombol tambah satuan --}}
                    <button type="button"
                            class="btn btn-success"
                            data-bs-toggle="modal"
                            data-bs-target="#modalSatuan">+
                    </button>

                    {{-- Tombol kelola satuan (hapus, dll) --}}
                    <button type="button"
                            class="btn btn-outline-secondary"
                            title="Kelola satuan"
                            data-bs-toggle="modal"
                            data-bs-target="#modalKelolaSatuan">
                        <i class="bi bi-gear"></i>
                    </button>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label">Harga Satuan</label>
                <input type="text" name="harga_satuan" id="harga_satuan" class="form-control" placeholder="contoh: 10000" required>
            </div>
        </div>

        {{-- Tanggal --}}
        <div class="mb-3">
            <label class="form-label">Tanggal Transaksi</label>
            <input type="date" name="tanggal_transaksi" class="form-control" required>
        </div>

        {{-- Total --}}
        <div class="mb-3">
            <label class="form-label">Total Nominal</label>
            <input type="text" id="total_nominal" class="form-control bg-light" readonly>
        </div>

        {{-- Tombol Simpan --}}
        <div class="text-end">
            <a href="{{ route('catatan.index') }}" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn btn-success px-4">Simpan</button>
        </div>
    </form>
</div>

<!-- Modal Tambah Satuan -->
<div class="modal fade" id="modalSatuan" tabindex="-1" aria-labelledby="modalSatuanLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="formSatuan" method="POST" action="{{ route('satuan.store') }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="modalSatuanLabel">Tambah Satuan Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nama_satuan" class="form-label">Nama Satuan</label>
                        <input type="text" name="nama_satuan" id="nama_satuan" class="form-control" placeholder="contoh: Bungkus, Liter, Porsi" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Kelola Satuan (Hapus dari daftar) -->
<div class="modal fade" id="modalKelolaSatuan" tabindex="-1" aria-labelledby="modalKelolaSatuanLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalKelolaSatuanLabel">Kelola Satuan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                @if($satuan->count())
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 50px;">No</th>
                                    <th>Nama Satuan</th>
                                    <th class="text-end" style="width: 120px;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($satuan as $s)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $s->nama_satuan }}</td>
                                        <td class="text-end">
                                            <button type="button"
                                                    class="btn btn-sm btn-outline-danger"
                                                    onclick="hapusSatuan({{ $s->id_satuan }})">
                                                <i class="bi bi-trash"></i> Hapus
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <p class="text-muted mb-0">Belum ada satuan yang terdaftar.</p>
                @endif
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

{{-- Script Dinamis --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    const jumlah = document.getElementById('jumlah');
    const satuan = document.getElementById('satuan');
    const harga  = document.getElementById('harga_satuan');
    const total  = document.getElementById('total_nominal');

    // Ubah placeholder & step sesuai satuan
    if (satuan) {
        satuan.addEventListener('change', function () {
            const val = this.value.toLowerCase();
            if (['kg', 'gram', 'liter'].includes(val)) {
                jumlah.setAttribute('step', '0.01');
                jumlah.setAttribute('placeholder', `Masukkan jumlah dalam ${val}`);
            } else {
                jumlah.setAttribute('step', '1');
                jumlah.setAttribute('placeholder', `Masukkan jumlah (${val})`);
            }
        });
    }

    // Hitung total otomatis
    function hitungTotal() {
        const jml = parseFloat(jumlah.value) || 0;
        const hrg = parseFloat(harga.value.replace(/\D/g, '')) || 0;
        total.value = "Rp " + new Intl.NumberFormat('id-ID').format(jml * hrg);
    }
    jumlah.addEventListener('input', hitungTotal);
    harga.addEventListener('input', hitungTotal);

    // Tambah satuan via AJAX
    document.getElementById('formSatuan').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch("{{ route('satuan.store') }}", {
            method: "POST",
            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.nama_satuan) {
                // Tambahkan ke dropdown
                const select = document.getElementById('satuan');
                const opt    = document.createElement('option');
                opt.value    = data.nama_satuan;
                opt.textContent = data.nama_satuan;
                select.appendChild(opt);
                select.value = data.nama_satuan;

                // Kosongkan input modal & tutup modal
                document.getElementById('nama_satuan').value = '';
                bootstrap.Modal.getInstance(document.getElementById('modalSatuan')).hide();

                // Optional: reload halaman kelola satuan biar list-nya ke-update
                // location.reload();
            } else if (data.error) {
                alert(data.error);
            } else {
                alert('Gagal menambah satuan.');
            }
        })
        .catch(() => alert('Terjadi kesalahan server.'));
    });
});

// Hapus satuan
function hapusSatuan(id) {
    if (!confirm('Yakin ingin menghapus satuan ini?')) return;

    fetch(`/satuan/${id}`, {
        method: 'DELETE',
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
    })
    .then(res => res.json())
    .then(data => {
        alert(data.success || data.error || 'Terjadi kesalahan.');
        // reload supaya dropdown & list satuan ke-refresh
        location.reload();
    })
    .catch(() => alert('Terjadi kesalahan server.'));
}
</script>
@endsection
