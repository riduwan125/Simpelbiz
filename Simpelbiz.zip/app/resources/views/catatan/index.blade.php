@extends('layouts.admin')

@section('title', 'Transaksi Harian')

@section('content')

<div class="container py-3 py-md-4">

    {{-- Header + tombol tambah --}}
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 mb-md-4 gap-3">
        <div class="flex-grow-1">
            <h3 class="fw-bold mb-1 fs-4 fs-md-3">Transaksi Harian</h3>
            <p class="text-secondary mb-0 small">
                Kelola transaksi harian dengan mudah
            </p>
        </div>
        <a href="{{ route('catatan.create') }}" 
           class="btn btn-primary d-flex align-items-center gap-2 shadow-sm">
            <i class="bi bi-plus-lg"></i>
            <span>Tambah Data</span>
        </a>
    </div>

    {{-- Card daftar catatan --}}
    <div class="card border-0 shadow-sm mb-3 mb-md-4">
        <div class="card-body p-2 p-md-4">

            {{-- Desktop Table View --}}
            <div class="d-none d-lg-block">
                <div class="table-responsive">
                    <table class="table table-striped align-middle text-center mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Jenis</th>
                                <th>Deskripsi</th>
                                <th>Jumlah</th>
                                <th>Satuan</th>
                                <th>Nominal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($catatan as $index => $row)
                                <tr>
                                    <td>{{ $index + 1 }}</td>

                                    <td>
                                        <div class="fw-medium">
                                            {{ \Carbon\Carbon::parse($row->tanggal_transaksi)->format('d/m/Y') }}
                                        </div>
                                        <small class="text-secondary">
                                            {{ \Carbon\Carbon::parse($row->tanggal_transaksi)->diffForHumans() }}
                                        </small>
                                    </td>

                                    <td>
                                        @if(strtolower($row->jenis_catatan) == 'pemasukan')
                                            <span class="badge rounded-pill text-bg-success">
                                                <i class="bi bi-arrow-down-circle me-1"></i>Pemasukan
                                            </span>
                                        @else
                                            <span class="badge rounded-pill text-bg-danger">
                                                <i class="bi bi-arrow-up-circle me-1"></i>Pengeluaran
                                            </span>
                                        @endif
                                    </td>

                                    <td class="text-start">
                                        {{ $row->deskripsi }}
                                    </td>

                                    <td>
                                        {{ number_format($row->jumlah, 0, ',', '.') }}
                                    </td>

                                    <td>
                                        {{ $row->satuan }}
                                    </td>

                                    <td class="text-end">
                                        Rp {{ number_format($row->nominal, 0, ',', '.') }}
                                    </td>

                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="{{ route('catatan.show', $row->id_catatan) }}" 
                                               class="btn btn-warning btn-sm"
                                               title="Lihat">
                                                <i class="bi bi-eye"></i>
                                            </a>

                                            <a href="{{ route('catatan.edit', $row->id_catatan) }}" 
                                               class="btn btn-primary btn-sm"
                                               title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>

                                            <form action="{{ route('catatan.destroy', $row->id_catatan) }}" 
                                                  method="POST"
                                                  class="d-inline delete-catatan-form">
                                                @csrf
                                                @method('DELETE')
                                                <button type="button"
                                                        class="btn btn-danger btn-sm btn-delete-catatan"
                                                        title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="8" class="text-muted py-4">
                                        Belum ada catatan keuangan
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            {{-- Mobile & Tablet Card View --}}
            <div class="d-lg-none">
                @forelse ($catatan as $index => $row)
                <div class="card mb-3 border transaction-card" data-type="{{ strtolower($row->jenis_catatan) }}">
                    <div class="card-body p-3">
                        {{-- Header Card --}}
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-secondary">{{ $index + 1 }}</span>
                                @if(strtolower($row->jenis_catatan) == 'pemasukan')
                                    <span class="badge bg-success">
                                        <i class="bi bi-arrow-down-circle"></i> Pemasukan
                                    </span>
                                @else
                                    <span class="badge bg-danger">
                                        <i class="bi bi-arrow-up-circle"></i> Pengeluaran
                                    </span>
                                @endif
                            </div>
                            <div class="text-end">
                                <small class="text-muted d-block">
                                    {{ \Carbon\Carbon::parse($row->tanggal_transaksi)->format('d/m/Y') }}
                                </small>
                                <small class="text-muted" style="font-size: 0.75rem;">
                                    {{ \Carbon\Carbon::parse($row->tanggal_transaksi)->diffForHumans() }}
                                </small>
                            </div>
                        </div>

                        {{-- Deskripsi --}}
                        <h6 class="mb-2 fw-bold">{{ $row->deskripsi }}</h6>

                        {{-- Detail Info --}}
                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <div class="p-2 bg-light rounded">
                                    <small class="text-muted d-block" style="font-size: 0.75rem;">Jumlah</small>
                                    <div class="fw-semibold">
                                        {{ number_format($row->jumlah, 0, ',', '.') }} {{ $row->satuan }}
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="p-2 bg-light rounded">
                                    <small class="text-muted d-block" style="font-size: 0.75rem;">Nominal</small>
                                    <div class="fw-bold" style="color: {{ strtolower($row->jenis_catatan) == 'pemasukan' ? '#198754' : '#dc3545' }}">
                                        Rp {{ number_format($row->nominal, 0, ',', '.') }}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Action Buttons --}}
                        <div class="d-flex gap-2">
                            <a href="{{ route('catatan.show', $row->id_catatan) }}" 
                               class="btn btn-warning btn-sm flex-fill">
                                <i class="bi bi-eye"></i> Lihat
                            </a>

                            <a href="{{ route('catatan.edit', $row->id_catatan) }}" 
                               class="btn btn-primary btn-sm flex-fill">
                                <i class="bi bi-pencil"></i> Edit
                            </a>

                            <form action="{{ route('catatan.destroy', $row->id_catatan) }}" 
                                  method="POST"
                                  class="delete-catatan-form flex-fill">
                                @csrf
                                @method('DELETE')
                                <button type="button"
                                        class="btn btn-danger btn-sm w-100 btn-delete-catatan"
                                        title="Hapus">
                                    <i class="bi bi-trash"></i> Hapus
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                @empty
                <div class="text-center text-muted py-5">
                    <div class="mb-3">
                        <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.5;"></i>
                    </div>
                    <h5 class="mb-2">Belum ada catatan keuangan</h5>
                    <p class="mb-3 small">Mulai catat transaksi harian Anda sekarang</p>
                    <a href="{{ route('catatan.create') }}" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg"></i> Tambah Catatan Pertama
                    </a>
                </div>
                @endforelse
            </div>

        </div>
    </div>

    {{-- Summary Cards (Mobile Only) --}}
    @if($catatan->count() > 0)
    <div class="row g-2 d-lg-none mb-3">
        @php
            $totalPemasukan = $catatan->where('jenis_catatan', 'pemasukan')->sum('nominal');
            $totalPengeluaran = $catatan->where('jenis_catatan', 'pengeluaran')->sum('nominal');
            $saldo = $totalPemasukan - $totalPengeluaran;
        @endphp

        <div class="col-4">
            <div class="card border-0 bg-success bg-opacity-10">
                <div class="card-body p-2 text-center">
                    <small class="text-success d-block mb-1" style="font-size: 0.7rem;">
                        <i class="bi bi-arrow-down-circle"></i> Pemasukan
                    </small>
                    <div class="fw-bold text-success" style="font-size: 0.85rem;">
                        Rp {{ number_format($totalPemasukan, 0, ',', '.') }}
                    </div>
                </div>
            </div>
        </div>

        <div class="col-4">
            <div class="card border-0 bg-danger bg-opacity-10">
                <div class="card-body p-2 text-center">
                    <small class="text-danger d-block mb-1" style="font-size: 0.7rem;">
                        <i class="bi bi-arrow-up-circle"></i> Pengeluaran
                    </small>
                    <div class="fw-bold text-danger" style="font-size: 0.85rem;">
                        Rp {{ number_format($totalPengeluaran, 0, ',', '.') }}
                    </div>
                </div>
            </div>
        </div>

        <div class="col-4">
            <div class="card border-0 bg-primary bg-opacity-10">
                <div class="card-body p-2 text-center">
                    <small class="text-primary d-block mb-1" style="font-size: 0.7rem;">
                        <i class="bi bi-wallet2"></i> Saldo
                    </small>
                    <div class="fw-bold text-primary" style="font-size: 0.85rem;">
                        Rp {{ number_format($saldo, 0, ',', '.') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

</div>

{{-- Custom CSS --}}
<style>
/* Mobile optimizations */
@media (max-width: 991.98px) {
    .transaction-card {
        transition: all 0.2s ease;
    }

    .transaction-card:active {
        transform: scale(0.98);
        box-shadow: 0 0.125rem 0.5rem rgba(0, 0, 0, 0.15);
    }

    /* Colored border for transaction type */
    .transaction-card[data-type="pemasukan"] {
        border-left: 4px solid #198754;
    }

    .transaction-card[data-type="pengeluaran"] {
        border-left: 4px solid #dc3545;
    }

    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
    }
}

/* Touch-friendly buttons */
.btn, .form-select, .form-control {
    min-height: 44px;
}

@media (max-width: 991.98px) {
    .btn-sm {
        min-height: 38px;
    }
}

/* Smooth animations */
.card {
    transition: box-shadow 0.2s ease;
}

.card:hover {
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

/* Better badge sizing on mobile */
@media (max-width: 991.98px) {
    .badge {
        font-size: 0.7rem;
        padding: 0.35em 0.65em;
    }
}

/* Empty state animation */
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.bi-inbox {
    animation: float 3s ease-in-out infinite;
}
</style>

{{-- Script SweetAlert konfirmasi hapus --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    const deleteForms = document.querySelectorAll('.delete-catatan-form');

    deleteForms.forEach(function(form) {
        const button = form.querySelector('.btn-delete-catatan');
        if (!button) return;

        button.addEventListener('click', function (e) {
            e.preventDefault();

            // Check if Swal is available
            if (typeof Swal === 'undefined') {
                if (confirm('Hapus catatan? Catatan yang dihapus tidak dapat dikembalikan.')) {
                    form.submit();
                }
                return;
            }

            Swal.fire({
                title: 'Hapus catatan?',
                text: 'Catatan yang dihapus tidak dapat dikembalikan.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3342f',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus',
                cancelButtonText: 'Batal',
                customClass: {
                    container: window.innerWidth < 992 ? 'swal2-mobile' : ''
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });

    // Prevent double tap zoom on buttons (iOS)
    document.querySelectorAll('button, a.btn').forEach(element => {
        let lastTap = 0;
        element.addEventListener('touchend', function(e) {
            const currentTime = new Date().getTime();
            const tapLength = currentTime - lastTap;
            
            if (tapLength < 500 && tapLength > 0) {
                e.preventDefault();
            }
            
            lastTap = currentTime;
        }, { passive: false });
    });
});
</script>

<style>
/* SweetAlert mobile optimization */
.swal2-mobile {
    padding: 1rem !important;
}

.swal2-mobile .swal2-popup {
    width: calc(100% - 2rem) !important;
    font-size: 0.9rem !important;
}

.swal2-mobile .swal2-title {
    font-size: 1.2rem !important;
}

.swal2-mobile .swal2-html-container {
    font-size: 0.85rem !important;
}
</style>

@endsection