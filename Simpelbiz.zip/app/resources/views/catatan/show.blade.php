@extends('layouts.app')

@section('title', 'Detail Catatan Keuangan')

@section('content')
<div class="container py-4">

    {{-- Header --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1">Detail Catatan Keuangan</h3>
            <p class="text-secondary mb-0" style="font-size: 0.95rem;">
                Informasi lengkap transaksi yang dipilih
            </p>
        </div>

        <a href="{{ route('catatan.index') }}" class="btn btn-outline-secondary d-flex align-items-center gap-2">
            <i class="bi bi-arrow-left"></i>
            <span>Kembali</span>
        </a>
    </div>

    {{-- Card Detail --}}
    <div class="card border-0 shadow-sm">
        <div class="card-body">

            {{-- Jenis + Nominal di atas --}}
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    @php
                        $jenisLower = strtolower($catatan->jenis_catatan);
                    @endphp

                    @if($jenisLower === 'pemasukan')
                        <span class="badge rounded-pill text-bg-success px-3 py-2">
                            <i class="bi bi-arrow-down-circle me-1"></i>Pemasukan
                        </span>
                    @else
                        <span class="badge rounded-pill text-bg-danger px-3 py-2">
                            <i class="bi bi-arrow-up-circle me-1"></i>Pengeluaran
                        </span>
                    @endif
                </div>

                <div class="text-end">
                    <div class="text-secondary small">Total Nominal</div>
                    <div class="fs-5 fw-semibold text-dark">
                        Rp {{ number_format($catatan->nominal, 0, ',', '.') }}
                    </div>
                </div>
            </div>

            <hr>

            {{-- Tabel detail --}}
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-borderless mb-0">
                        <tbody>
                            <tr>
                                <th class="text-secondary" style="width: 40%;">Jenis Catatan</th>
                                <td class="fw-medium">{{ $catatan->jenis_catatan }}</td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Tanggal Transaksi</th>
                                <td>
                                    {{ \Carbon\Carbon::parse($catatan->tanggal_transaksi)->format('d-m-Y') }}
                                    <span class="text-muted small d-block">
                                        {{ \Carbon\Carbon::parse($catatan->tanggal_transaksi)->diffForHumans() }}
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Jumlah</th>
                                <td>
                                    {{ number_format($catatan->jumlah, 0, ',', '.') }}
                                    @if(!empty($catatan->satuan))
                                        <span class="text-muted"> {{ $catatan->satuan }}</span>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Harga Satuan (perkiraan)</th>
                                <td>
                                    @php
                                        $hargaSatuan = $catatan->jumlah > 0
                                            ? ($catatan->nominal / $catatan->jumlah)
                                            : 0;
                                    @endphp
                                    Rp {{ number_format($hargaSatuan, 0, ',', '.') }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="col-md-6">
                    <table class="table table-borderless mb-0">
                        <tbody>
                            <tr>
                                <th class="text-secondary" style="width: 40%;">Deskripsi</th>
                                <td>
                                    @if($catatan->deskripsi)
                                        {{ $catatan->deskripsi }}
                                    @else
                                        <span class="text-muted fst-italic">Tidak ada deskripsi.</span>
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Dibuat pada</th>
                                <td>
                                    {{ \Carbon\Carbon::parse($catatan->created_at)->format('d-m-Y H:i') }}
                                </td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Terakhir diubah</th>
                                <td>
                                    {{ \Carbon\Carbon::parse($catatan->updated_at)->format('d-m-Y H:i') }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            {{-- Tombol aksi bawah (opsional edit) --}}
            <div class="mt-4 d-flex justify-content-between">
                <div>
                    <a href="{{ route('catatan.index') }}" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-1"></i> Kembali ke daftar
                    </a>
                </div>
                <div>
                    <a href="{{ route('catatan.edit', $catatan->id_catatan) }}"
                       class="btn btn-primary">
                        <i class="bi bi-pencil me-1"></i> Edit Catatan
                    </a>
                </div>
            </div>

        </div>
    </div>

</div>
@endsection
