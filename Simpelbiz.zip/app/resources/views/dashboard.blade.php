@extends('layouts.admin')
@section('page-title', 'Dashboard')

@section('content')
<div class="container-fluid py-4">
    
    {{-- Header Section --}}
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <h2 class="fw-bold mb-1 dashboard-title">Dashboard Keuangan</h2>
                    <p class="text-muted mb-0 small">
                        Ringkasan aktivitas dan statistik keuangan Anda
                    </p>
                </div>
                <div class="text-start text-md-end">
                    <small class="text-muted d-block">Periode</small>
                    <strong>{{ now()->format('F Y') }}</strong>
                </div>
            </div>
        </div>
    </div>

    {{-- Summary Cards --}}
    <div class="row g-3 g-md-4 mb-4 row-cols-1 row-cols-md-2 row-cols-xl-4">
        
        {{-- Monthly Total --}}
        <div class="col">
            <div class="card border-0 shadow-sm h-100 overflow-hidden position-relative">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-2 text-uppercase small fw-semibold">Bulan Ini</p>
                            <h2 class="fw-bold mb-0 summary-number">{{ $monthlyTransactions }}</h2>
                            <small class="text-success">
                                <i class="bi bi-arrow-up"></i> Transaksi
                            </small>
                        </div>
                        <div class="bg-success bg-opacity-10 rounded-circle p-3 d-none d-sm-inline-flex">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="text-success" viewBox="0 0 16 16">
                                <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-success" style="width: {{ min(100, $monthlyTransactions * 3) }}%"></div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Yearly Total --}}
        <div class="col">
            <div class="card border-0 shadow-sm h-100 overflow-hidden position-relative">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-2 text-uppercase small fw-semibold">Tahun Ini</p>
                            <h2 class="fw-bold mb-0 summary-number">{{ $yearlyTransactions }}</h2>
                            <small class="text-primary">
                                <i class="bi bi-arrow-up"></i> Transaksi
                            </small>
                        </div>
                        <div class="bg-primary bg-opacity-10 rounded-circle p-3 d-none d-sm-inline-flex">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="text-primary" viewBox="0 0 16 16">
                                <path d="M4 .5a.5.5 0 0 0-1 0V1H2a2 2 0 0 0-2 2v1h16V3a2 2 0 0 0-2-2h-1V.5a.5.5 0 0 0-1 0V1H4V.5zM16 14V5H0v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2zm-6.664-1.21c-1.11 0-1.656-.767-1.703-1.407h.683c.043.37.387.82 1.051.82.844 0 1.301-.848 1.305-2.164h-.027c-.153.414-.637.79-1.383.79-.852 0-1.676-.61-1.676-1.77 0-1.137.871-1.809 1.797-1.809 1.172 0 1.953.734 1.953 2.668 0 1.805-.742 2.871-2 2.871zm-2.89-5.435v5.332H5.77V8.079h-.012c-.29.156-.883.52-1.258.777V8.16a12.6 12.6 0 0 1 1.313-.805h.632z"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-primary" style="width: {{ min(100, $yearlyTransactions * 1.5) }}%"></div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Average Daily --}}
        <div class="col">
            <div class="card border-0 shadow-sm h-100 overflow-hidden position-relative">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-2 text-uppercase small fw-semibold">Rata-rata Harian</p>
                            <h2 class="fw-bold mb-0 summary-number">{{ $averageDailyTransactions }}</h2>
                            <small class="text-info">
                                <i class="bi bi-graph-up"></i> Transaksi/hari
                            </small>
                        </div>
                        <div class="bg-info bg-opacity-10 rounded-circle p-3 d-none d-sm-inline-flex">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="text-info" viewBox="0 0 16 16">
                                <path d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-info" style="width: {{ min(100, $averageDailyTransactions * 10) }}%"></div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Growth Rate --}}
        <div class="col">
            <div class="card border-0 shadow-sm h-100 overflow-hidden position-relative">
                <div class="card-body">
                    @php
                        $growthLabel = ($growthRate >= 0 ? '+' : '') . number_format($growthRate, 1) . '%';
                    @endphp
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-muted mb-2 text-uppercase small fw-semibold">Pertumbuhan</p>
                            <h2 class="fw-bold mb-0 summary-number">{{ $growthLabel }}</h2>
                            <small class="text-warning">
                                <i class="bi bi-arrow-up-right"></i> vs bulan lalu
                            </small>
                        </div>
                        <div class="bg-warning bg-opacity-10 rounded-circle p-3 d-none d-sm-inline-flex">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="text-warning" viewBox="0 0 16 16">
                                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4zm.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <div class="progress" style="height: 4px;">
                        <div class="progress-bar bg-warning" style="width: {{ max(5, min(100, abs($growthRate))) }}%"></div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    {{-- Charts Section --}}
    <div class="row g-4">
        
        {{-- Expenses Chart --}}
        <div class="col-xl-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div>
                            <h5 class="mb-0 fw-semibold">
                                <i class="bi bi-pie-chart text-danger me-2"></i>
                                Distribusi Pengeluaran
                            </h5>
                            <small class="text-muted d-block">Berdasarkan deskripsi transaksi bulan ini</small>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="chartPengeluaran"></canvas>
                    </div>
                    <div class="mt-4 pt-3 border-top">
                        <div class="row g-3 text-center">
                            @forelse($pengeluaranRingkasan as $row)
                                <div class="col-6 col-md-3">
                                    <div class="mb-1">
                                        <span class="badge legend-dot">●</span>
                                    </div>
                                    <small class="text-muted d-block">
                                        {{ Str::limit($row->label, 12) }}
                                    </small>
                                    <strong class="small">{{ number_format($row->total, 0, ',', '.') }}</strong>
                                </div>
                            @empty
                                <div class="col-12 text-muted small">
                                    Tidak ada data pengeluaran bulan ini.
                                </div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Income Chart --}}
        <div class="col-xl-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div>
                            <h5 class="mb-0 fw-semibold">
                                <i class="bi bi-bar-chart text-success me-2"></i>
                                Tren Pemasukan
                            </h5>
                            <small class="text-muted d-block">Per minggu bulan ini</small>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="chartPemasukan"></canvas>
                    </div>
                    <div class="mt-4 pt-3 border-top">
                        <div class="row g-3">
                            <div class="col-12 col-sm-6">
                                <div class="d-flex align-items-center">
                                    <div class="bg-success bg-opacity-10 rounded p-2 me-2">
                                        <i class="bi bi-arrow-up text-success"></i>
                                    </div>
                                    <div>
                                        <small class="text-muted d-block">Pemasukan Tertinggi</small>
                                        <strong class="small">
                                            {{ $pemasukanMaxLabel }} - {{ number_format($pemasukanMaxValue, 0, ',', '.') }}
                                        </strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="d-flex align-items-center">
                                    <div class="bg-info bg-opacity-10 rounded p-2 me-2">
                                        <i class="bi bi-graph-up text-info"></i>
                                    </div>
                                    <div>
                                        <small class="text-muted d-block">Rata-rata</small>
                                        <strong class="small">
                                            {{ number_format($pemasukanAveragePerWeek, 0, ',', '.') }} / minggu
                                        </strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const pengeluaranLabels = @json($chartPengeluaranLabels);
    const pengeluaranData   = @json($chartPengeluaranData);

    const pemasukanLabels   = @json($chartPemasukanLabels);
    const pemasukanData     = @json($chartPemasukanData);

    // Pie Chart for Expenses
    const ctxPengeluaran = document.getElementById('chartPengeluaran').getContext('2d');
    new Chart(ctxPengeluaran, {
        type: 'doughnut',
        data: {
            labels: pengeluaranLabels,
            datasets: [{
                data: pengeluaranData,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        boxWidth: 10,
                        boxHeight: 10,
                        font: { size: 11 }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 10,
                    titleFont: { size: 13 },
                    bodyFont: { size: 12 },
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0) || 1;
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value.toLocaleString('id-ID')} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });

    // Bar Chart for Income
    const ctxPemasukan = document.getElementById('chartPemasukan').getContext('2d');
    new Chart(ctxPemasukan, {
        type: 'bar',
        data: {
            labels: pemasukanLabels,
            datasets: [{
                label: 'Pemasukan',
                data: pemasukanData,
                backgroundColor: '#36A2EB',
                borderRadius: 6,
                maxBarThickness: 40
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0, 0, 0, 0.05)' },
                    ticks: { font: { size: 11 } }
                },
                x: {
                    grid: { display: false },
                    ticks: { font: { size: 11 } }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 10,
                    titleFont: { size: 13 },
                    bodyFont: { size: 12 },
                    callbacks: {
                        label: function(context) {
                            return `Pemasukan: ${context.parsed.y.toLocaleString('id-ID')}`;
                        }
                    }
                }
            }
        }
    });
});
</script>

<style>
    .card {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 0.5rem 1.5rem rgba(0, 0, 0, 0.1) !important;
    }

    .bg-opacity-10 {
        --bs-bg-opacity: 0.1;
    }

    .chart-container {
        position: relative;
        min-height: 260px;
        height: 260px;
    }

    .legend-dot {
        background-color: rgba(0, 0, 0, .06);
        border-radius: 999px;
        font-size: 0.8rem;
        padding: .25rem .5rem;
    }

    .summary-number {
        font-size: 1.6rem;
    }

    .dashboard-title {
        font-size: 1.6rem;
    }

    @media (max-width: 576px) {
        .container-fluid {
            padding-left: 0.75rem !important;
            padding-right: 0.75rem !important;
        }

        .chart-container {
            min-height: 220px;
            height: 220px;
        }

        .summary-number {
            font-size: 1.35rem;
        }

        .dashboard-title {
            font-size: 1.4rem;
        }

        .card-body {
            padding: 0.85rem 0.9rem;
        }

        .card-header,
        .card-footer {
            padding-left: 0.9rem;
            padding-right: 0.9rem;
        }
    }
</style>
@endsection
