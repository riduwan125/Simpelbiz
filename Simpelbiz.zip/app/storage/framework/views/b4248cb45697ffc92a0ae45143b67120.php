<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('page-title', config('app.name')); ?></title>

    <!-- FAVICON (bypass cache) -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>?v=2">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>?v=2">
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.ico')); ?>?v=2">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <style>
        body { background-color: #f5f7fb; }
        .app-wrapper { min-height: 100vh; }
        .sidebar { background: #4c46ff; color: #fff; width: 260px; }
        .sidebar a { color: #e0e7ff; text-decoration: none; }
        .sidebar .nav-link { border-radius: 999px; padding: .65rem 1rem; margin-bottom: .25rem; }
        .sidebar .nav-link.active, .sidebar .nav-link:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .sidebar-header { padding: .85rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,0.15); }
        .sidebar-body { padding: 1rem 1.25rem 1.5rem 1.25rem; }
        .main-content { flex: 1; padding: 1.5rem; }

        @media (max-width: 767.98px) {
            .app-wrapper { flex-direction: column; }
            .sidebar {
                position: fixed; inset: 0 auto 0 0;
                transform: translateX(-100%);
                transition: transform .25s ease;
                z-index: 1040;
            }
            .sidebar.show { transform: translateX(0); }
            .sidebar-backdrop {
                position: fixed; inset: 0;
                background: rgba(15,23,42,.45);
                z-index: 1035; display: none;
            }
            .sidebar-backdrop.show { display: block; }
            .main-content { padding: 1rem; }
            .topbar {
                position: sticky; top: 0; z-index: 1030;
                background: #ffffff; border-bottom: 1px solid #e5e7eb;
            }
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
<div id="sidebar-backdrop" class="sidebar-backdrop"></div>

<div class="app-wrapper d-flex">

    
    <aside id="sidebar" class="sidebar d-flex flex-column">
        <div class="sidebar-header d-flex justify-content-between align-items-center">
            <span class="fw-semibold">
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(auth()->user()->is_admin == 1 ? 'Admin Panel' : 'Dashboard'); ?>

                <?php else: ?>
                    Dashboard
                <?php endif; ?>
            </span>
            <button class="btn btn-sm btn-light d-md-none" type="button" onclick="toggleSidebar()">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <div class="sidebar-body">
            <nav class="nav flex-column">

                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->is_admin == 1): ?>
                        

                        <?php if(\Illuminate\Support\Facades\Route::has('admin.dashboard')): ?>
                            <a href="<?php echo e(route('admin.dashboard')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('admin.dashboard')): ?> active <?php endif; ?>">
                                <i class="bi bi-speedometer2 me-2"></i> Dashboard Admin
                            </a>
                        <?php endif; ?>

                        <?php if(\Illuminate\Support\Facades\Route::has('admin.umkm.index')): ?>
                            <a href="<?php echo e(route('admin.umkm.index')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('admin.umkm.*')): ?> active <?php endif; ?>">
                                <i class="bi bi-buildings me-2"></i> Kelola UMKM
                            </a>
                        <?php endif; ?>

                        <?php if(\Illuminate\Support\Facades\Route::has('admin.verifikasi.index')): ?>
                            <a href="<?php echo e(route('admin.verifikasi.index')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('admin.verifikasi.*')): ?> active <?php endif; ?>">
                                <i class="bi bi-patch-check me-2"></i> Verifikasi UMKM
                            </a>
                        <?php endif; ?>

                        <?php if(\Illuminate\Support\Facades\Route::has('admin.users.index')): ?>
                            <a href="<?php echo e(route('admin.users.index')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('admin.users.*')): ?> active <?php endif; ?>">
                                <i class="bi bi-people me-2"></i> Kelola User
                            </a>
                        <?php endif; ?>

                        <?php if(\Illuminate\Support\Facades\Route::has('admin.laporan.index')): ?>
                            <a href="<?php echo e(route('admin.laporan.index')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('admin.laporan.*')): ?> active <?php endif; ?>">
                                <i class="bi bi-bar-chart-line me-2"></i> Laporan Sistem
                            </a>
                        <?php endif; ?>

                    <?php else: ?>
                        
                        <?php if(\Illuminate\Support\Facades\Route::has('dashboard')): ?>
                            <a href="<?php echo e(route('dashboard')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
                                <i class="bi bi-speedometer2 me-2"></i> Dashboard
                            </a>
                        <?php endif; ?>

                        <?php if(\Illuminate\Support\Facades\Route::has('catatan.index')): ?>
                            <a href="<?php echo e(route('catatan.index')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('catatan.*')): ?> active <?php endif; ?>">
                                <i class="bi bi-journal-text me-2"></i> Transaksi Harian
                            </a>
                        <?php endif; ?>

                        <?php if(\Illuminate\Support\Facades\Route::has('modal-beban.index')): ?>
                            <a href="<?php echo e(route('modal-beban.index')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('modal-beban.*')): ?> active <?php endif; ?>">
                                <i class="bi bi-wallet2 me-2"></i> Biaya Usaha
                            </a>
                        <?php endif; ?>

                        <?php if(\Illuminate\Support\Facades\Route::has('laporan.index')): ?>
                            <a href="<?php echo e(route('laporan.index')); ?>"
                               class="nav-link d-flex align-items-center <?php if(request()->routeIs('laporan.*')): ?> active <?php endif; ?>">
                                <i class="bi bi-bar-chart-line me-2"></i> Laporan
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>

            </nav>
        </div>
    </aside>

    
    <div class="flex-grow-1 d-flex flex-column">

        
        <header class="topbar px-3 py-2 d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-2">
                <button class="btn btn-sm btn-outline-secondary d-md-none me-1" type="button" onclick="toggleSidebar()">
                    <i class="bi bi-list"></i>
                </button>
                <span class="fw-semibold"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></span>
            </div>

            <div class="d-flex align-items-center gap-2">
                <?php if(auth()->guard()->check()): ?>
                    <span class="small text-muted d-none d-sm-inline">
                        <?php echo e(auth()->user()->username ?? auth()->user()->email); ?>

                    </span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-box-arrow-right me-1"></i> Keluar
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </header>

        <main class="main-content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function toggleSidebar() {
        const sidebar  = document.getElementById('sidebar');
        const backdrop = document.getElementById('sidebar-backdrop');
        sidebar.classList.toggle('show');
        backdrop.classList.toggle('show');
    }
    document.getElementById('sidebar-backdrop')?.addEventListener('click', toggleSidebar);
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof Swal === 'undefined') return;

    <?php if(session('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil',
            text: <?php echo json_encode(session('success'), 15, 512) ?>,
            toast: true,
            position: 'top-end',
            timer: 2200,
            timerProgressBar: true,
            showConfirmButton: false
        });
    <?php endif; ?>

    <?php if(session('error')): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal',
            text: <?php echo json_encode(session('error'), 15, 512) ?>,
        });
    <?php endif; ?>

    <?php if(session('warning')): ?>
        Swal.fire({
            icon: 'warning',
            title: 'Perhatian',
            text: <?php echo json_encode(session('warning'), 15, 512) ?>,
        });
    <?php endif; ?>
});
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/indf5165/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>