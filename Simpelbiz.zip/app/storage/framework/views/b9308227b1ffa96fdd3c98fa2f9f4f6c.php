<?php
    $laporan = $accessPin->laporan;
?>

<p>Halo,</p>

<p>Berikut PIN untuk mengakses laporan keuangan UMKM:</p>

<p>
    <strong>UMKM:</strong> <?php echo e($laporan->umkm->nama_umkm ?? 'UMKM'); ?><br>
    <strong>Periode:</strong> <?php echo e($laporan->bulan); ?>/<?php echo e($laporan->tahun); ?><br>
    <strong>PIN Akses:</strong> <span style="font-size: 18px"><?php echo e($accessPin->pin); ?></span><br>
    <strong>Berlaku sampai:</strong> <?php echo e($accessPin->expires_at->format('d-m-Y H:i')); ?>

</p>

<p>Silakan kembali ke halaman scan laporan dan masukkan PIN di atas untuk mengunduh PDF.</p>

<p>Terima kasih.</p>
<?php /**PATH /home/indf5165/laravel/resources/views/emails/laporan_access_pin.blade.php ENDPATH**/ ?>