<form method="POST" action="<?php echo e(route('laporan.access.pin.resend')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="laporan_id" value="<?php echo e($laporanId); ?>">
    <input type="hidden" name="email" value="<?php echo e($email); ?>">
    <button type="submit">🔄 Minta PIN Baru</button>
</form><?php /**PATH /home/indf5165/laravel/resources/views/laporan/pin_invalid.blade.php ENDPATH**/ ?>