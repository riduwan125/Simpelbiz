<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lupa Password - QR Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .fade-in {
      animation: fadeIn 0.3s ease-out;
    }
  </style>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen p-4">

  <div class="bg-white shadow-lg rounded-2xl w-full max-w-md overflow-hidden fade-in">
    
    <!-- Header Section -->
    <div class="p-8 pb-6">
      <div class="text-center mb-6">
        <div class="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-xl mb-4">
          <svg class="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
          </svg>
        </div>
        <h2 class="text-xl font-semibold text-gray-900 mb-1">Lupa Password?</h2>
        <p class="text-gray-600 text-sm">Masukkan email untuk menerima QR Code login</p>
      </div>

      <!-- Alert Messages -->
      <?php if(session('status')): ?>
        <div class="mb-5 p-3.5 rounded-lg bg-green-50 border border-green-200 fade-in">
          <div class="flex items-start gap-3">
            <svg class="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <p class="text-sm text-green-800 leading-relaxed"><?php echo e(session('status')); ?></p>
          </div>
        </div>
      <?php endif; ?>

      <?php if($errors->any()): ?>
        <div class="mb-5 p-3.5 rounded-lg bg-red-50 border border-red-200 fade-in">
          <div class="flex items-start gap-3">
            <svg class="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
            <ul class="space-y-1">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="text-sm text-red-800"><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
      <?php endif; ?>

      <!-- Info Box -->
      <div class="mb-5 p-3.5 rounded-lg bg-blue-50 border border-blue-200">
        <div class="flex items-start gap-3">
          <svg class="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
          </svg>
          <div>
            <p class="text-sm font-semibold text-blue-900 mb-1">Informasi</p>
            <p class="text-sm text-blue-800 leading-relaxed">
              Gunakan email Gmail/Workspace yang aktif dan sudah diverifikasi. QR Code akan dikirim ke email Anda.
            </p>
          </div>
        </div>
      </div>

      <div class="text-center text-gray-500 text-sm mb-5">atau</div>

      <!-- Form Section -->
      <form method="POST" action="<?php echo e(route('qr.send')); ?>" class="space-y-5" autocomplete="off" novalidate>
        <?php echo csrf_field(); ?>
        
        <div>
          <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
            Alamat Email
          </label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            value="<?php echo e(old('email')); ?>" 
            required
            placeholder="nama@example.com"
            class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-blue-500 focus:ring-3 focus:ring-blue-100 outline-none transition-all text-gray-700 placeholder-gray-400 text-sm"
          >
        </div>

        <button 
          type="submit"
          class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium shadow-sm hover:shadow transition-all duration-200 flex items-center justify-center gap-2"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/>
          </svg>
          <span>Kirim QR ke Email</span>
        </button>
      </form>

      <!-- Back to Login -->
      <div class="mt-4">
        <a 
          href="<?php echo e(route('login')); ?>" 
          class="w-full bg-white hover:bg-gray-50 text-gray-700 py-3 rounded-lg font-medium border border-gray-300 transition-all duration-200 flex items-center justify-center gap-2"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
          </svg>
          <span>Kembali ke Login</span>
        </a>
      </div>

      <!-- Help Section -->
      <div class="mt-5 p-4 bg-gray-50 rounded-lg">
        <div class="flex items-start gap-3">
          <svg class="w-5 h-5 text-gray-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
          <div>
            <p class="text-xs font-semibold text-gray-900 mb-1">Butuh Bantuan?</p>
            <p class="text-xs text-gray-600 leading-relaxed">
              Tidak menerima QR Code? Periksa folder spam atau 
              <a href="#" class="text-blue-600 hover:text-blue-700 font-medium underline">hubungi support</a>
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <div class="px-8 py-5 bg-gray-50 border-t border-gray-100 text-center">
      <p class="text-sm text-gray-600">
        Belum punya akun? 
        <a href="<?php echo e(route('register')); ?>" class="text-blue-600 hover:text-blue-700 font-medium">Daftar Sekarang</a>
      </p>
    </div>

  </div>

  <script>
    // Auto focus pada input email saat halaman dimuat
    window.addEventListener('load', function() {
      const emailInput = document.getElementById('email');
      if (emailInput) {
        emailInput.focus();
      }
    });

    // Loading state saat form disubmit
    document.querySelector('form').addEventListener('submit', function(e) {
      const submitBtn = this.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.innerHTML = `
        <svg class="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <span>Mengirim...</span>
      `;
    });
  </script>

</body>
</html><?php /**PATH /home/indf5165/laravel/resources/views/auth/forgot-password-qr.blade.php ENDPATH**/ ?>