<form method="post" action="<?php echo e(route('profile.password.update')); ?>" class="mt-3">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <?php if(session('status') === 'password-updated'): ?>
        <div class="alert alert-success py-2 px-3 mb-3">
            Password berhasil diperbarui.
        </div>
    <?php endif; ?>

    <div class="mb-3">
        <label class="form-label fw-semibold">Password Baru</label>
        <input id="password"
               name="password"
               type="password"
               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               autocomplete="new-password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-4">
        <label class="form-label fw-semibold">Konfirmasi Password Baru</label>
        <input id="password_confirmation"
               name="password_confirmation"
               type="password"
               class="form-control"
               autocomplete="new-password">
    </div>

    <div class="d-flex justify-content-end">
        <button type="submit" class="btn btn-primary px-4">
            Simpan
        </button>
    </div>
</form>
<?php /**PATH /home/indf5165/laravel/resources/views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>