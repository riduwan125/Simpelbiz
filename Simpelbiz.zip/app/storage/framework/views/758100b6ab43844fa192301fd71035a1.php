<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SimpelBiz - Solusi Manajemen Keuangan UMKM</title>

    <!-- ✅ FAVICON (agar tab browser tidak pakai logo Laravel) -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>?v=3">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>?v=3">
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.ico')); ?>?v=3">

    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        * { font-family: 'Inter', sans-serif; }

        @keyframes fadeInUp { from {opacity:0;transform:translateY(40px);} to {opacity:1;transform:translateY(0);} }
        @keyframes slideInRight { from {opacity:0;transform:translateX(30px);} to {opacity:1;transform:translateX(0);} }
        @keyframes float { 0%,100% {transform:translateY(0);} 50% {transform:translateY(-15px);} }

        .animate-fadeInUp { animation: fadeInUp 1s ease-out forwards; }
        .animate-slideInRight { animation: slideInRight 1s ease-out forwards; }
        .animate-float { animation: float 4s ease-in-out infinite; }

        .gradient-bg { background: linear-gradient(135deg, #0f172a, #1e293b, #334155); }
        .gradient-blue { background: linear-gradient(135deg, #3b82f6, #2563eb); }

        .gradient-text {
            background: linear-gradient(135deg, #3b82f6, #06b6d4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .glass-morphism {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
        }

        .card-elegant { transition: .4s; border: 1px solid rgba(226,232,240,.8); }
        .card-elegant:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.15);
            border-color: rgba(59,130,246,0.3);
        }

        .feature-icon { background: linear-gradient(135deg,#eff6ff,#dbeafe); transition:.3s; }
        .card-elegant:hover .feature-icon { background: linear-gradient(135deg,#3b82f6,#2563eb); transform: scale(1.1) rotate(5deg); }
        .card-elegant:hover .feature-icon svg { color: white; }

        .stat-card {
            background: linear-gradient(135deg,rgba(255,255,255,0.1),rgba(255,255,255,0.05));
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg,#3b82f6,#2563eb);
            transition:.3s;
            box-shadow: 0 10px 25px -5px rgba(59,130,246,.4);
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 20px 35px -5px rgba(59,130,246,.5); }

        .section-divider { height:1px; background:linear-gradient(90deg,transparent,rgba(226,232,240,.5),transparent); }

        .dashboard-preview {
            border-radius: 16px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            border: 1px solid rgba(226,232,240,.8);
        }
    </style>
</head>

<body class="antialiased bg-gray-50">

<!-- Header Navigation -->
<header class="fixed top-0 inset-x-0 z-50 bg-white shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between py-3 sm:py-4">
            <!-- Logo -->
            <div class="flex items-center space-x-3">
    <img src="/images/logo.png?v=4"
         alt="Logo SimpelBiz"
         class="w-12 h-12 sm:w-14 sm:h-14 object-contain">
    <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">
        SimpelBiz
    </h1>
</div>



            <!-- Menu desktop -->
            <nav class="hidden md:flex items-center space-x-8">
                <a href="#fitur" class="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Fitur</a>
                <a href="#keunggulan" class="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Keunggulan</a>
                <a href="#tentang" class="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Tentang</a>
                <a href="#kontak" class="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Kontak</a>
            </nav>

            <!-- Tombol auth desktop -->
            <div class="hidden md:flex items-center space-x-3">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>"
                       class="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white rounded-lg text-sm font-semibold shadow-lg shadow-purple-500/30 transition-all">
                        Dashboard
                    </a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="text-sm text-gray-600 hover:text-red-500 transition-colors">
                            Logout
                        </button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"
                       class="btn-primary px-5 py-2 text-white font-semibold rounded-xl text-sm inline-flex items-center justify-center">
                        Masuk
                    </a>
                    <a href="<?php echo e(route('register')); ?>"
                       class="px-5 py-2 border border-blue-500 text-blue-600 font-semibold rounded-xl text-sm hover:bg-blue-50 transition-all">
                        Daftar
                    </a>
                <?php endif; ?>
            </div>

            <!-- Tombol hamburger (mobile) -->
            <button id="mobileMenuOpen"
                    class="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-full border border-gray-200 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500/70">
                <span class="sr-only">Buka menu</span>
                <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>
        </div>
    </div>

    <!-- FULLSCREEN MOBILE MENU -->
    <div id="mobileMenu"
         class="fixed inset-0 bg-white/95 backdrop-blur-xl z-40 opacity-0 pointer-events-none transform scale-95 transition-all duration-200 ease-out">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 pt-5 flex items-center justify-between">
            <!-- Logo kecil di overlay -->
            <div class="flex items-center space-x-2">
                <div class="w-8 h-8 bg-gradient-blue rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                    </svg>
                </div>
                <span class="text-lg font-bold text-gray-900">SimpelBiz</span>
            </div>

            <!-- Tombol close -->
            <button id="mobileMenuClose"
                    class="inline-flex items-center justify-center w-10 h-10 rounded-full border border-gray-200 bg-white shadow-sm">
                <span class="sr-only">Tutup menu</span>
                <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>

        <div class="mt-10 px-6 flex flex-col items-center space-y-6 text-lg font-semibold">
            <a href="#fitur" class="mobile-link text-gray-800 hover:text-blue-600 transition-colors">Fitur</a>
            <a href="#keunggulan" class="mobile-link text-gray-800 hover:text-blue-600 transition-colors">Keunggulan</a>
            <a href="#tentang" class="mobile-link text-gray-800 hover:text-blue-600 transition-colors">Tentang</a>
            <a href="#kontak" class="mobile-link text-gray-800 hover:text-blue-600 transition-colors">Kontak</a>

            <div class="w-full max-w-xs pt-6 mt-4 border-t border-gray-200">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>"
                       class="block w-full mb-3 text-center px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-purple-700 text-white font-semibold shadow-lg shadow-purple-500/30">
                        Buka Dashboard
                    </a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="w-full text-center px-6 py-3 rounded-xl border border-red-500 text-red-500 font-semibold hover:bg-red-50 transition-all">
                            Logout
                        </button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"
                       class="block w-full mb-3 text-center px-6 py-3 rounded-xl btn-primary text-white font-semibold">
                        Masuk
                    </a>
                    <a href="<?php echo e(route('register')); ?>"
                       class="block w-full text-center px-6 py-3 rounded-xl border border-blue-500 text-blue-600 font-semibold hover:bg-blue-50 transition-all">
                        Daftar Gratis
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

<!-- HERO -->
<section class="pt-32 pb-20 px-6 lg:px-8 bg-gradient-to-br from-slate-50 via-blue-50 to-cyan-50 relative overflow-hidden">

    <div class="absolute inset-0 opacity-10">
        <div class="absolute top-20 left-10 w-72 h-72 bg-blue-400 rounded-full blur-3xl"></div>
        <div class="absolute bottom-20 right-10 w-96 h-96 bg-cyan-400 rounded-full blur-3xl"></div>
    </div>

    <div class="max-w-7xl mx-auto relative grid lg:grid-cols-2 gap-12 items-center">

        <!-- Left -->
        <div class="animate-fadeInUp">
            <div class="inline-flex items-center px-4 py-2 bg-blue-100 rounded-full text-blue-700 text-sm font-semibold mb-6">
                Gratis 100% – Platform Keuangan untuk UMKM
            </div>

            <h1 class="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Kelola Keuangan Bisnis dengan
                <span class="gradient-text block mt-2">Profesional & Efisien</span>
            </h1>

            <p class="text-lg text-gray-600 leading-relaxed mb-8 max-w-xl">
                Platform manajemen keuangan modern yang membantu UMKM mencatat, menganalisis, dan mengoptimalkan arus kas secara real-time.
            </p>

            <a href="<?php echo e(route('register')); ?>"
               class="btn-primary px-8 py-4 text-white font-semibold rounded-xl inline-flex items-center">
                Mulai Sekarang
                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M13 7l5 5m0 0l-5 5m5-5H6"></path>
                </svg>
            </a>
        </div>

        <!-- Right -->
        <div class="hidden lg:block animate-slideInRight">
            <div class="relative">
                <!-- Fake Dashboard -->
                <div class="dashboard-preview bg-white p-6 transform rotate-2">
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex items-center space-x-3">
                            <div class="w-10 h-10 bg-blue-100 rounded-full"></div>
                            <div>
                                <div class="h-3 w-24 bg-gray-200 rounded mb-1"></div>
                                <div class="h-2 w-16 bg-gray-100 rounded"></div>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <div class="w-8 h-8 bg-gray-100 rounded"></div>
                            <div class="w-8 h-8 bg-gray-100 rounded"></div>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4 mb-6">
                        <div class="bg-blue-600 rounded-xl p-4 text-white">
                            <div class="text-xs opacity-90">Total Pemasukan</div>
                            <div class="text-2xl font-bold">Rp 45,2 jt</div>
                        </div>
                        <div class="bg-cyan-600 rounded-xl p-4 text-white">
                            <div class="text-xs opacity-90">Total Pengeluaran</div>
                            <div class="text-2xl font-bold">Rp 28,8 jt</div>
                        </div>
                    </div>

                    <div class="space-y-3">
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor"
                                         viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                              d="M12 4v16m8-8H4"></path>
                                    </svg>
                                </div>
                                <div>
                                    <div class="font-semibold text-sm">Penjualan Produk</div>
                                    <div class="text-xs text-gray-500">23 Nov 2025, 14:30</div>
                                </div>
                            </div>
                            <div class="text-green-600 font-bold">+Rp 2,5 jt</div>
                        </div>

                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                                    <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor"
                                         viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                              d="M20 12H4"></path>
                                    </svg>
                                </div>
                                <div>
                                    <div class="font-semibold text-sm">Pembelian Stok</div>
                                    <div class="text-xs text-gray-500">23 Nov 2025, 10:15</div>
                                </div>
                            </div>
                            <div class="text-red-600 font-bold">-Rp 1,2 jt</div>
                        </div>
                    </div>
                </div>

                <div class="absolute -bottom-6 -right-6 bg-white dashboard-preview p-4 w-64 animate-float">
                    <div class="text-sm font-semibold mb-3">Analisis Bulan Ini</div>
                    <div class="h-20 flex items-end space-x-2">
                        <div class="flex-1 bg-blue-200 rounded-t" style="height:45%"></div>
                        <div class="flex-1 bg-blue-300 rounded-t" style="height:65%"></div>
                        <div class="flex-1 bg-blue-400 rounded-t" style="height:80%"></div>
                        <div class="flex-1 bg-blue-500 rounded-t" style="height:95%"></div>
                        <div class="flex-1 bg-blue-600 rounded-t" style="height:100%"></div>
                    </div>
                </div>

            </div>
        </div>

    </div>

</section>

<!-- STATS -->
<section class="py-16 gradient-bg">
    <div class="max-w-7xl mx-auto px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-8">

        <div class="stat-card rounded-xl p-6 text-center text-white">
            <div class="text-4xl font-bold mb-2">100+</div>
            <div class="text-sm text-gray-300">Pengguna Aktif</div>
        </div>

        <div class="stat-card rounded-xl p-6 text-center text-white">
            <div class="text-4xl font-bold mb-2">1,000+</div>
            <div class="text-sm text-gray-300">Transaksi Tercatat</div>
        </div>

        <div class="stat-card rounded-xl p-6 text-center text-white">
            <div class="text-4xl font-bold mb-2">24/7</div>
            <div class="text-sm text-gray-300">Akses Kapan Saja</div>
        </div>

        <div class="stat-card rounded-xl p-6 text-center text-white">
            <div class="text-4xl font-bold mb-2">100%</div>
            <div class="text-sm text-gray-300">Gratis Selamanya</div>
        </div>

    </div>
</section>

<!-- FEATURES SECTION -->
<section id="fitur" class="py-24 bg-white">
    <div class="max-w-7xl mx-auto px-6 lg:px-8">

        <div class="text-center mb-16">
            <div class="inline-block px-4 py-2 bg-blue-50 rounded-full text-blue-600 text-sm font-semibold mb-4">
                Fitur Unggulan
            </div>

            <h2 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
                Solusi Lengkap untuk <span class="gradient-text">Manajemen Keuangan</span>
            </h2>

            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Semua yang Anda butuhkan untuk mengelola keuangan bisnis dengan efisien dan profesional
            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

            <!-- Card 1 -->
            <div class="card-elegant bg-white rounded-2xl p-8">
                <div class="feature-icon w-14 h-14 rounded-xl flex items-center justify-center mb-6">
                    <svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0
                            a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z">
                        </path>
                    </svg>
                </div>

                <h3 class="text-xl font-bold text-gray-900 mb-3">Laporan Keuangan Real-Time</h3>

                <p class="text-gray-600 leading-relaxed">
                    Pantau performa keuangan bisnis Anda secara real-time dengan dashboard interaktif dan visualisasi data.
                </p>
            </div>

            <!-- Card 2 -->
            <div class="card-elegant bg-white rounded-2xl p-8">
                <div class="feature-icon w-14 h-14 rounded-xl flex items-center justify-center mb-6">
                    <svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2
                            0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z">
                        </path>
                    </svg>
                </div>

                <h3 class="text-xl font-bold text-gray-900 mb-3">Manajemen Arus Kas</h3>

                <p class="text-gray-600 leading-relaxed">
                    Kelola pemasukan dan pengeluaran dengan sistem pencatatan yang mudah digunakan.
                </p>
            </div>

            <!-- Card 3 -->
            <div class="card-elegant bg-white rounded-2xl p-8">
                <div class="feature-icon w-14 h-14 rounded-xl flex items-center justify-center mb-6">
                    <svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4
                            12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0
                            00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0
                            001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1
                            0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1
                            1 0 00-1 1v2a1 1 0 001 1z">
                        </path>
                    </svg>
                </div>

                <h3 class="text-xl font-bold text-gray-900 mb-3">Login dengan QR Code</h3>

                <p class="text-gray-600 leading-relaxed">
                    Akses akun dengan aman menggunakan QR Code pada proses lupa password.
                </p>
            </div>

            <!-- Card 4 -->
            <div class="card-elegant bg-white rounded-2xl p-8">
                <div class="feature-icon w-14 h-14 rounded-xl flex items-center justify-center mb-6">
                    <svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0
                            012-2h5.586a1 1 0 01.707.293l5.414
                            5.414a1 1 0 01.293.707V19a2 2 0 01-2
                            2z">
                        </path>
                    </svg>
                </div>

                <h3 class="text-xl font-bold text-gray-900 mb-3">Export Laporan PDF</h3>

                <p class="text-gray-600 leading-relaxed">
                    Unduh laporan keuangan dalam format PDF untuk dibagikan atau disimpan.
                </p>
            </div>

            <!-- Card 5 -->
            <div class="card-elegant bg-white rounded-2xl p-8">
                <div class="feature-icon w-14 h-14 rounded-xl flex items-center justify-center mb-6">
                    <svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 18h.01M8 21h8a2 2 0
                            002-2V5a2 2 0 00-2-2H8a2 2 0 00-2
                            2v14a2 2 0 002 2z">
                        </path>
                    </svg>
                </div>

                <h3 class="text-xl font-bold text-gray-900 mb-3">Akses Multi-Device</h3>

                <p class="text-gray-600 leading-relaxed">
                    Gunakan aplikasi ini dari HP, tablet, maupun komputer.
                </p>
            </div>

            <!-- Card 6 -->
            <div class="card-elegant bg-white rounded-2xl p-8">
                <div class="feature-icon w-14 h-14 rounded-xl flex items-center justify-center mb-6">
                    <svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M16 8v8m-4-5v5m-4-2v2m-2
                            4h12a2 2 0 002-2V6a2 2 0
                            00-2-2H6a2 2 0
                            00-2 2v12a2 2 0 002 2z">
                        </path>
                    </svg>
                </div>

                <h3 class="text-xl font-bold text-gray-900 mb-3">Visualisasi Data</h3>

                <p class="text-gray-600 leading-relaxed">
                    Grafik dan chart yang mudah dibaca untuk analisis cepat.
                </p>
            </div>
        </div>

    </div>
</section>

<!-- KEUNGGULAN SECTION -->
<section id="keunggulan" class="py-24 bg-gradient-to-br from-slate-900 to-slate-800 text-white relative overflow-hidden">

    <div class="absolute inset-0 opacity-10">
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full blur-3xl"></div>
        <div class="absolute bottom-0 right-0 w-96 h-96 bg-cyan-500 rounded-full blur-3xl"></div>
    </div>

    <div class="max-w-7xl mx-auto px-6 lg:px-8 relative">

        <div class="text-center mb-16">
            <div class="inline-block px-4 py-2 bg-blue-500/20 rounded-full text-blue-300 text-sm font-semibold mb-4">
                Mengapa SimpelBiz?
            </div>

            <h2 class="text-4xl lg:text-5xl font-bold mb-4">
                Keunggulan yang Membedakan Kami
            </h2>

            <p class="text-lg text-gray-300 max-w-2xl mx-auto">
                Solusi keuangan yang dirancang khusus untuk UMKM Indonesia
            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

            <div class="group">
                <div class="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all">

                    <div class="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M13 10V3L4 14h7v7l9-11h-7z">
                            </path>
                        </svg>
                    </div>

                    <h3 class="text-xl font-bold mb-3">Setup Cepat & Mudah</h3>

                    <p class="text-gray-300 leading-relaxed">
                        Mulai tanpa instalasi rumit — cukup daftar dan langsung bisa digunakan.
                    </p>
                </div>
            </div>

            <div class="group">
                <div class="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all">
                    <div class="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2
                                  m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1
                                  c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                            </path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Gratis Selamanya</h3>
                    <p class="text-gray-300 leading-relaxed">Fitur inti dapat digunakan tanpa biaya selamanya.</p>
                </div>
            </div>

            <div class="group">
                <div class="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all">
                    <div class="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172
                                  9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0
                                  11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z">
                            </path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Support Responsif</h3>
                    <p class="text-gray-300 leading-relaxed">Dukungan cepat saat Anda butuh bantuan.</p>
                </div>
            </div>

            <div class="group">
                <div class="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all">
                    <div class="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112
                                  2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003
                                  9c0 5.591 3.824 10.29 9 11.622 5.176-1.332
                                  9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z">
                            </path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Backup Otomatis</h3>
                    <p class="text-gray-300 leading-relaxed">Data aman, tersimpan otomatis di server cloud.</p>
                </div>
            </div>

            <div class="group">
                <div class="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all">
                    <div class="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M7 12l3-3 3 3 4-4M8 21l4-4 4
                                  4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1
                                  1 0 01-1-1V4z">
                            </path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Update Berkala</h3>
                    <p class="text-gray-300 leading-relaxed">Dapatkan fitur baru secara berkala.</p>
                </div>
            </div>

            <div class="group">
                <div class="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all">
                    <div class="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17
                                  20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7
                                  20H2v-2a3 3 0 015.356-1.857M7 20v-2
                                  c0-.656.126-1.283.356-1.857m0 0a5.002 5.002
                                  0 019.288 0M15 7a3 3 0 11-6 0 3 3
                                  0 016 0zm6 3a2 2 0 11-4 0 2 2 0
                                  014 0zM7 10a2 2 0 11-4 0 2 2 0
                                  014 0z">
                            </path>
                        </svg>
                    </div>

                    <h3 class="text-xl font-bold mb-3">Multi-User Access</h3>

                    <p class="text-gray-300 leading-relaxed">
                        Kolaborasi bersama tim dengan pembagian akses.
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ABOUT SECTION -->
<section id="tentang" class="py-24 bg-white">
    <div class="max-w-7xl mx-auto px-6 lg:px-8">

        <div class="grid lg:grid-cols-2 gap-16 items-center">

            <!-- LEFT -->
            <div>
                <div class="inline-block px-4 py-2 bg-blue-50 rounded-full text-blue-600 text-sm font-semibold mb-6">
                    Tentang SimpelBiz
                </div>

                <h2 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                    Platform Sederhana untuk <span class="gradient-text">Kelola Keuangan</span> UMKM
                </h2>

                <p class="text-lg text-gray-600 leading-relaxed mb-6">
                    SimpelBiz adalah platform pencatatan keuangan berbasis web untuk membantu UMKM
                    mencatat pemasukan & pengeluaran secara terstruktur.
                </p>

                <p class="text-lg text-gray-600 leading-relaxed mb-8">
                    Dibuat dengan desain sederhana namun modern, sehingga mudah digunakan siapa pun.
                </p>

                <div class="grid grid-cols-2 gap-6 mb-8">
                    <div class="border-l-4 border-blue-500 pl-4">
                        <div class="text-3xl font-bold text-gray-900 mb-1">2025</div>
                        <div class="text-sm text-gray-600">Tahun Peluncuran</div>
                    </div>
                    <div class="border-l-4 border-blue-500 pl-4">
                        <div class="text-3xl font-bold text-gray-900 mb-1">Mudah</div>
                        <div class="text-sm text-gray-600">Digunakan</div>
                    </div>
                    <div class="border-l-4 border-blue-500 pl-4">
                        <div class="text-3xl font-bold text-gray-900 mb-1">100%</div>
                        <div class="text-sm text-gray-600">Gratis</div>
                    </div>
                    <div class="border-l-4 border-blue-500 pl-4">
                        <div class="text-3xl font-bold text-gray-900 mb-1">Online</div>
                        <div class="text-sm text-gray-600">Akses Kapan Saja</div>
                    </div>
                </div>

                <div class="flex gap-4">
                    <a href="<?php echo e(route('register')); ?>"
                       class="btn-primary px-8 py-4 text-white font-semibold rounded-xl">
                        Mulai Sekarang
                    </a>
                    <a href="#kontak"
                       class="px-8 py-4 border-2 border-gray-200 text-gray-700 font-semibold rounded-xl hover:border-blue-300 hover:bg-gray-50 transition-all">
                        Hubungi Kami
                    </a>
                </div>
            </div>

            <!-- RIGHT — Fake UI -->
            <div class="relative">
                <div class="absolute inset-0 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-3xl blur-3xl opacity-30"></div>

                <div class="relative bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">

                    <div class="grid grid-cols-2 gap-6 mb-6">
                        <div class="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 text-center">
                            <div class="text-4xl mb-2">📊</div>
                            <div class="text-2xl font-bold text-gray-900 mb-1">100+</div>
                            <div class="text-sm text-gray-600">Pengguna</div>
                        </div>

                        <div class="bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-2xl p-6 text-center">
                            <div class="text-4xl mb-2">💴</div>
                            <div class="text-2xl font-bold text-gray-900 mb-1">1,000+</div>
                            <div class="text-sm text-gray-600">Transaksi</div>
                        </div>
                    </div>

                    <div class="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl p-6 text-white mb-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="text-sm font-semibold">Fitur Utama</div>
                            <div class="text-2xl">✨</div>
                        </div>

                        <div class="grid grid-cols-3 gap-4 text-center">
                            <div>
                                <div class="text-2xl font-bold">Mudah</div>
                                <div class="text-xs opacity-90">Dipakai</div>
                            </div>
                            <div>
                                <div class="text-2xl font-bold">Cepat</div>
                                <div class="text-xs opacity-90">Akses</div>
                            </div>
                            <div>
                                <div class="text-2xl font-bold">Aman</div>
                                <div class="text-xs opacity-90">Data</div>
                            </div>
                        </div>

                    </div>

                    <div class="space-y-3">
                        <div class="flex items-center space-x-3 text-sm">
                            <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                                ✔
                            </div>
                            <span class="text-gray-700 font-medium">Berbasis Web</span>
                        </div>

                        <div class="flex items-center space-x-3 text-sm">
                            <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                                ✔
                            </div>
                            <span class="text-gray-700 font-medium">Pencatatan Mudah</span>
                        </div>

                        <div class="flex items-center space-x-3 text-sm">
                            <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                                ✔
                            </div>
                            <span class="text-gray-700 font-medium">Laporan Otomatis</span>
                        </div>
                    </div>

                </div>
            </div>

        </div>

    </div>
</section>

<!-- CTA SECTION -->
<section class="py-24 bg-gradient-to-br from-blue-600 via-blue-700 to-cyan-600 relative overflow-hidden">
    <div class="absolute inset-0 opacity-10">
        <div class="absolute top-0 left-1/4 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div class="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-300 rounded-full blur-3xl"></div>
    </div>

    <div class="max-w-4xl mx-auto px-6 lg:px-8 text-center relative">
        <h2 class="text-4xl lg:text-5xl font-bold text-white mb-6">
            Siap Mengoptimalkan Keuangan Bisnis Anda?
        </h2>

        <p class="text-xl text-blue-100 mb-10 max-w-2xl mx-auto leading-relaxed">
            Bergabunglah dengan SimpelBiz dan kelola keuangan UMKM Anda secara profesional dan efisien — 100% Gratis!
        </p>

        <div class="flex flex-col sm:flex-row gap-4 justify-center mb-10">
            <a href="<?php echo e(route('register')); ?>"
               class="inline-flex items-center justify-center px-10 py-5 bg-white text-blue-600 rounded-xl font-bold hover:bg-gray-50 transition-all shadow-2xl transform hover:scale-105">
                Mulai Gratis Sekarang
                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M13 7l5 5m0 0l-5 5m5-5H6"></path>
                </svg>
            </a>

            <a href="#kontak"
               class="inline-flex items-center justify-center px-10 py-5 bg-transparent border-2 border-white text-white rounded-xl font-bold hover:bg-white/10 transition-all">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z">
                    </path>
                </svg>
                Hubungi Kami
            </a>
        </div>

        <div class="flex flex-wrap items-center justify-center gap-8 text-sm text-blue-100">
            <div class="flex items-center">
                <svg class="w-5 h-5 text-green-300 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0
                             00-1.414-1.414L9 10.586 7.707 9.293a1 1 0
                             00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clip-rule="evenodd"></path>
                </svg>
                100% Gratis
            </div>

            <div class="flex items-center">
                <svg class="w-5 h-5 text-green-300 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0
                             00-1.414-1.414L9 10.586 7.707 9.293a1 1 0
                             00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clip-rule="evenodd"></path>
                </svg>
                Setup dalam 5 Menit
            </div>

            <div class="flex items-center">
                <svg class="w-5 h-5 text-green-300 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0
                             00-1.414-1.414L9 10.586 7.707 9.293a1 1 0
                             00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clip-rule="evenodd"></path>
                </svg>
                Tanpa Biaya Tersembunyi
            </div>
        </div>
    </div>
</section>

<!-- CONTACT SECTION -->
<section id="kontak" class="py-24 bg-gray-50">
    <div class="max-w-4xl mx-auto px-6 lg:px-8">

        <div class="text-center mb-12">
            <div class="inline-block px-4 py-2 bg-blue-50 rounded-full text-blue-600 text-sm font-semibold mb-4">
                Hubungi Kami
            </div>

            <h2 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
                Ada Pertanyaan? <span class="gradient-text">Kami Siap Membantu</span>
            </h2>

            <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                Tim support kami siap menjawab pertanyaan dan membantu Anda memulai mengelola keuangan bisnis dengan lebih baik.
            </p>
        </div>

        <div class="grid md:grid-cols-1 gap-6 mb-12">
            <div class="bg-white rounded-2xl p-6 text-center shadow-sm border border-gray-100 hover:shadow-md transition-all">
                <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0
                                 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z">
                        </path>
                    </svg>
                </div>

                <h3 class="font-bold text-gray-900 mb-2">Email</h3>

                <a href="mailto:umkmsystem@gmail.com" class="text-blue-600 hover:text-blue-700 font-medium">
                    umkmsystem@gmail.com
                </a>
            </div>
        </div>

        <div class="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <div class="text-center">
                <a href="mailto:umkmsystem@gmail.com"
                   class="inline-flex items-center justify-center px-10 py-5 btn-primary text-white font-bold rounded-xl">
                    <svg class="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0
                                 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z">
                        </path>
                    </svg>
                    Kirim Email Sekarang
                </a>

                <p class="text-sm text-gray-500 mt-4">
                    Kami akan merespon dalam 1x24 jam
                </p>
            </div>
        </div>

    </div>
</section>

<!-- FOOTER -->
<footer class="bg-slate-900 text-gray-300">
    <div class="max-w-7xl mx-auto px-6 lg:px-8 py-16">

        <div class="grid md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">

            <!-- Brand -->
            <div class="lg:col-span-2">
                <div class="flex items-center space-x-3 mb-6">
                    <div class="w-10 h-10 bg-gradient-blue rounded-lg flex items-center justify-center">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                                  d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z">
                            </path>
                        </svg>
                    </div>

                    <h3 class="text-2xl font-bold text-white">SimpelBiz</h3>
                </div>

                <p class="text-gray-400 mb-6 max-w-sm leading-relaxed">
                    Platform manajemen keuangan modern yang membantu UMKM Indonesia berkembang dengan lebih cerdas dan efisien.
                </p>

                <div class="flex space-x-4">
                    <a href="#"
                       class="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"></path>
                        </svg>
                    </a>

                    <a href="#"
                       class="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"></path>
                        </svg>
                    </a>

                    <a href="#"
                       class="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.941z"></path>
                        </svg>
                    </a>

                    <a href="#"
                       class="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"></path>
                        </svg>
                    </a>
                </div>
            </div>

            <div>
                <h4 class="text-white font-bold mb-4">Produk</h4>
                <ul class="space-y-3">
                    <li><a href="#fitur" class="hover:text-blue-400 transition-colors">Fitur</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition-colors">Panduan</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition-colors">Tutorial</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-white font-bold mb-4">Perusahaan</h4>
                <ul class="space-y-3">
                    <li><a href="#tentang" class="hover:text-blue-400 transition-colors">Tentang Kami</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition-colors">Karir</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition-colors">Blog</a></li>
                    <li><a href="#kontak" class="hover:text-blue-400 transition-colors">Kontak</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-white font-bold mb-4">Legal</h4>
                <ul class="space-y-3">
                    <li><a href="#" class="hover:text-blue-400 transition-colors">Kebijakan Privasi</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition-colors">Syarat & Ketentuan</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition-colors">Keamanan</a></li>
                    <li><a href="#" class="hover:text-blue-400 transition-colors">FAQ</a></li>
                </ul>
            </div>

        </div>

        <div class="section-divider mb-8"></div>

        <div class="flex flex-col md:flex-row justify-between items-center gap-4">
            <p class="text-gray-400 text-sm">
                © 2025 SimpelBiz. All rights reserved.
            </p>

            <div class="flex items-center space-x-6 text-sm">
                <span class="flex items-center">
                    <svg class="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0
                                 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0
                                 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                              clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-gray-400">Secure</span>
                </span>

                <span class="flex items-center">
                    <svg class="w-4 h-4 text-blue-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"></path>
                    </svg>
                    <span class="text-gray-400">Reliable</span>
                </span>

                <span class="flex items-center">
                    <svg class="w-4 h-4 text-purple-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                              d="M18 10a8 8 0 11-16 0 8 8 0
                                 0116 0zm-7-4a1 1 0 11-2 0 1 1 0
                                 012 0zM9 9a1 1 0 000 2v3a1 1 0
                                 001 1h1a1 1 0 100-2v-3a1 1 0
                                 00-1-1H9z"
                              clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-gray-400">Easy to Use</span>
                </span>
            </div>
        </div>

    </div>
</footer>

<!-- SCROLL TO TOP BUTTON -->
<button id="scrollTop"
        class="fixed bottom-8 right-8 w-12 h-12 bg-gradient-blue text-white rounded-full shadow-2xl flex items-center justify-center opacity-0 invisible transition-all hover:scale-110 z-40">
    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M5 10l7-7m0 0l7 7m-7-7v18"></path>
    </svg>
</button>

<script>
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href && href.startsWith('#')) {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });

    // Scroll to top button visibility
    const scrollTopBtn = document.getElementById('scrollTop');

    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.remove('opacity-0', 'invisible');
            scrollTopBtn.classList.add('opacity-100', 'visible');
        } else {
            scrollTopBtn.classList.add('opacity-0', 'invisible');
            scrollTopBtn.classList.remove('opacity-100', 'visible');
        }
    });

    // Scroll to top action
    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Intersection Observer untuk animasi kartu
    const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.card-elegant, .stat-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // Mobile fullscreen menu
    const mobileMenu     = document.getElementById('mobileMenu');
    const mobileOpenBtn  = document.getElementById('mobileMenuOpen');
    const mobileCloseBtn = document.getElementById('mobileMenuClose');
    const mobileLinks    = document.querySelectorAll('#mobileMenu .mobile-link');

    function openMobileMenu() {
        mobileMenu.classList.remove('opacity-0', 'pointer-events-none', 'scale-95');
        mobileMenu.classList.add('opacity-100', 'pointer-events-auto', 'scale-100');
    }

    function closeMobileMenu() {
        mobileMenu.classList.add('opacity-0', 'pointer-events-none', 'scale-95');
        mobileMenu.classList.remove('opacity-100', 'pointer-events-auto', 'scale-100');
    }

    mobileOpenBtn.addEventListener('click', openMobileMenu);
    mobileCloseBtn.addEventListener('click', closeMobileMenu);
    mobileLinks.forEach(link => link.addEventListener('click', closeMobileMenu));
</script>

</body>
</html>
<?php /**PATH /home/indf5165/laravel/resources/views/welcome.blade.php ENDPATH**/ ?>