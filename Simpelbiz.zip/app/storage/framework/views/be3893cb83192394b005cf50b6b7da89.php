

<?php $__env->startSection('page-title', 'Profil Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">

    
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-3">Informasi UMKM</h5>

            <?php if($umkm): ?>
                <div class="mb-2">
                    <span class="text-muted d-block">Nama UMKM</span>
                    <span class="fw-semibold"><?php echo e($umkm->nama_umkm); ?></span>
                </div>

                <div class="mb-2">
                    <span class="text-muted d-block">Jenis Usaha</span>
                    <span class="fw-semibold"><?php echo e($umkm->jenis_usaha); ?></span>
                </div>

                <div class="mb-2">
                    <span class="text-muted d-block">Alamat</span>
                    <span class="fw-semibold"><?php echo e($umkm->alamat_umkm); ?></span>
                </div>

                <div class="mb-2">
                    <span class="text-muted d-block">No. Telepon</span>
                    <span class="fw-semibold"><?php echo e($umkm->no_telepon); ?></span>
                </div>
            <?php else: ?>
                <p class="text-muted mb-0">
                    Data UMKM belum tersedia untuk akun ini.
                </p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-3">Informasi Profil</h5>
            <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-2">Ganti Password</h5>

            
            <div class="alert alert-secondary small mb-3">
                <strong>Syarat Password:</strong>
                <ul class="mb-0 ps-3">
                    <li>Minimal 8 karakter</li>
                    <li>Minimal 1 huruf besar (A–Z)</li>
                    <li>Minimal 1 huruf kecil (a–z)</li>
                    <li>Minimal 1 angka (0–9)</li>
                    <li>Minimal 1 simbol (contoh: !@#$)</li>
                </ul>
            </div>

            <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    
    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <h5 class="fw-semibold mb-3 text-danger">Hapus Akun</h5>
            <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/indf5165/laravel/resources/views/profile/edit.blade.php ENDPATH**/ ?>