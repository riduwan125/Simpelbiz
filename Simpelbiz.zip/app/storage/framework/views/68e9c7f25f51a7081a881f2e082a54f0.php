<form method="post" action="<?php echo e(route('profile.destroy')); ?>" class="mt-3"
      onsubmit="return confirm('Yakin ingin menghapus akun? Semua data akan hilang.');">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>

    <?php if($errors->userDeletion->get('password')): ?>
        <div class="alert alert-danger py-2 px-3 mb-3">
            <?php echo e($errors->userDeletion->first('password')); ?>

        </div>
    <?php endif; ?>

    <p class="text-muted mb-3">
        Setelah akun dihapus, semua data Anda akan dihapus permanen.
    </p>

    <div class="mb-3" style="max-width: 320px;">
        <label class="form-label fw-semibold">Password</label>
        <input id="password"
               name="password"
               type="password"
               class="form-control <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               placeholder="Masukkan password untuk konfirmasi">
    </div>

    <button type="submit" class="btn btn-outline-danger">
        Hapus Akun
    </button>
</form>
<?php /**PATH /home/indf5165/laravel/resources/views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>