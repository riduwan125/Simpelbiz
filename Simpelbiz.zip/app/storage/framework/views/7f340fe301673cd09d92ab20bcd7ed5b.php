

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Input Modal Usaha / Beban Operasional</h3>

    <form action="<?php echo e(route('modal-beban.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Jenis</label>
            <select name="jenis" class="form-select" required>
                <option value="">-- Pilih Jenis --</option>
                <option value="modal_usaha" <?php echo e(old('jenis')=='modal_usaha'?'selected':''); ?>>
                    Modal Usaha (modal awal / investasi)
                </option>
                <option value="beban_operasional" <?php echo e(old('jenis')=='beban_operasional'?'selected':''); ?>>
                    Beban Operasional (listrik, sewa, bensin, dll)
                </option>
            </select>
        </div>

        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal_transaksi" class="form-control"
                   value="<?php echo e(old('tanggal_transaksi', date('Y-m-d'))); ?>" required>
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <input type="text" name="deskripsi" class="form-control"
                   value="<?php echo e(old('deskripsi')); ?>" required>
        </div>

        <div class="mb-3">
            <label>Nominal</label>
            <input type="number" name="nominal" class="form-control"
                   value="<?php echo e(old('nominal')); ?>" required>
        </div>

        <button class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('modal-beban.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/indf5165/laravel/resources/views/modal-beban/create.blade.php ENDPATH**/ ?>