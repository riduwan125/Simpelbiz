<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>QR Code Laporan</title>
  <style>
    body { font-family: DejaVu Sans, sans-serif; padding: 60px 40px; color:#111; }
    .wrap { text-align:center; }
    h1 { font-size: 18px; margin: 0 0 6px; }
    .sub { font-size: 12px; margin: 0 0 18px; color:#333; }
    .qrbox { display:inline-block; padding: 12px; border:1px solid #ddd; border-radius: 10px; background:#fff; }
    .qrbox img { width: 220px; height: 220px; display:block; }
    .note { margin-top: 18px; font-size: 11px; color:#444; line-height: 1.5; }
    .download { margin-top: 14px; font-size: 12px; }
    .download a { color:#0b57d0; text-decoration: underline; font-weight: 700; }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>QR Code Laporan Keuangan <?php echo e($umkm->nama_umkm ?? 'UMKM'); ?></h1>
    <p class="sub">
      Periode: <?php echo e(str_pad($laporan->bulan, 2, '0', STR_PAD_LEFT)); ?> / <?php echo e($laporan->tahun); ?><br>
      Scan QR Code berikut untuk membuka halaman akses laporan.
    </p>

    <div class="qrbox">
      <img src="data:image/png;base64,<?php echo e($qrPngBase64); ?>" alt="QR Code Laporan">
    </div>

    <div class="note">
      Setelah scan, masukkan <b>email pemilik</b> dan <b>PIN</b> yang dikirim ke email untuk mengunduh laporan.
    </div>

    <div class="download">
      <a href="<?php echo e(route('laporan.qr.download', $laporan->id_laporan)); ?>">
        Download Gambar QR Code (PNG)
      </a>
    </div>
  </div>
</body>
</html>
<?php /**PATH /home/indf5165/laravel/resources/views/laporan/qr_pdf.blade.php ENDPATH**/ ?>