

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Edit Biaya Usaha</h3>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('modal-beban.update', $item->id_modal_beban)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Jenis</label>
            <select name="jenis" class="form-select" required>
                <option value="">-- Pilih Jenis --</option>
                <option value="modal_usaha" <?php echo e(old('jenis', $item->jenis) == 'modal_usaha' ? 'selected' : ''); ?>>
                    Modal Usaha (modal awal / investasi)
                </option>
                <option value="beban_operasional" <?php echo e(old('jenis', $item->jenis) == 'beban_operasional' ? 'selected' : ''); ?>>
                    Beban Operasional (listrik, sewa, bensin, dll)
                </option>
            </select>
        </div>

        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal_transaksi" class="form-control"
                   value="<?php echo e(old('tanggal_transaksi', $item->tanggal_transaksi)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <input type="text" name="deskripsi" class="form-control"
                   value="<?php echo e(old('deskripsi', $item->deskripsi)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Nominal</label>
            <input type="number" name="nominal" class="form-control"
                   value="<?php echo e(old('nominal', $item->nominal)); ?>" required>
        </div>

        <button class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('modal-beban.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    const selectJenis = document.querySelector('select[name="jenis"]');
    const jumlahGroup = document.getElementById('jumlahGroup');

    function toggleJumlah() {
        if (selectJenis.value === 'modal_usaha') {
            jumlahGroup.style.display = 'block';
        } else {
            jumlahGroup.style.display = 'none';
        }
    }

    selectJenis.addEventListener('change', toggleJumlah);
    toggleJumlah();
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/indf5165/laravel/resources/views/modal-beban/edit.blade.php ENDPATH**/ ?>