

<?php $__env->startSection('page-title', 'Laporan Keuangan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-3 py-md-4">

    
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-3 mb-md-4 gap-3">
        <div class="flex-grow-1">
            <h3 class="fw-bold mb-1 fs-4 fs-md-3">Laporan Keuangan</h3>
            <p class="text-muted mb-0 small">
                Kelola dan unduh QR laporan keuangan bulanan UMKM Anda
            </p>
        </div>

        <button type="button"
                id="btn-show-export-form"
                class="btn btn-primary d-flex align-items-center gap-2 shadow-sm">
            <i class="bi bi-download"></i> 
            <span>Export</span>
        </button>
    </div>

    
    <div class="card border-0 shadow-sm mb-3 mb-md-4">
        <div class="card-body p-3 p-md-4">
            <h5 class="mb-3 fs-6 fs-md-5">
                <i class="bi bi-funnel"></i> Filter Laporan
            </h5>
            <form action="<?php echo e(route('laporan.index')); ?>" method="GET" id="search-form">
                <div class="row g-2 g-md-3 align-items-end">
                    <div class="col-12 col-md-4">
                        <label for="search-bulan" class="form-label small">Bulan</label>
                        <select name="search_bulan" id="search-bulan" class="form-select form-select-sm form-select-md-regular">
                            <option value="">-- Semua Bulan --</option>
                            <?php $__currentLoopData = $namaBulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($index); ?>"
                                    <?php echo e(request('search_bulan') == $index ? 'selected' : ''); ?>>
                                    <?php echo e($nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12 col-md-4">
                        <label for="search-tahun" class="form-label small">Tahun</label>
                        <select name="search_tahun" id="search-tahun" class="form-select form-select-sm form-select-md-regular">
                            <option value="">-- Semua Tahun --</option>
                            <?php $tahunSekarang = now()->year; ?>
                            <?php for($t = $tahunSekarang - 5; $t <= $tahunSekarang + 1; $t++): ?>
                                <option value="<?php echo e($t); ?>"
                                    <?php echo e(request('search_tahun') == $t ? 'selected' : ''); ?>>
                                    <?php echo e($t); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-sm flex-grow-1">
                                <i class="bi bi-search"></i> Cari
                            </button>
                            <a href="<?php echo e(route('laporan.index')); ?>" class="btn btn-outline-secondary btn-sm">
                                <i class="bi bi-arrow-clockwise"></i> 
                                <span class="d-none d-sm-inline">Reset</span>
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm mb-3 mb-md-4">
        <div class="card-body p-2 p-md-4">

            <?php if(request('search_bulan') || request('search_tahun')): ?>
                <div class="alert alert-info d-flex align-items-start justify-content-between mb-3 small">
                    <div>
                        <i class="bi bi-info-circle"></i>
                        Menampilkan hasil pencarian untuk:
                        <?php if(request('search_bulan')): ?>
                            <strong><?php echo e($namaBulan[request('search_bulan')]); ?></strong>
                        <?php endif; ?>
                        <?php if(request('search_tahun')): ?>
                            <strong><?php echo e(request('search_tahun')); ?></strong>
                        <?php endif; ?>
                        <br class="d-md-none">
                        <span class="d-block d-md-inline mt-1 mt-md-0">(<?php echo e($laporanList->count()); ?> laporan ditemukan)</span>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="d-none d-md-block table-responsive">
                <table class="table table-striped align-middle text-center mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>ID Laporan</th>
                            <th>Periode</th>
                            <th>Nama PDF</th>
                            <th style="width:220px;">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $laporanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $lap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td><?php echo e($lap->id_laporan); ?></td>
                            <td>
                                <?php echo e($namaBulan[$lap->bulan] ?? $lap->bulan); ?>

                                <?php echo e($lap->tahun); ?>

                            </td>
                            <td>
                                <?php echo e($lap->path_pdf ? basename($lap->path_pdf) : '-'); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('laporan.detail', [
                                        'id' => $lap->id_laporan,
                                        'bulan' => $lap->bulan,
                                        'tahun' => $lap->tahun
                                    ])); ?>"
                                   class="btn btn-info btn-sm"
                                   title="Detail Laporan">
                                    <i class="bi bi-eye"></i>
                                </a>

                                <form action="<?php echo e(route('laporan.destroy', $lap->id_laporan)); ?>"
                                      method="POST"
                                      class="d-inline delete-laporan-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button"
                                            class="btn btn-danger btn-sm btn-delete-laporan"
                                            title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-muted py-4">
                                <?php if(request('search_bulan') || request('search_tahun')): ?>
                                    Tidak ada laporan yang sesuai dengan pencarian.
                                <?php else: ?>
                                    Belum ada laporan yang tersimpan.
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="d-md-none">
                <?php $__empty_1 = true; $__currentLoopData = $laporanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $lap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card mb-2 border">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center gap-2 mb-1">
                                    <span class="badge bg-primary"><?php echo e($i + 1); ?></span>
                                    <small class="text-muted">#<?php echo e($lap->id_laporan); ?></small>
                                </div>
                                <h6 class="mb-1 fw-bold">
                                    <?php echo e($namaBulan[$lap->bulan] ?? $lap->bulan); ?> <?php echo e($lap->tahun); ?>

                                </h6>
                                <p class="mb-0 small text-muted text-truncate" style="max-width: 200px;">
                                    <i class="bi bi-file-earmark-pdf"></i>
                                    <?php echo e($lap->path_pdf ? basename($lap->path_pdf) : 'Tidak ada PDF'); ?>

                                </p>
                            </div>
                        </div>

                        <div class="d-flex gap-2 mt-2">
                            <a href="<?php echo e(route('laporan.detail', [
                                    'id' => $lap->id_laporan,
                                    'bulan' => $lap->bulan,
                                    'tahun' => $lap->tahun
                                ])); ?>"
                               class="btn btn-info btn-sm flex-grow-1">
                                <i class="bi bi-eye"></i> Detail
                            </a>

                            <form action="<?php echo e(route('laporan.destroy', $lap->id_laporan)); ?>"
                                  method="POST"
                                  class="delete-laporan-form"
                                  style="flex: 0 0 auto;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="button"
                                        class="btn btn-danger btn-sm btn-delete-laporan"
                                        title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center text-muted py-4">
                    <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                    <p class="mb-0">
                        <?php if(request('search_bulan') || request('search_tahun')): ?>
                            Tidak ada laporan yang sesuai dengan pencarian.
                        <?php else: ?>
                            Belum ada laporan yang tersimpan.
                        <?php endif; ?>
                    </p>
                </div>
                <?php endif; ?>
            </div>

        </div>
    </div>

    
    <?php
        $tahunSekarang = now()->year;
        $bulanSekarang = now()->month;
        $bulanDipilih  = isset($bulanSelected) ? (int)$bulanSelected : $bulanSekarang;
        $tahunDipilih  = isset($tahunSelected) ? (int)$tahunSelected : $tahunSekarang;
    ?>

    <div class="d-flex justify-content-center px-2 px-md-0">
        <div class="card border-0 shadow-sm d-none" id="export-form-card" style="max-width: 500px; width: 100%;">
            <div class="card-body p-3 p-md-4">
                <h5 class="text-center mb-3 fs-6 fs-md-5">
                    <i class="bi bi-calendar-check"></i> Pilih Periode Laporan
                </h5>

                <form id="export-form" action="<?php echo e(route('laporan.export')); ?>" method="GET">
                    <div class="row g-2 g-md-3 mb-3">
                        <div class="col-6">
                            <label for="bulan" class="form-label small">Bulan</label>
                            <select name="bulan" id="bulan" class="form-select form-select-sm" required>
                                <?php $__currentLoopData = $namaBulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($index); ?>" <?php echo e($bulanDipilih == $index ? 'selected' : ''); ?>>
                                        <?php echo e($nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-6">
                            <label for="tahun" class="form-label small">Tahun</label>
                            <select name="tahun" id="tahun" class="form-select form-select-sm" required>
                                <?php for($t = $tahunSekarang - 5; $t <= $tahunSekarang + 1; $t++): ?>
                                    <option value="<?php echo e($t); ?>" <?php echo e($tahunDipilih == $t ? 'selected' : ''); ?>>
                                        <?php echo e($t); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    <input type="hidden" name="filename" id="filename" value="">

                    <div class="d-grid gap-2">
                        <button type="button" id="btn-preview" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-eye"></i> Tampilkan Preview
                        </button>

                        <button type="button" id="btn-hide-export-form" class="btn btn-light btn-sm">
                            <i class="bi bi-x-circle"></i> Kembali
                        </button>

                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="bi bi-download"></i> Ekspor (QR-Only PDF)
                        </button>
                    </div>
                </form>

                <div class="alert alert-info mt-3 mb-0 small">
                    <i class="bi bi-info-circle"></i>
                    <strong>Catatan:</strong> PDF laporan tabel hanya dapat dibuka oleh pemilik UMKM melalui verifikasi email dan kode pin.
                </div>
            </div>
        </div>
    </div>

</div>


<style>
/* Mobile optimizations */
@media (max-width: 767.98px) {
    .form-select-sm {
        font-size: 0.875rem;
    }
    
    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
    }
    
    .card-body {
        border-radius: 0.5rem;
    }
    
    /* Smooth scroll behavior */
    html {
        scroll-behavior: smooth;
    }
    
    /* Better touch targets */
    .btn, .form-select, .form-control {
        min-height: 44px;
    }
}

/* Tablet and up */
@media (min-width: 768px) {
    .form-select-md-regular {
        height: calc(1.5em + 0.75rem + 2px);
    }
}

/* Animation for export form */
#export-form-card {
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Mobile card hover effect */
@media (max-width: 767.98px) {
    .card:active {
        transform: scale(0.98);
        transition: transform 0.1s;
    }
}
</style>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const btnShow     = document.getElementById('btn-show-export-form');
    const btnHide     = document.getElementById('btn-hide-export-form');
    const btnPrev     = document.getElementById('btn-preview');
    const card        = document.getElementById('export-form-card');
    const selectBulan = document.getElementById('bulan');
    const selectTahun = document.getElementById('tahun');

    // show export form
    if (btnShow && card) {
        btnShow.addEventListener('click', function () {
            card.classList.remove('d-none');
            
            // Smooth scroll with offset for mobile
            setTimeout(() => {
                const offset = window.innerWidth < 768 ? -20 : 0;
                const cardPosition = card.getBoundingClientRect().top + window.pageYOffset + offset;
                
                window.scrollTo({
                    top: cardPosition,
                    behavior: 'smooth'
                });
            }, 100);
        });
    }

    // hide export form
    if (btnHide && card) {
        btnHide.addEventListener('click', function () {
            card.classList.add('d-none');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // preview
    if (btnPrev && selectBulan && selectTahun) {
        btnPrev.addEventListener('click', function () {
            const bulan = selectBulan.value;
            const tahun = selectTahun.value;

            const baseUrl = "<?php echo e(route('laporan.index')); ?>";
            const url = `${baseUrl}?bulan=${encodeURIComponent(bulan)}&tahun=${encodeURIComponent(tahun)}`;
            window.location.href = url;
        });
    }

    // intercept export submit -> minta nama file dulu
    const exportForm = document.getElementById('export-form');
    const filenameInput = document.getElementById('filename');

    if (exportForm) {
        exportForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const bulan = selectBulan ? selectBulan.value : '';
            const tahun = selectTahun ? selectTahun.value : '';
            const defaultName = `qr_only_laporan_${tahun}_${bulan}`;

            // SweetAlert ada?
            if (typeof Swal === 'undefined') {
                const name = prompt('Masukkan nama file PDF:', defaultName);
                if (!name) return;
                filenameInput.value = name;
                exportForm.submit();
                return;
            }

            const result = await Swal.fire({
                title: 'Nama file PDF',
                input: 'text',
                inputValue: defaultName,
                inputPlaceholder: 'Contoh: qr_only_laporan_2025_12',
                showCancelButton: true,
                confirmButtonText: 'Unduh',
                cancelButtonText: 'Batal',
                customClass: {
                    container: window.innerWidth < 768 ? 'swal2-mobile' : ''
                },
                inputValidator: (value) => {
                    if (!value || !value.trim()) return 'Nama file tidak boleh kosong.';
                    if (value.length > 80) return 'Nama file terlalu panjang.';
                    return null;
                }
            });

            if (!result.isConfirmed) return;

            filenameInput.value = result.value.trim();
            exportForm.submit();
        });
    }

    // delete confirm
    document.querySelectorAll('.delete-laporan-form').forEach((form) => {
        const btn = form.querySelector('.btn-delete-laporan');
        if (!btn) return;

        btn.addEventListener('click', function (e) {
            e.preventDefault();

            if (typeof Swal === 'undefined') {
                if (confirm('Hapus laporan? Laporan yang dihapus tidak dapat dikembalikan.')) form.submit();
                return;
            }

            Swal.fire({
                title: 'Hapus laporan?',
                text: 'Laporan yang dihapus tidak dapat dikembalikan.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3342f',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus',
                cancelButtonText: 'Batal',
                customClass: {
                    container: window.innerWidth < 768 ? 'swal2-mobile' : ''
                }
            }).then((result) => {
                if (result.isConfirmed) form.submit();
            });
        });
    });

    // toast notif after redirect
    <?php if(session('success')): ?>
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: <?php echo json_encode(session('success'), 15, 512) ?>,
                toast: true,
                position: window.innerWidth < 768 ? 'top' : 'top-end',
                timer: 2200,
                timerProgressBar: true,
                showConfirmButton: false
            });
        } else {
            alert(<?php echo json_encode(session('success'), 15, 512) ?>);
        }
    <?php endif; ?>

    <?php if(session('error')): ?>
        if (typeof Swal !== 'undefined') {
            Swal.fire({ 
                icon: 'error', 
                title: 'Gagal', 
                text: <?php echo json_encode(session('error'), 15, 512) ?>,
                customClass: {
                    container: window.innerWidth < 768 ? 'swal2-mobile' : ''
                }
            });
        } else {
            alert(<?php echo json_encode(session('error'), 15, 512) ?>);
        }
    <?php endif; ?>

    // Prevent double tap zoom on buttons (iOS)
    document.querySelectorAll('button, a.btn').forEach(element => {
        element.addEventListener('touchend', function(e) {
            e.preventDefault();
            element.click();
        }, { passive: false });
    });
});
</script>

<style>
/* SweetAlert mobile optimization */
.swal2-mobile {
    padding: 1rem !important;
}

.swal2-mobile .swal2-popup {
    width: calc(100% - 2rem) !important;
    font-size: 0.9rem !important;
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/indf5165/laravel/resources/views/laporan/index.blade.php ENDPATH**/ ?>