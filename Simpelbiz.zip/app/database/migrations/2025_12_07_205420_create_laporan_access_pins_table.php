<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('laporan_access_pins', function (Blueprint $table) {
            $table->id();
            $table->foreignId('laporan_id')
                ->constrained('laporan_keuangan', 'id_laporan')
                ->onDelete('cascade');

            $table->string('email');
            $table->string('pin', 6);           // PIN 6 digit
            $table->timestamp('expires_at');    // masa berlaku PIN
            $table->timestamp('used_at')->nullable(); // kalau sudah dipakai
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('laporan_access_pins');
    }
};
