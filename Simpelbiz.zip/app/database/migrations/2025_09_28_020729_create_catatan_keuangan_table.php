<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('catatan_keuangan', function (Blueprint $table) {
            $table->id('id_catatan');

            // relasi ke tabel umkm
            $table->foreignId('id_umkm')
                ->constrained('umkm', 'id_umkm')
                ->onDelete('cascade');

            $table->string('jenis_catatan'); // pemasukan / pengeluaran
            $table->decimal('jumlah', 15, 2);
            $table->decimal('nominal', 15, 2); // ✅ hasil perkalian disimpan
            $table->date('tanggal_transaksi');
            $table->text('deskripsi')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('catatan_keuangan');
    }
};
