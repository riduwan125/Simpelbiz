<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up()
{
    Schema::table('laporan_keuangan', function (Blueprint $table) {
        $table->string('path_qr_pdf')->nullable()->after('path_pdf');
    });
}

public function down()
{
    Schema::table('laporan_keuangan', function (Blueprint $table) {
        $table->dropColumn('path_qr_pdf');
    });
}
};
