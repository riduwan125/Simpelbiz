<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('catatan_keuangan', function (Blueprint $table) {
            $table->string('satuan', 50)->nullable()->after('jumlah');
        });
    }
    
    public function down(): void
    {
        Schema::table('catatan_keuangan', function (Blueprint $table) {
            $table->dropColumn('satuan');
        });
    }
};    