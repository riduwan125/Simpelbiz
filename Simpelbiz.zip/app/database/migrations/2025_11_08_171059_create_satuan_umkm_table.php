<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('satuan_umkm', function (Blueprint $table) {
            $table->id('id_satuan');
            $table->foreignId('id_umkm')
                  ->constrained('umkm', 'id_umkm')
                  ->onDelete('cascade');
            $table->string('nama_satuan', 50);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('satuan_umkm');
    }
};
