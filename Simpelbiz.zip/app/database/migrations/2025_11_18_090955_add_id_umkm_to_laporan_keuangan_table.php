<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('laporan_keuangan', function (Blueprint $table) {
            $table->unsignedBigInteger('id_umkm')->after('id_laporan');
            $table->foreign('id_umkm')->references('id_umkm')->on('umkm')->onDelete('cascade');
        });
    }
    
    public function down()
    {
        Schema::table('laporan_keuangan', function (Blueprint $table) {
            $table->dropForeign(['id_umkm']);
            $table->dropColumn('id_umkm');
        });
    }
};    