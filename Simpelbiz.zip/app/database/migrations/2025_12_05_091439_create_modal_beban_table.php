<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('modal_beban', function (Blueprint $table) {
            $table->id('id_modal_beban');

            // relasi ke tabel umkm
            $table->foreignId('id_umkm')
                ->constrained('umkm', 'id_umkm')
                ->onDelete('cascade');

            // modal_usaha / beban_operasional
            $table->enum('jenis', ['modal_usaha', 'beban_operasional']);

            $table->decimal('jumlah', 15, 2)->default(1);   // kalau mau pakai qty
            $table->decimal('nominal', 15, 2);              // total uang
            $table->date('tanggal_transaksi');
            $table->text('deskripsi')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('modal_beban');
    }
};
