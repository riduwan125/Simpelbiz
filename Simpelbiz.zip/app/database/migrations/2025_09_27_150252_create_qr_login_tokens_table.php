<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('qr_login', function (Blueprint $table) {
            $table->id('id_qr_login');
            $table->foreignId('id_user')
                  ->constrained(table: 'users', column: 'id_user')
                  ->onDelete('cascade');
            $table->text('token_login');       // simpan token terenkripsi (AES-256)
            $table->timestamp('expires_at');   // kadaluarsa 15 menit
            $table->timestamp('used_at')->nullable(); // kalau sudah dipakai
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('qr_login');
    }
};
