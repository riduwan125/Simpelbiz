<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('catatan_keuangan', function (Blueprint $table) {
            $table->unsignedBigInteger('id_laporan')
                  ->nullable()
                  ->after('id_umkm');

            $table->foreign('id_laporan')
                  ->references('id_laporan')
                  ->on('laporan_keuangan')
                  ->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::table('catatan_keuangan', function (Blueprint $table) {
            $table->dropForeign(['id_laporan']);
            $table->dropColumn('id_laporan');
        });
    }
};
