<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('laporan_keuangan_detail', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('laporan_id');

            $table->date('tanggal_transaksi');
            $table->string('jenis_catatan');
            $table->text('deskripsi')->nullable();
            $table->decimal('jumlah', 15, 2)->default(0);
            $table->decimal('nominal', 15, 2)->default(0);

            $table->timestamps();

            $table->foreign('laporan_id')
                ->references('id_laporan')
                ->on('laporan_keuangan')
                ->onDelete('cascade');

            $table->index('laporan_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('laporan_keuangan_detail');
    }
};
