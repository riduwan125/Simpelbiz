<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('qr_laporan', function (Blueprint $table) {
            $table->id('id_token'); // PK

            // relasi ke laporan keuangan
            $table->foreignId('id_laporan')
                  ->constrained('laporan_keuangan', 'id_laporan')
                  ->onDelete('cascade');

            $table->string('token_akses', 128)->unique(); // token QR akses laporan
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('qr_laporan');
    }
};