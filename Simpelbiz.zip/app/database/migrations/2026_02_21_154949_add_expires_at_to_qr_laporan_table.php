<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('qr_laporan', function (Blueprint $table) {

            // Tambah kolom expired token QR
            if (!Schema::hasColumn('qr_laporan', 'expires_at')) {
                $table->timestamp('expires_at')
                      ->nullable()
                      ->after('token_akses');
            }

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('qr_laporan', function (Blueprint $table) {

            // Hapus kolom jika rollback
            if (Schema::hasColumn('qr_laporan', 'expires_at')) {
                $table->dropColumn('expires_at');
            }

        });
    }
};